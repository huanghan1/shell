#!/bin/bash

develop_pass=dev_123456
test_pass=test_123
cloud_pass=dev_123456
master_pass=pro
hotfix_pass=pro

eval pass="\$${branch}_pass"

if [ "$password" != "$pass" ];then 
   echo "#################password is error.....#############################"
   exit 1
fi     
