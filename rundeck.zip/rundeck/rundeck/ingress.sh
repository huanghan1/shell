#!/bin/bash
#item=$1
#app=$2
#env=$3
#idc=$4
#dname=$5
path='/'

if [ $item == "none" -o $app == "none" ];then
   echo "error:item or app is none"
   exit 1
fi

#端口与应用类型
if [ $item == "hwynan" -o $item == "hwp2p" -o $item == "hwflb" ];then
	app_port=`/usr/bin/curl -sSL "http://apollo.51huihuahua.com:8080/configfiles/json/xiaoniuhw-app-port-type/default/application?ip=192.168.1.248" |/usr/bin/jq .$app | /usr/bin/awk '{print $1}' |/usr/bin/sed -n 's/\"//gp'`
else
	app_port=`/usr/bin/curl -sSL "http://apollo.51huihuahua.com:8080/configfiles/json/xiaoniu-app-port-type/default/application?ip=192.168.1.248" |/usr/bin/jq .$app | /usr/bin/awk '{print $1}' |/usr/bin/sed -n 's/\"//gp'`
	
fi
if [ -z "$app_port" ];then
   echo "apollo xiaoniuhw-app-port-type 中不存在这个应用名"
   exit 1
fi

ns=${item}-${env}-$idc
workdir="/data/workspace/$item/$app/$env/$idc"
[ ! -d $workdir ] && /usr/bin/mkdir -pv $workdir
src_dname_prefix=`echo $dname |/usr/bin/awk -F "." '{print $1}'`
dname_check="${app}-${item}-${env}-${idc}"

if [ $if_pressure == "yes" ];then
  ns=${ns}-pressure
  workdir=${workdir}-pressure
  dname_check="${app}-${item}-${env}-${idc}-pressure"
  
fi


#检查域名规则是否正确
if [ $src_dname_prefix != "$dname_check"  ];then
   echo "域名前缀不满足使用的域名规则"
   echo "域名前缀应用为: $dname_check"
   exit 1
fi


#检查namespace是否存在
/opt/kube/bin/kubectl get namespaces |/usr/bin/grep -q $ns
if [ ! $? -eq 0 ];then
   echo "namespace: $ns 不存在"
   exit 1 
fi

cd $workdir || exit 1

/usr/bin/cat << EOF > ${app}_ingress.yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: $app
  namespace: $ns
spec:
  rules:
  - host: $dname
    http:
      paths:
      - path: $path
        backend:
          serviceName: $app
          servicePort: 8080
          
EOF

/opt/kube/bin/kubectl apply -f ${app}_ingress.yaml

if [ $? -eq 0 ];then
   re=`/usr/bin/ssh 172.16.11.53 "/usr/bin/grep -c $dname /etc/nginx/conf.d/common/ingress_server_name.txt"`
   if [ $re -eq 0 ];then
       /usr/bin/ssh 172.16.11.53 "echo server_name  ${dname}\;  >> /etc/nginx/conf.d/common/ingress_server_name.txt "
       result=`/usr/bin/ssh 172.16.11.53 "/usr/sbin/nginx -t 2>&1 |/usr/bin/grep  'test is successful'"`
       [ ! -z "$result" ] && /usr/bin/ssh 172.16.11.53 "/usr/sbin/nginx -s reload"
   fi
fi
