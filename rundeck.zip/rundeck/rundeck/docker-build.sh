#!/bin/bash

# Variables
appname=$1
proj=$2
tagstr=$3
#大写转小写
typeset -l  app
app=$appname

dir=/data/workspace/$proj/$appname

HARBOR_IP="registry-vpc.cn-shanghai.aliyuncs.com"
REPOSITORIES="xn-test/${proj}"
HARBOR_USER="niehaiyong@xiaoniutech"
HARBOR_USER_PASSWD="xn123456"
HARBOR_USER_EMAIL="niehaiyong@xiaoniu.com"
 
 
# Delete image early version.
docker login -u ${HARBOR_USER} -p ${HARBOR_USER_PASSWD} ${HARBOR_IP} 
IMAGE_ID=`docker images | grep ${REPOSITORIES} | awk '{print $3}'`
if [ -n "${IMAGE_ID}" ];then
    sudo docker rmi -f ${IMAGE_ID}
fi
 
# Build image.
cd $dir
TAG=`date +"%Y-%m-%d-%H-%M"`
tagstr=v${tagstr}_$TAG
#sudo docker build -t ${HARBOR_IP}/${REPOSITORIES}:${TAG} . &>/dev/null
docker build -t ${HARBOR_IP}/${REPOSITORIES}:${tagstr} . 
 
# Push to the harbor registry.
#sudo docker push ${HARBOR_IP}/${REPOSITORIES}:${TAG} &>/dev/null
docker push ${HARBOR_IP}/${REPOSITORIES}:${tagstr} 
echo "Tag:$tagstr"
