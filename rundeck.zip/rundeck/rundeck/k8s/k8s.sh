#!/bin/bash
if [ $# -lt 3 ];then
   echo "参数错误:project,cluster,appname,[relicas]"
   exit 1
fi

proj=$1
cluster=$2
appname=$3
option=$4
memry=2048m
[ -z $option ] && option=deploy
relicas=$5
[ -z $relicas ] &&  relicas=1
#大写转小写
typeset -l  app
app=$appname

#环境ip
htest01=172.16.11.137
hdev="172.16.11.175"
eval ip="\$$cluster"
[ -z $ip ] &&  echo "节点ip没在配置,退出容器操作" && exit 1
appscriptname="appstart.sh"
dir="/data/workspace/$proj/$appname"
k8logdir="/data/logs/"
logdir="/data/$appname/logs"
port=`curl -sSL "http://apollo.58huihuahua.com:18082/configfiles/json/huihuahua-app-port/default/application?ip=192.168.1.248" |jq .$appname | awk '{print $1}' |sed -n 's/\"//gp'`
ptype=`curl -sSL "http://apollo.58huihuahua.com:18082/configfiles/json/huihuahua-app-type/default/application?ip=192.168.1.248" |jq .${appname}_type | awk '{print $1}' |sed -n 's/\"//gp'`
authstr="--docker-server=registry-vpc.cn-shanghai.aliyuncs.com --docker-username=niehaiyong@xiaoniutech --docker-password=xn123456 --docker-email=niehaiyong@xiaoniu.com"
pinpoint="no"
pinpoint_ip="no"
config_dir=" "
jar_string=" "
imageadd="registry-vpc.cn-shanghai.aliyuncs.com/xn-test/xiaoniu-tomcat:8.5.32_v6"

echo $node |grep -q pro
[ $? -eq 0 ] && filename=${appname}.$ptype || filename=${appname}_${cluster}.$ptype


echo "记录变量值"
cat << EOF > var.txt
proj=$proj
cluster=$cluster
appname=$appname
option=$option
memry=$memry
relicas=$relicas
app=$app
htest01=$htest01
hdev=$hdev
ip=$ip
dir=$dir
logdir=$logdir
port=$port
ptype=$ptype
npoint=$pinpoint
pinpoint_ip=$pinpoint_ip
config_dir=$config_dir
jar_string=$jar_string
EOF

cat var.txt

echo "########################"

cd $dir || exit 1

echo "#生成namespace.yml"
cat << EOF > namespace.yml

apiVersion: v1
kind: Namespace
metadata:
   name: $proj
   labels: 
     name: $proj

EOF

echo "#生成${appname}-configmap.yaml"
cat << EOF > ${appname}-configmap.yaml
kind: ConfigMap
apiVersion: v1
metadata:
  name: $app
  namespace: $proj
  labels:
    software: $app
    project: $app
    app: $app
    version: v1
data:
  appname: "$appname"
  port: "$port"
  ptype: "$ptype"
  memry: "$memry"
  cluster: "$cluster"
  appscriptname: "$appscriptname"
  logdir: "$k8logdir"
  pinpoint: "$pinpoint"
  pinpoint_ip: "$pinpoint_ip"
  config_dir: "$config_dir"
  jar_string: "$jar_string"
EOF

echo "#生成k8s 的deployment类型文件"
cat << EOF > ${appname}.yml
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  namespace: $proj
  name: $app
  labels:
    name: $app
spec:
  replicas: $replicas
  template:
    metadata:
      labels:
        app: $app
    spec:
      hostNetwork: true
      nodeSelector:
        cluster: $cluster
      imagePullSecrets:
      - name: $proj
      containers:
      - name: $app
        image: $imageadd
        ports:
        - containerPort: $port
          hostPort: $port
        envFrom:
        - configMapRef:
            name: $app
        volumeMounts:
        - mountPath: $k8logdir
          name: logs
      volumes:
      - name: logs
        hostPath:
          path: $logdir

EOF

echo "############# k8s start ###############"
echo "#检查创建namespace"
kubectl get namespaces |grep -q $proj
if [ ! $? -eq 0 ];then
   kubectl create -f namespace.yml
   kubectl  create secret docker-registry $proj -n $proj $authstr
   [ ! $? -eq 0 ] && echo "私有仓库授权失败" && exit 1
else
   kubectl get secret -n $proj |grep -q $proj
   [ ! $? -eq 0 ] && kubectl  create secret docker-registry $proj -n $proj $authstr > /dev/null
fi

echo "#检查创建节标签"
kubectl get node -l "cluster=$cluster" -n $proj 2>&1 |grep -q "No resources found"
#[ $? -eq 0 ] && echo "名字空间${proj}的应用${appname}没有创建节点标签，停上后面所有动作退出" && exit 1
if [ $? -eq 0 ];then
   hname=`ssh $ip "hostname"`
   kubectl label nodes $hname cluster=$cluster -n $proj
fi

kubectl get deployment -n $proj 2>&1 |grep -q $app
re=$?
[ ! $re -eq 0 ] && echo "$app 的 deployment不存在"

if [ $option == "only_del_deployment" ];then
   echo "delete $appname deployment"
   kubectl delete deployment/$app -n $proj 2>&1 
   exit 0

elif [ ! $re -eq 0 -o $option == "reset" ];then
   echo "#创建configMap,deployment"
   echo "-->#重新创建configMap"
   kubectl  get configMap -n $proj 2>&1 |grep -q $app
   [ $? -eq 0 ] && kubectl delete configMap/$app -n $proj > /dev/null
   kubectl create -f ${appname}-configmap.yaml -n $proj
   
   echo "-->delete $appname deployment"
   kubectl delete deployment/$app -n $proj 2>&1 > /dev/null
   sleep 10
   echo "-->#创建deployment,这可能需要几分钟........."
   kubectl create -f ${appname}.yml -n $proj
   sleep 15
   echo "-->检查pod壮态."
   kubectl get pod -n $proj |grep $app

else
  echo "#deployment正常，开始检查pod壮态"
  #创建configMap
  kubectl  get configMap -n $proj |grep -q $app
  [ ! $? -eq 0 ] && kubectl create -f ${appname}-configmap.yaml -n $proj
  
  #检查pod状态
  pod=`kubectl get pod -n $proj |grep $app `
  echo $pod
  pod_status=`echo $pod |awk '{print $2"-"$3}'`
  if [ $pod_status != "${relicas}/${relicas}-Running" ];then
     echo "pod壮态异常,退出容器操作"
     exit 1
  else
    echo "pod壮态正常"
  fi
fi

if [ $option == "update_script" ];then
   echo "更新启动脚本appstart.sh"
   dstr=`date +"%Y-%m-%d-%H"`
   sha1=`echo "${appscriptname}-$dstr" | sha256sum |awk '{print $1}'`
   scp -P 22 /data/shell2/shell/rundeck/$appscriptname $ip:$logdir/
   ssh -p 22 $ip "echo 1 > $logdir/$sha1"
   echo "hash文件$logdir/$sha1"

elif [ -f $filename -a $option != "onlyrestart" ];then
   echo "#推送应用包到目标节点 并设置应用更新开关壮态为1"
   ssh -p 22 $ip "[ ! -d $logdir ] &&  mkdir $logdir"
   rsync -az -e "ssh " $filename $ip:$logdir/${appname}.$ptype
   sleep 2
   sha1=`sha256sum $filename |awk '{print $1}'`
   ssh -p 22 $ip "echo 1 > $logdir/$sha1"
   exit 0
elif [ $option == "onlyrestart" ];then
   echo "#设置重启开关为1"
   dstr=`date +"%Y-%m-%d"`
   sha1=`echo ${cluster}-$dstr |sha256sum |awk '{print $1}'`
   ssh -p 22 $ip "echo 1 > $logdir/$sha1"
fi

