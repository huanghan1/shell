#!/bin/bash

apurl=$1
cluster_name=$2
appname=$3

if [ ! $# -eq 3 ];then
   echo "Usage:apollo_env_url cluster_name app_name"
   exit 1
fi

#apollo_str=`curl -sSL "http://apollo.51huihuahua.com:18082/configfiles/json/k8s-cluster-ip/fdd_test01/application?ip=192.168.1.248"  | jq .loanapply|sed -n s'/\"//gp'`
apollo_str=`curl -sSL "$apurl/configfiles/json/k8s-cluster-ip/$cluster_name/application?ip=192.168.1.248"  | jq .$appname |sed -n s'/\"//gp'`
tmp_str=$(echo $apollo_str |sed -n 's/\\n/__/pg')
par_num=$(echo $tmp_str |awk -F '__' '{print NF}')
[ ! -d /tmp/apollconfig/$appname ] && mkdir -p /tmp/apollconfig/$cluster_name/$appname
> /tmp/apollconfig/$cluster_name/$appname/apollo_par.sh
for x in `seq 1 $par_num`
do
  par_str1=$(echo $tmp_str |awk -F "__" -v li=$x '{print $li}')
  par_str2=$(echo $par_str1 |sed -n 's/#/\"/gp')
  echo $par_str1 |grep -q "#"

  if [ $? -eq  0 ];then
     echo "$par_str2" >> /tmp/apollconfig/$cluster_name/$appname/apollo_par.sh
  else
     echo "$par_str1" >> /tmp/apollconfig/$cluster_name/$appname/apollo_par.sh
  fi
done

