#!/bin/bash
#cd /root/.jenkins/workspace/guanjia/lending-medical-beauty
##########################################################################
###变量信息
item=$1
appname=$2
branch=$3
env=$4
idc=$5
file_dir=$6
yaml_file_dir=$7
#节点ip
#nodesip=""
dockerlogsdir="/data/$appname/logs"
#host文件
local_host=$ip_host
#namespce and logdir
ns=${item}-${env}-$idc
logdir="/data/logs/$item/$appname/$env/$idc"
if [ "$if_pressure" == "yes" ];then
  ns=${ns}-pressure
  logdir=${logdir}-pressure
fi

if [ "$env" == "pro" ];then
    exit 0 

fi


#集群标签
#cluster_lable="function_test"
#if [ $if_pressure == "yes" ];then
#   cluster_lable="pressure_test"
#fi

#端口与应用类型
app_port=`curl -sSL "http://apollo.51huihuahua.com:8080/configfiles/json/xiaoniu-app-port-type/default/application?ip=192.168.1.248" |jq .$appname | awk '{print $1}' |sed -n 's/\"//gp'`
[ -z $app_port ] && app_port=none
app_type=`curl -sSL "http://apollo.51huihuahua.com:8080/configfiles/json/xiaoniu-app-port-type/default/application?ip=192.168.1.248" |jq .${appname}_type|sed -n 's/\"//gp'`
[ -z $app_type ] && app_type=none

if [ $app_port == "none" -a $app_type == "none" ];then
   echo "port or app_type 没有配置在xiaoniu-app-port-type"
   exit 1
fi

#配置启动参数common_java_Doption="-server -Xms1g -Xmx1g -XX:MetaspaceSize=512m -XX:MaxMetaspaceSize=512m -XX:+DisableExplicitGC -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:ParallelGCThreads=8 -XX:ConcGCThreads=8 -XX:InitiatingHeapOccupancyPercent=45 -XX:NewRatio=2 -XX:SurvivorRatio=8 -XX:MaxTenuringThreshold=15 -XX:G1ReservePercent=10 -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/data/$appname/logs/ -Dserver.port=8080 -Deureka.instance.homePageUrl=http://${appname}:8080"
common_java_Doption="-server -Xms1g -Xmx1g -XX:MetaspaceSize=512m -XX:MaxMetaspaceSize=512m -XX:+DisableExplicitGC -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:ParallelGCThreads=8 -XX:ConcGCThreads=8 -XX:InitiatingHeapOccupancyPercent=45 -XX:NewRatio=2 -XX:SurvivorRatio=8 -XX:MaxTenuringThreshold=15 -XX:G1ReservePercent=10 -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${dockerlogsdir} -Dserver.port=8080 -Deureka.instance.homePageUrl=http://${appname}:8080"
common_java_option="--server.port=8080"

if [ -z "$java_Doption" ];then
   JDoption="$common_java_Doption"
else
   JDoption="${common_java_Doption} $java_Doption"
fi

if [ -z "$java_option" ];then
   Joption="$common_java_option"
else
   Joption="$common_java_option $java_option"
fi

#harbor_url
harbor_url="172.16.0.175:18080"
#k8s访问harbor仓库认证用的参数
authstr="--docker-server=http://$harbor_url --docker-username=admin --docker-password=admin_123 --docker-email=niehaiyong@xiaoniu.com"
#基础镜像，用于dockerfile
base_image="172.16.0.175:18080/common/openjdk8:v1"
#镜像url,用于k8s部署
image_url="$harbor_url/$item/${appname}_${branch}:$d_time"

###########################################################################
if [ $option == "deploy" ];then
#docker 操作
#登录harbor仓库
docker login -u admin -p admin_123 http://172.16.0.175:18080

# Delete local  image early version.
#repo_str="$item/${appname}_$branch"
repo_str="172.16.0.175:18080/$item/${appname}_$branch"
IMAGE_ID=`docker images | grep -E "$repo_str|none|python|mongo|node|open|centes" | awk '{print $3}'`
if [ -n "${IMAGE_ID}" ];then
  for x in $IMAGE_ID
  do 
       sudo docker rmi -f $x
  done
fi

#创建dockerfile
unset cp
\cp -f /data/shell2/shell/rundeck/k8s-start.sh ./
cat << EOF > Dockerfile
from $base_image
MAINTAINER niehaiyong@xiaoniu.com
workdir /home/wls81
ENV LANG=zh_CN.UTF-8
COPY k8s-start.sh /home/wls81/shell/start.sh
COPY $file_dir /home/wls81/package/${appname}.${app_type}
cmd ["/home/wls81/shell/start.sh"]

EOF

##build基础镜像,并推送到harbor仓库
d_time=`date +"%Y.%m.%d.%H.%M.%S"`
image_url="$harbor_url/$item/${appname}_${branch}:$d_time"
#检查harbor中项目是否创建。
curl  -I  "http://$harbor_url/api/projects?project_name=$item" 2>&1 |grep -q "Not Found"
if [ $? -eq 0 ];then
  curl -X POST "http://$harbor_url/api/projects" -H "accept: application/json" -H "Content-Type: application/json" -d "{ \"project_name\": \"$item\", \"metadata\": { \"public\": \"false\", \"enable_content_trust\": \"true\",  \"auto_scan\": \"true\" }}" -u admin:admin_123
fi

#构建与推送
docker build -t $image_url .
docker push $image_url

if [ ! $? -eq 0 ];then
   echo "docker push 失败" 
   exit 1
fi

#保存Dockerfile
unset cp
\cp -f Dockerfile $yaml_file_dir

fi
##########################################################################
cd $yaml_file_dir || exit 1
if [ $option == "deploy" ];then
#k8s操作
#创建namespce.yml,检查并创建namespace,同时创建访问harbor仓库的认证配置
cat << EOF > namespace.yml
apiVersion: v1
kind: Namespace
metadata:
   name: $ns
   labels: 
     name: $ns

EOF

kubectl get namespaces |grep -q $ns
if [ ! $? -eq 0 ];then
   kubectl create -f namespace.yml
fi
kubectl get secret -n $ns |grep -q $item
if [ ! $? -eq 0 ];then
   kubectl  create secret docker-registry $item -n $ns $authstr > /dev/null
   if [ ! $? -eq 0 ];then
      echo "私有harbor仓库授权认证创建失败"
      exit 1
   fi
fi

#生成configmap.yaml,这个文件中的变量在容器内部被启动脚本使用
echo "创建configmap"
cat << EOF > ${appname}_configmap.yaml
kind: ConfigMap
apiVersion: v1
metadata:
  name: $appname
  namespace: $ns
  labels:
    software: $appname
    project: $appname
    app: $appname
    version: v1
data:
  appname: $appname
  apptype: $app_type
  idc: "$idc"
  env: "$env"
  host: "$local_host"
  java_Doption: "$JDoption"
  java_option: "$Joption"
EOF

kubectl apply -f ${appname}_configmap.yaml -n $ns
if [ ! $? -eq 0 ];then
  echo "创建configmap 失败"
  exit 1
fi

#生成${appname}_deployment.yaml,在k8s中部署容器应用
echo "k8s开始部署 ${appname}_deployment.yaml"
cat << EOF > ${appname}_deployment.yaml
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  namespace: $ns
  name: $appname
  labels:
    name: $appname
spec:
  replicas: 1
  template:
    metadata:
      labels:
        app: $appname
    spec:
      imagePullSecrets:
      - name: $item
      containers:
      - name: $appname
        image: $image_url
        ports:
        - containerPort: 8080  
        envFrom:
        - configMapRef:
            name: $appname
        volumeMounts:
        - mountPath: /data/$appname/logs
          name: logs
      volumes:
      - name: logs
        hostPath:
          path: $logdir

EOF

kubectl apply -f ${appname}_deployment.yaml -n $ns
if [ ! $? -eq 0 ];then
  echo "创建deployment 失败"
  exit 1
fi


#生成${appname}_svc.yaml
echo "开始应用 ${appname}_svc.yaml"
#配置server  
#if [ $ifcreate_server -eq 1 ];then
cat << EOF > ${appname}_svc.yaml
apiVersion: v1
kind: Service
metadata:
  labels:
    name: $appname
  namespace: $ns
  name: $appname
spec:
  ports:
    - port: 8080 
      targetPort: 8080
  selector:
    app: $appname
EOF


kubectl apply -f ${appname}_svc.yaml -n $ns
if [ ! $? -eq 0 ];then
  echo "创建svc 失败"
  exit 1
fi


echo "k8s完成部署"

elif [ $option == "restart" ];then
   pods=`kubectl get pods -n $ns |grep -v NAME |grep -E "${appname}-" | awk '{print $1}'`
   for pod in $pods
   do
     kubectl delete pods/$pod -n $ns
   done
elif [ $option == "delete" ];then
   dep=`kubectl get deployments -n $ns |grep -v NAME |grep -E "\<$appname\>" | awk -F '{print $1}' `
   kubectl delete deployments/$appname -n $ns
fi
   
  

