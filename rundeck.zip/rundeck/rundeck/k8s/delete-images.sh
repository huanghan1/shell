#!/bin/bash
IMAGE_ID=`docker images |grep -E "^172" |awk '{print $3}'`
if [ -n "${IMAGE_ID}" ];then
  for x in $IMAGE_ID
  do  
    docker rmi  $x  
    echo $x
  done
fi
