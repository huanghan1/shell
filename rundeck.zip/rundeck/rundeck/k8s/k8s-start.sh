#!/bin/bash

local_host=$host
[ -z $local_host ] && local_host=none

local_idc=$idc
[ -z "$local_idc" ] && local_idc="default"

local_env="$env"
[ -z "$local_env" ] && local_env="pro"

local_java_Doption="$java_Doption"
[ -z "$local_java_Doption" ] && local_java_Doption=" "

local_java_option="$java_option"
[ -z "$local_java_option" ] && local_java_option=" "

local_app_name=$appname
unset cp 
if [ -z "$local_app_name" ];then 
 local_app_name="web"
fi

local_app_type=$apptype
[ -z "$local_app_type" ] && local_app_type="war"
export LANG=en_US.UTF-8
#设置apollo
[ ! -d /opt/settings ] && mkdir -p /opt/settings
echo "idc=$local_idc" > /opt/settings/server.properties
echo "env=$local_env" >> /opt/settings/server.properties

#log dir
logdir="/data/$local_app_name/logs"
[ ! -d $logdir ] && mkdir -p $logdir

#复制package到运行目录，设置pid_str
if [ $local_app_type == "war" ];then
   [ -f /home/wls81/package/${local_app_name}.$local_app_type ] &&  \cp -f  /home/wls81/package/${local_app_name}.$local_app_type /home/wls81/tomcat/webapps/
   pid_str="/home/wls81/tomcat/temp"
elif [ $local_app_type == "jar" ];then
   [ -f /home/wls81/package/${local_app_name}.$local_app_type ] &&  \cp -f  /home/wls81/package/${local_app_name}.$local_app_type /home/wls81/jarapp/
   pid_str="${local_app_name}.jar"
else
   pid_str="/home/wls81"
fi

#处理本地host映射
if [ $local_host != "none" ];then
   for host_str in $local_host
   do
      ip=`echo $host_str |awk -F : '{print $1}'`
      dname=`echo $host_str |awk -F : '{print $2}'`
      echo "$ip  $dname" >> /etc/hosts
   done
fi

#################################################################################
#检查并启动应用
while true
do
   pid=$(ps -ef |grep -v grep |grep -E "$pid_str" |awk -F " " '{print $2}')
   if [ -z $pid ];then
      if [ $local_app_type == "war" ];then
         cd /home/wls81/tomcat/ || echo "error:can not cd /home/wls81/tomcat"
         if [ -f webapps/${local_app_name}.$local_app_type ];then
                export local_app_name
                [ -f ./bin/startup.sh ] && ./bin/startup.sh 2>&1 > /dev/null
         else
            echo "webapps/${local_app_name}.$local_app_type is not exit"
         fi
      else
         cd /home/wls81/jarapp/ || echo "error:can not cd /home/wls81/java"
         if [ -f ${local_app_name}.jar ];then
             nohup java $local_java_Doption -jar /home/wls81/jarapp/${local_app_name}.jar $local_java_option 2>&1 | /usr/local/sbin/cronolog $logdir/catalina.out.%Y-%m-%d-%H.log >> /dev/null &
         
         else
             echo "${local_app_name}.jar is not exist"
         fi
      fi
  else
      echo "$local_app_name is running,pid:$pid"
      echo "变量信息:------"
      echo "idc:$local_idc"
      echo "env:$local_env"
      echo "local_host:$local_host"
      echo "java_Doption:$local_java_Doption"
      echo "java_option:$local_java_option"
      echo "local_app_name:$local_app_name"
      echo "local_app_type:$local_app_type"
      echo "logdir:$logdir"
      #检查日志目录，并清理历史日志
      #find $logdir -type f -mtime +0 |xargs rm -f {}
      #检查并运行log.io.client
      if [ $local_item != "none" ];then
         sh /home/wls81/shell/log.io.client.sh "start" ${local_appn_ame} ${local_item} ${local_env} ${local_idc} $logdir
      fi

     
   fi
   
   sleep 8
  
done

