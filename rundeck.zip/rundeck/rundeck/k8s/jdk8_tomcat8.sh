#!/bin/bash

local_host=$host
[ -z $local_host ] && local_host=none

local_idc=$idc
[ -z "$local_idc" ] && local_idc="default"

local_env="$env"
[ -z "$local_env" ] && local_env="pro"

local_java_Doption="$java_Doption"
[ -z "$local_java_Doption" ] && local_java_Doption=" "

local_java_option="$java_option"
[ -z "$local_java_option" ] && local_java_option=" "

local_app_name=$appname
unset cp 
if [ -z "$local_app_name" -o $local_app_name == "test" ];then 
 local_app_name="web"
fi

local_app_type=$apptype
[ -z "$local_app_type" ] && local_app_type="war"

#设置apollo
[ ! -d /opt/settings ] && mkdir -p /opt/settings
echo "idc=$local_idc" > /opt/settings/server.properties
echo "env=$local_env" >> /opt/settings/server.properties

#log dir
logdir="/data/${local_app_name}/logs"
[ ! -d $logdir ] && mkdir -p $logdir

#复制package到运行目录，设置pid_str
if [ $local_app_type == "war" ];then
   \cp -f  /home/wls81/package/${local_app_name}.$local_app_type /home/wls81/tomcat/webapps/
   pid_str="/home/wls81/tomcat/temp"
elif [ $local_app_type == "jar" ];then
   \cp -f  /home/wls81/package/${local_app_name}.$local_app_type /home/wls81/jarapp/
   pid_str="${local_app_name}.jar"
else
   pid_str="/home/wls81"
fi

#处理本地host映射
if [ $local_host != "none" ];then
   for host_str in $local_host
   do
      ip=`echo $host_str |awk -F : '{print $1}'`
      dname=`echo $host_str |awk -F : '{print $2}'`
      echo "$ip  $dname" >> /etc/hosts
   done
fi

#################################################################################

while true
do
   pid=$(ps -ef |grep -v grep |grep -E "$pid_str" |awk -F " " '{print $2}')
   if [ -z $pid ];then
      if [ $local_app_type == "war" ];then
         cd /home/wls81/tomcat/ || echo "error:can not cd /home/wls81/tomcat"
         [ -f ./bin/startup.sh ] && ./bin/startup.sh 2>&1 > /dev/null
         sleep 5
      else
         cd /home/wls81/jarapp/ || echo "error:can not cd /home/wls81/java"
         if [ -f ${local_app_name}.jar ];then
             nohup java $local_java_Doption -jar /home/wls81/jarapp/${local_app_name}.jar $local_java_option 2>&1 | /usr/local/sbin/cronolog $logdir/catalina.out.%Y-%m-%H.log >> /dev/null &
         else
             echo "${local_app_name}.jar is not exist"
         fi
      fi
  else
      echo "$local_app_name is running"
	  echo "vars:------"
	  echo "idc:$local_idc"
	  echo "env:$local_env"
	  echo "java_Doption:$local_java_Doption"
	  echo "java_option:$local_java_option"
	  echo "local_app_name:$local_app_name"
	  echo "local_app_type:$local_app_type"
          echo "logdir:$logdir"
   fi
   
   sleep 10
  
done

