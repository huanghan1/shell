#!/bin/bash
#当前的某个节点挂了或误删除了，需要重新加入集时，需要删除/etc/ansible/hosts文件中的这个节点的记录。
redisip=172.16.0.215

k8snodes=`/usr/local/bin/redis-cli keys k8snodes:*`

for key in $k8snodes
do
   #lable=`/usr/local/bin/redis-cli get $key`
   node_ip=`echo $key |awk -F : '{print $2}'`
   
   #查询
   statu=`kubectl get nodes |grep $node_ip |awk '{print $2}'`
   
   if [ -z $statu ];then
      cd /etc/ansible || exit 1
	  /usr/bin/easzctl add-node $node_ip
	  sleep 3
	  statu=`kubectl get nodes |grep $node_ip |awk '{print $2}'`
	  if [ $statu != "Ready" ];then
	     echo "easzctl 增加节点失败"
	  fi
	  
   else
      if [ $statu == "NotReady" ];then
        num=`ssh $node_ip "ps -ef |grep kube|grep -v grep  |wc -l"`
        if [ $num -eq 0 ];then
          kubectl delete  nodes/$node_ip
          echo "delete"
        fi
     fi
   fi
done

#删除NotReady的节点
#nodes=`/etc/ansible/bin/kubectl get nodes |grep -E "node|none" |grep NotReady|awk '{print $1}'`

#for node_ip in $nodes
#do  
#   usr/bin/easzctl del-node $node_ip
#   /etc/ansible/bin/kubectl delete  nodes/$node_ip
#done

#检测Ready节点
