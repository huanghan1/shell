#!/bin/bash
if [ ! $# -eq 5 ];then
    echo "Usage: cluster_name  appname env base_image update_image"
	exit 1
fi

cluster_name=$1
appname=$2
env=$3
base_image=$4
update_image=$5

#加载解析后的apollo配置文件
source  /tmp/apollconfig/$cluster_name/$appname/apollo_par.sh
#转小写
typeset -l  app_name
app_name=$appname
#集群节点名
[ -z "$nodes_name" ] && echo " nodes_name is null"

#images_url="registry-vpc.cn-shanghai.aliyuncs.com"
authstr="--docker-server=$images_url --docker-username=niehaiyong@xiaoniutech --docker-password=xn123456 --docker-email=niehaiyong@xiaoniu.com"
common_java_Doption="-server -XX:+UseConcMarkSweepGC -XX:CMSInitiatingOccupancyFraction=85 -XX:+CMSParallelRemarkEnabled -XX:+UseParNewGC -Xms1024m -Xmx1024m"
common_java_option="--server.port=8080"

#查询apollo里配置的启动参数
[ -z "$java_Doption" ] && java_Doption="$common_java_Doption"
[ -z "$java_option"  ] && java_option="$common_java_option"


cat << EOF > namespace.yml

apiVersion: v1
kind: Namespace
metadata:
   name: $cluster_name
   labels: 
     name: $cluster_name

EOF

configmap_name="$app_name"

#生成configmap.yaml
cat << EOF > ${appname}_configmap.yaml
kind: ConfigMap
apiVersion: v1
metadata:
  name: $configmap_name
  namespace: $cluster_name
  labels:
    software: $configmap_name
    project: $configmap_name
    app: $configmap_name
    version: v1
data:
  idc: "$app_idc"
  env: "$env"
  java_Doption: "$java_Doption"
  java_option: "$java_option"
EOF

#delete node docker images
cat << EOF > init_docker.sh
docker pull "$base_image"
docker tag "$base_image" "$update_image"
#image_id=\`docker images | grep $images_url | awk '{print \$3}'\`
#for id in \$image_id
#do
#  if [ -n "\${id}" ];then
#     docker rmi -f \$id
#  fi
#done
EOF
for node in $nodes_name 
do
  scp init_docker.sh $node:/tmp/
  ssh $node "sh /tmp/init_docker.sh"
done

#检查创建namespace
kubectl get namespaces |grep -q $cluster_name
if [ ! $? -eq 0 ];then
   kubectl create -f namespace.yml
   kubectl  create secret docker-registry $cluster_name -n $cluster_name $authstr
   if [ ! $? -eq 0 ];then
      echo "私有仓库授权失败" 
      exit 1
   fi
else
   kubectl get secret -n $cluster_name |grep -q $cluster_name
   flag=0
   if [ ! $? -eq 0 ];then
       kubectl  create secret docker-registry $cluster_name -n $cluster_name $authstr > /dev/null
       [ ! $? -eq 0 ] && flag=1 
   fi
   [ $flag -eq 1 ] && exit 1 
fi

#给集群节点打标签
echo "集群节点打标签"
kubectl get node -l "${app_name}_cluster=$cluster_name" -n $cluster_name 2>&1 |grep -q "No resources found"
if [ $? -eq 0 ];then
   flag=0
   for node in $nodes_name
   do
      kubectl label nodes $node ${app_name}_cluster=$cluster_name -n $cluster_name --overwrite=1
      if [ ! $? -eq 0 ];then
         echo "$node 创建标签 ${app_name}_cluster=$cluster_name  失败"
         flag=1
         break
      fi
   done
   [ $flag -eq 1 ] && exit 1
fi

#kubectl  get configMap -n $cluster_name 2>&1 |grep -q $configmap_name
#[ ! $? -eq 0 ] && kubectl apply -f ${appname}_configmap.yaml -n $cluster_name
echo "创建configmap"
kubectl apply -f ${appname}_configmap.yaml -n $cluster_name
if [ ! $? -eq 0 ];then
   echo "apply configmap false"
   cat ${appname}_configmap.yaml
   exit 1
fi
