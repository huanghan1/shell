#!/bin/bash
if [ ! $# -eq 4 ];then
   echo "Usage: cluster_name env appname branch_name"
   exit 1
fi

cluster_name=$1
env=$2
appname=$3
branch_name=$4

if [ $env == "dev" ];then
   apurl="http://apollo.51huihuahua.com:18081"
elif [ $env == "fat" ];then
   apurl="http://apollo.51huihuahua.com:18082"
elif [ $env == "uat" ];then
   apurl="http://apollo.51huihuahua.com:18083"
fi
#解析apollo配置参数
sh /data/shell2/shell/rundeck/apollo_getconfig.sh "$apurl" "$cluster_name" "$appname"
#加载解析后的apollo配置文件
source  /tmp/apollconfig/$cluster_name/$appname/apollo_par.sh

package_dir=${package_basedir}/${appname}/$branch_name

flag=0
cd $package_dir || flag=1
if [ $flag -eq 1 ];then
   echo "$package_dir 不存在"  
   exit 1
fi

if [ $type == "war" ];then
   docker_dir="/home/wls81/tomcat/webapps"
elif [ $type == "jar" ];then
   docker_dir="/home/wls81/java"
else
   echo "type 参数错误"
   exit 1
fi

#创建dockerfile
filename=${appname}.$type
cat << EOF > Dockerfile
from registry-vpc.cn-shanghai.aliyuncs.com/xn-test/xn-docker:java_tomcat8_v1
MAINTAINER niehaiyong@xiaoniu.com
workdir /home/wls81
ENV LANG=zh_CN.UTF-8 
env appname=$appname
env apptype=$type
COPY $filename ${docker_dir}/${appname}.$type
EOF

#开始构建应用容器
tagstr=$3
#大写转小写
typeset -l  app
app=$appname

#登录
HARBOR_IP="registry-vpc.cn-shanghai.aliyuncs.com"
REPOSITORIES="xn-test/${cluster_name}:$app"
HARBOR_USER="niehaiyong@xiaoniutech"
HARBOR_USER_PASSWD="xn123456"
docker login -u ${HARBOR_USER} -p ${HARBOR_USER_PASSWD} ${HARBOR_IP}

# Delete local  image early version.
IMAGE_ID=`docker images | grep ${REPOSITORIES} | awk '{print $3}'`
if [ -n "${IMAGE_ID}" ];then
    sudo docker rmi -f ${IMAGE_ID}
fi
 
# Build image.
tagstr="$env"
docker build -t ${HARBOR_IP}/${REPOSITORIES} . 
 
# Push to the harbor registry.
docker push ${HARBOR_IP}/${REPOSITORIES} 

