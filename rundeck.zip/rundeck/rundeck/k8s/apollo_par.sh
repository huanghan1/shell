type=jar
replicas=1
ifcreate_server:1
nodes_name="172.16.11.133 172.16.11.133"
java_Doption="-server -XX:+UseConcMarkSweepGC -XX:CMSInitiatingOccupancyFraction=85 -XX:+CMSParallelRemarkEnabled -XX:+UseParNewGC -Xms1024m -Xmx1024m"
java_option=none
package_basedir="/data/workspace/jar/fdd"
package_subdir_type="brach_name"
