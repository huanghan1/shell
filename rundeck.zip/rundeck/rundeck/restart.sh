#!/bin/bash

[[ $# != 1 ]] && echo "para error" && exit 1

function nginx_ser { 
   nginxp=/usr/local/nginx/sbin/nginx
   nginxd=/etc/init.d/nginx

   num=$($nginxp -t 2>&1 |grep "test is successful"|wc -l)
   [[ $num == 1 ]] && $nginxd restart 
   [[ $num == 0 ]]  && echo "config file error" && exit 1
   
  num=`/sbin/pidof nginx | wc -l`
  [[ $num != 0 ]] && echo "nginx restart successful" 
   
   
}

function zabbixd {
    systemctl restart zabbix-agent
    num=$(ps -ef  |grep "zabbix_agent" |grep -v "grep" |wc -l)
    [[ $num != 0 ]] && echo "zabbix-agent restart successful"
}

$1
