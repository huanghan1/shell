#!/bin/bash
#app_主干命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 trunk crmCenter yes test app_trunk

#app_分支命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 1.4.0 activityCenter no test app_branch

#风控命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 risk-parent_2.7 backendCenter no test risk

#催收命令行测试用例
#sh -x  /data/shell2/shell/rundeck/app_trunk.sh test02 receive receiveWebCenter no test receive
######################################################################
#定义项目对应的maven配置文件路径
#app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
#mset="/usr/local/maven-3.5.0/conf/voice_setting.xml"
mset="/usr/local/maven-3.5.0/conf/laizhejie_setting.xml"
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/tomcat/laizheje"
tom_dir="/home/wls81/tomcat"
jar_config_dir="/home/wls81/config/laizheje"
war_config_idr="/data/workspace/config"
workspace_dir="/data/workspace/laizheje"
#配置文件路
lzjdev_configdir="/data/workspace/config/lzjdev"
lzjtest01_configdir="/data/workspace/config/lzjtest01"
lzjpro_configdir="/data/workspace/config/lzjpro"

#定义环境对应的svn物理路径
#app 主干
loan_trunk="/root/.jenkins/workspace/laizheje/lending-loan-center"
#dir2="/root/.jenkins/workspace/laizheje/lending-loan-center"
api_trunk="/root/.jenkins/workspace/laizheje/lending-gj-api-center"
user_trunk="/root/.jenkins/workspace/laizheje/lending-user-center"
community_trunk="/root/.jenkins/workspace/laizheje/lending-community-center"
admin_trunk="/root/.jenkins/workspace/laizheje/lending-back-web"
lendingjob_trunk="/root/.jenkins/workspace/laizheje/lending-job"



######################################################################
#定义环境对应的ip
lzjdev="172.16.11.195"
lzjtest01="172.16.11.200"
lzjpro="172.16.0.191"

#定义环境密码
lzjdevX="dev"
lzjtest01X="qytest"
lzjproX="pro"

######################################################################

#定义项目的要target目录名
loanwar_target="lending-loan-center-web"
loanjar_target="lending-loan-center-biz"
apiwar_target="lending-gj-api-center-web"
apijar_target="lending-gj-api-center-biz"
userwar_target="lending-user-center-web"
userjar_target="lending-user-center-biz"
communitywar_target="lending-community-center-web"
communityjar_target="lending-community-center-biz"
apiscjar_target="lending-gj-api-sc-biz"
adminwar_target=""
lendingjob=""


#定义项目的要打包目录名
loanwar_build="lending-loan-center-web"
loanjar_build="lending-loan-center-biz"
apiwar_build="lending-gj-api-center-web"
apijar_build="lending-gj-api-center-biz"
userwar_build="lending-user-center-web"
userjar_build="lending-user-center-biz"
communitywar_build="lending-community-center-web"
communityjar_build="lending-community-center-biz"
apiscjar_build="lending-gj-api-sc-biz"
adminwar_build=""
lendingjob=""

#定义实例对应的端口
loanwarX=8083
loanjarX=8084
apiwarX=8085
apijarX=8086
userwarX=8087
userjarX=8088
communityjarX=8089
communitywarX=8090
apiscjarX=8091
adminwarX=8092
lendingjobX=8093

#定义应用类型
loanwar_type=war
loanjar_type=jar
apiwar_type=war
apijar_type=jar
userwar_type=war
userjar_type=jar
communityjar_type=jar
communitywar_type=war
apiscjar_type=jar
adminwar_type=war
lendingjob_type=jar


#包名
loanwar_filename=loanCenter.war
loanjar_filename=loanCenter.jar
apiwar_filename=gjapiCenter.war
apijar_filename=gjapiCenter.jar
userwar_filename=userCenter.war
userjar_filename=userCenter.jar
communityjar_filename=communityCenter.jar
communitywar_filename=lendingCommunityCenter.war
apiscjar_filename=gjapiSC.jar
adminwar_filename=lending-back-web.war
lendingjob_filename=lendingjob.jar
