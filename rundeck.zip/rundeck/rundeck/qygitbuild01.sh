#!/bin/bash
#svn://svn.xnshandai.net/shandai/trunk/loan-parent
unset cp 
to=$1
build_all=$2
projects=$3

######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/qygitparfile.sh
#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$${item}"
#dir1="${dir}/loan-api"

dir1="${dir}"
#eval dir1="\$${projects}_build"




echo ${parfile}
###############################main############################################################################################
NF=$(echo $projects | awk -F "," '{print NF}')

for x in `seq 1 $NF`
	do 
    	project=`echo $projects |awk -v d=$x -F "," '{ print $d }'`
        [ $project == "None" ] && echo "你选择了None" && exit 1
        sh /data/shell2/shell/rundeck/qygitshandai3.sh  $to $build_all $project 
        echo "################################################"
done
