#!/bin/bash

#########################################################################
#定义实例对应的端口
newsApi=9082  #jvm:2348
videoApi=9083  #jvm:2349
payApi=9084  #jvm:2345
systemApi=9085  #jvm:2350
activityApi=9086  #jvm:2352
community=8084  #jvm:
jobrule=8094  #jvm:2345
