
jobadmin=8086  #shutdown:8002 , jvm:2345
jobproft=8087  #jvm:2345
jobsys=8088  #jvm:2345
jobtrade=8089  #jvm:
jobmall=8090  #jvm:
jobnews=8091  #jvm:2345
