#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#svn://svn.xnshandai.net/shandai/trunk/loan-parent

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
projects=$4
create_pro_war=$5
authority=$6
item=$7
pinpoint=$8

######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/vgsangitparfile.sh
#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$${item}"
#dir1="${dir}/loan-api"
dir1="${dir}"


echo ${parfile}
###############################main############################################################################################
#判断密码
eval password="\$${to}X"
echo $test01X
echo ${to}X
echo ${authority}
echo $password
#echo $authority
if [[ ${authority} != ${password} ]];then
   echo "your password is error ................................................."
   exit 1
fi


#执行testall打包
fl=0
cd $dir || fl=1
[ $fl -eq 1 ] && echo "$dir 目录不存在" && exit 1

export BUILD_ID="mvn install"
#替换仓库master分支文件

if [ $build_all == "yes" ];then
   echo "开始构建全量war包....."
   echo "$mvnd --settings $msetting clean package -P${to} -Dmaven.test.skip=true"
   $mvnd --settings $msetting clean package -P${to} -Dmaven.test.skip=true
   #clean install package -Pdev 
   #$mvnd  clean install -Dmaven.test.skip=true
   [ ! $? -eq 0 ] && echo "全量构建失败" && exit 1
   echo "############################################################################################"
   echo "############################################################################################"
else
   echo "没有构建全量war包.....只对所选工程进行构建"
   echo "############################################################################################"
   echo "############################################################################################"
fi
######################################################

NF=$(echo $projects | awk -F "," '{print NF}')

for x in `seq 1 $NF`
	do 
    	project=`echo $projects |awk -v d=$x -F "," '{ print $d }'`
        [ $project == "None" ] && echo "你选择了None" && exit 1
        sh /data/shell2/shell/rundeck/vgsangitshandai2.sh  $to $bra_name $build_all $project $create_pro_war $item $pinpoint 
        #[ $? -eq 1 ] && echo "$project 部署失败" && exit 1
        echo "################################################"
        sleep 2
    done
#[ $fl -eq 1 ] && exit 1
