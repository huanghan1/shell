#!/bin/bash

if [ $# != 6 ];then
   echo "参数错误"
   exit 1
fi

pro_name=$1
app_name=$2
ser_port=$3
svn_dir=$4
app_type=$5
proxy=$6

#load config
script_dir=/data/shell2/shell/rundeck
. ${script_dir}/main_env.sh
tom_dir=/home/wls81/tomcat/${pro_name}
#copy dir
if [ ! -d $tom_dir ];then
    mkdir -pv $tom_dir
fi
cd $tom_dir
if [ -d $app_name ];then 
   echo  $tom_dir/$app_name"项目已经存在------"
   exit 1
fi
   port=`echo $ser_port | awk -F "," '{print $1}'`
   jvm_port=`echo $ser_port | awk -F "," '{print $2}'`
   if [ -f ${script_dir}/${pro_name}_port_env.sh ];then
       grep $app_name ${script_dir}/${pro_name}_port_env.sh 
       if [ $? -eq 0 ];then
           echo "${pro_name}_port_env.sh已经存在${app_name}"
           exit 1
       fi 
   fi

if [ $app_type == "war" ];then
   shutdown_port=`echo $ser_port | awk -F "," '{print $3}'`
   #copy dir
   unset cp
   cp -a ../common $app_name
   sed -i -r "s/(.*)6188(.*)/\1${shutdown_port}\2/"  ${app_name}/conf/server.xml
   sed -i -r "s/(.*)5188(.*)/\1${port}\2/"  ${app_name}/conf/server.xml
   echo "${app_name}=$port  #shutdown:$shutdown_port , jvm:$jvm_port" >> ${script_dir}/${pro_name}_port_env.sh
else
   #create dir
   mkdir -p $app_name
   
   #modify port_env.sh
   
   echo "${app_name}=$port  #jvm:$jvm_port" >> ${script_dir}/${pro_name}_port_env.sh
fi

#modify svndir_env.sh
echo "${app_name}=$svn_dir" >> ${script_dir}/${pro_name}_svndir_env.sh
#modify nginx
grep ${app_name} /tmp/location.txt >/dev/null

if [ $? -eq 0 ];then
   echo "----nginx的配置文件已经存在了"
   exit 1
fi

cat > /tmp/location.txt << EOF
location  /${app_name} { 
   proxy_set_header Host \$http_host;
   proxy_set_header REMOTE_ADDR \$remote_addr;
   proxy_set_header X-Real-IP \$remote_addr;
   proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
   proxy_pass http://${app_name};
}
EOF
       
cat > /tmp/upstream.conf << EOF
upstream ${app_name} {
   ip_hash;
   server 127.0.0.1:$port weight=10 max_fails=2  fail_timeout=20s;
}
EOF
cat /tmp/upstream.conf
cat /tmp/location.txt
fg=0
if [ $proxy == "yes" ];then
   eval ips="\${${pro_name}X[@]}"
   echo $ips
   for ip in $ips 
   do
       scp -P 20022 /tmp/location.txt $ip:/tmp/
       scp -P 20022 /tmp/upstream.conf $ip:/tmp/
       
       ssh -p 20022 $ip "cat /usr/local/nginx/conf/vhost/location.txt > /usr/local/nginx/conf/vhost/location.txt.bak"
       ssh -p 20022 $ip "cat /usr/local/nginx/conf/vhost/upstream.conf > /usr/local/nginx/conf/vhost/upstream.conf.bak"
       ssh -p 20022 $ip "cat /tmp/location.txt >> /usr/local/nginx/conf/vhost/location.txt"
       ssh -p 20022 $ip "cat /tmp/upstream.conf >> /usr/local/nginx/conf/vhost/upstream.conf"
       ssh -p 20022 $ip "cat /usr/local/nginx/conf/vhost/location.txt"
       ssh -p 20022 $ip "cat /usr/local/nginx/conf/vhost/upstream.conf"
       ssh -p 20022 $ip "/usr/local/nginx/sbin/nginx -t" 2>&1 |grep -q "syntax is ok"
       if [ $? -eq 0 ];then
           ssh -p 20022 $ip "/usr/local/nginx/sbin/nginx -s reload"
       else
          echo "$ip nginx config is error"
          fg=1
          echo "--------nginx配置文件回滚--------"
          rm -rf $tom_dir/$app_name
          sed -i "/^${app_name}.*/d" ${script_dir}/${pro_name}_svndir_env.sh 
          sed -i "/^${app_name}.*/d" ${script_dir}/${pro_name}_port_env.sh
          ssh -p 20022 $ip "cat /usr/local/nginx/conf/vhost/location.txt.bak > /usr/local/nginx/conf/vhost/location.txt"
          ssh -p 20022 $ip "cat /usr/local/nginx/conf/vhost/upstream.conf.bak > /usr/local/nginx/conf/vhost/upstream.conf"
          break
      fi
   done
     
fi
echo > /tmp/location.txt
exit 0
#[ $fg -eq 1 ] && exit 1

