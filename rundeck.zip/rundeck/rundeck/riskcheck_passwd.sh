#!/bin/bash

dev_pass=dev_123456
develop_pass=dev_123456
test_pass=test_123
master_pass=pro
mock_pass=pro
fat_pass=test_123
uat_pass=pro
pro_pass=pro
eval pass="\$${to}_pass"

if [ "$password" != "$pass" ];then 
   echo "#################password is error.....#############################"
   exit 1
fi     
