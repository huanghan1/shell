#!/bin/bash


To=$1
app=$2
passwd=$3
pinpoint=$4

mdev_pd="hhhhh"
mtest01_pd="xntest"
mpro_pd="pro"

eval pd="\$${To}_pd"

if [ $passwd != "$pd" ];then
   echo "your passwd is error...."
   exit
fi

hhhjobmessage=job-message
hhhjobmonitor=job-monitor
hhhjoboverdue=job-overdue
hhhjobpayment=job-payment
hhhjobdatapush=job-datapush

mgjobmessage=job-message
mgjobmonitor=job-monitor
mgjoboverdue=job-overdue
mgjobpayment=job-payment
mgjobdatapush=job-datapush
mgjobchannel=job-channel


eval app_dir="\$$app"

#dir=$3
mvnd=$(which mvn)
setting="/usr/local/maven-3.5.0/conf/shandaicaiwu_trunk_settings.xml"

#svn基准目录
svn_dir=/root/.jenkins/workspace/miaogou_xxxjob_git/XXLJob
pro_svn_dir=${svn_dir}/${app_dir}
wk_dir=/data/workspace/miaogou
pro_wk_dir=${wk_dir}/$app
#if [ ! -d "${pro_svn_dir}" ];then
#    mkdir -pv ${pro_svn_dir}
#fi

#exit 0

mdev_ip="172.16.11.196"
mtest02_ip="172.16.11.177"
mtest01_ip="172.16.11.187"
src_config_dir="/data/workspace/config/miaogou/${app}/$To"
dest_config_dir="/home/wls81/config/${app}/"
src_tom_dir="/home/wls81/miaogou/$app"
app_dir="/home/wls81/tomcat/$app/"

script_dir="/data/shell2/shell/rundeck/mmm_update.sh"

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
       mdev)
           unset cp
           echo "开始部署${app}的开发环境"
           #rsync -az -e "ssh -p 20022" $config_dir $hdev_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $mdev_ip:$script_dir
           rsync -az -e "ssh -p 20022" ${pro_wk_dir}/${app}_${To}.jar ${mdev_ip}:${app_dir}/${app}.jar
           ssh -p 20022 $hdev_ip "sh $script_dir $app $pinpoint"
           [ $? -eq 0 ] && exit 0

       ;;
       mtest02)
           unset cp
           echo "开始部署${app}的${To}环境....."
           rsync -az -e "ssh -p 20022" $src_config_dir/* $htest02_ip:$dest_config_dir/
           rsync -az -e "ssh -p 20022" $script_dir $htest02_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}_${To}.jar $htest02_ip:$app_dir
           ssh -p 20022 $htest02_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;


      mtest03)
           unset cp
           echo "开始部署${app}的测试环境....."
           rsync -az -e "ssh -p 20022" $config_dir $test03_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test03_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}_${To}.jar $test03_ip:$app_dir
           ssh -p 20022 $test03_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;
       mtest01)
           unset cp
           echo "测试环境....."
           [ ! -d $src_tom_dir ] && mkdir -p $src_tom_dir
           rsync -az -e "ssh -p 20022 " $src_tom_dir/ $mtest01_ip:$app_dir/
           rsync -az -e "ssh -p 20022" $src_config_dir/ $mtest01_ip:$dest_config_dir/
           rsync -az -e "ssh -p 20022" $script_dir $mtest01_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}_${To}.jar $mtest01_ip:${app_dir}/${app}.jar
           ssh -p 20022 $mtest01_ip "sh $script_dir $app $pinpoint"
           [ $? -eq 0 ] && exit 0
       ;;

      mpre|mpro)
           echo "Only create pro jar..."
       ;;
    esac
fi

