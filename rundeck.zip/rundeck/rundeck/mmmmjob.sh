#!/bin/bash

To=$1
app=$2
passwd=$3
pinpoint=$4
branch=$5

mdev_pd="hhhhh"
mtest01_pd="xntest"
mpro_pd="pro"

eval pd="\$${To}_pd"

if [ $passwd != "$pd" ];then
   echo "your passwd is error...."
   exit
fi


hhhjobmessage=job-message
hhhjobmonitor=job-monitor
hhhjoboverdue=job-overdue
hhhjobpayment=job-payment
hhhjobdatapush=job-datapush

eval app_dir="\$$app"

#dir=$3
mvnd=$(which mvn)
setting="/usr/local/maven-3.5.0/conf/shandaicaiwu_trunk_settings.xml"

#svn基准目录
svn_dir=/root/.jenkins/workspace/miaogou/$branch/XXLJob
pro_svn_dir=${svn_dir}/${app_dir}
wk_dir=/data/workspace/miaogou
pro_wk_dir=${wk_dir}/$app


if [ $app != "dataprope" ];then
  #mkdir -pv ${pro_svn_dir}
  cd ${pro_svn_dir} || exit 1
  #cd ${svn_dir} || exit 1
  echo "开始构建${app}。。。。"
  echo "############################################################################################"
  echo "############################################################################################"
  if [ $To == "pro" ];then
     #$mvnd clean  package install --settings $setting -P prod -Dmaven.test.skip=true
     $mvnd clean  package install  -Dmaven.test.skip=true
  else
     #$mvnd clean  package install --settings $setting -P test -Dmaven.test.skip=true
     $mvnd clean  package install  -Dmaven.test.skip=true
  fi
  num=$?
  echo "############################################################################################"
  echo "############################################################################################"
  echo "构建${app}完成，开始生成${app}.jar"

  if [ $num -eq 0 ];then
     #取得jar包文件名
     cd ${pro_svn_dir} || exit 1

     [ -d target ] && filedir=`find target -name "*.jar" `
     [ ! -z $filedir ] && jarfile=`basename $filedir ` 
     if [[ ! -f ${pro_svn_dir}/target/$jarfile ]];then
        echo "############################################################################################"
        echo "############################################################################################"
        echo "打包失败"
        echo "构建${app}失败,请找开发确定是否还有未提交的代码"
        exit 1
     else
       [ ! -d $pro_wk_dir ] && mkdir -p $pro_wk_dir
       if [ -d $pro_wk_dir ];then
	  src_dir="${pro_svn_dir}/target/$jarfile"
	  #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
          unset cp
	  cp -f $src_dir  ${pro_wk_dir}/$app.jar

	  if [[ ! $? -eq 0 ]];then
		 echo "转移${app}的jar包失败"
		 exit 1
	  else
                  sleep 2
                  echo "############################################################################################"
		  echo "创建${app}.jar成功，生成md5.....记录时间...."
		  cd $pro_wk_dir || exit 1
		  sha256=$(sha256sum ${app}.jar | awk '{print $1}')
		  if [ ! -z $sha256 ];then
			 echo $sha256 > sha256.txt
		  else
			 echo "error" > sha256.txt
			 echo "md5值生成失败"
			 exit 1
		  fi
		  d=$(date +%Y-%m-%d_%H:%M)
		  echo $d  > time

	  fi
          echo "############################################################################################"
          echo "构建${app}完成."
          echo "############################################################################################"
        else
	  echo "${dir2}$appn 目录不存在"
	  exit 1
        fi
     fi
  else
     echo "构建失败"
     exit 1
  fi

fi
#exit 0

dev_ip="106.15.48.19"
mtest01_ip="172.16.11.187"
src_config_dir="/data/workspace/config/miaogou/${app}/$To"
dest_config_dir="/home/wls81/config/${app}/"
src_tom_dir="/home/wls81/miaogou/$app"
app_dir="/home/wls81/tomcat/$app/"

script_dir="/data/shell2/shell/rundeck/mmm_update.sh"

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
       test03)
           unset cp
           echo "开始部署${app}的测试环境....."
           rsync -az -e "ssh -p 20022" $config_dir $test03_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test03_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $test03_ip:$app_dir
           ssh -p 20022 $test03_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;
       mtest01)
           unset cp
           echo "测试环境....."
           [ ! -d $src_tom_dir ] && mkdir -p $src_tom_dir
           rsync -az -e "ssh -p 20022 " $src_tom_dir/ $mtest01_ip:$app_dir/
           rsync -az -e "ssh -p 20022" $src_config_dir/ $mtest01_ip:$dest_config_dir/
           rsync -az -e "ssh -p 20022" $script_dir $mtest01_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $mtest01_ip:$app_dir
           ssh -p 20022 $mtest01_ip "sh $script_dir $app $pinpoint"
           [ $? -eq 0 ] && exit 0
       ;;

       mpro)
           echo "Only create pro jar..."
       ;;
    esac
fi

