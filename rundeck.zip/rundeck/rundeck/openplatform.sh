#!/bin/bash

if [ $# != 3 ];then
  echo "参数错误"
  exit 1
fi

To=$1
app=$2
dir=$3
mvnd=$(which mvn)
setting="/usr/local/maven-3.5.0/conf/bigdata_settings.xml"

#svn基准目录
svn_dir=/root/.jenkins/workspace/openplatform
pro_svn_dir=${svn_dir}/$app/$dir
wk_dir=/data/workspace/jar
pro_wk_dir=${wk_dir}/$app


if [ $app != "dataprope" ];then
  cd ${pro_svn_dir} || exit 1
  echo "开始构建${app}。。。。"
  echo "############################################################################################"
  echo "############################################################################################"

  $mvnd clean  package install --settings $setting -P test -Dmaven.test.skip=true

  echo "############################################################################################"
  echo "############################################################################################"
  echo "构建${app}完成，开始生成${app}.jar"

  if [ $? -eq 0 ];then
     #取得jar包文件名
     [ -d target ] && filedir=`find target -name "*.jar" `
     [ ! -z $filedir ] && jarfile=`basename $filedir ` 
     if [[ ! -f ${pro_svn_dir}/target/$jarfile ]];then
        echo "############################################################################################"
        echo "############################################################################################"
        echo "打包失败"
        echo "构建${app}失败,请找开发确定是否还有未提交的代码"
        exit 1
     else
       [ ! -d $pro_wk_dir ] && mkdir -p $pro_wk_dir
       if [ -d $pro_wk_dir ];then
	  src_dir="${pro_svn_dir}/target/$jarfile"
	  #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
          unset cp
	  cp -f $src_dir  ${pro_wk_dir}/$app.jar

	  if [[ ! $? -eq 0 ]];then
		 echo "转移${app}的jar包失败"
		 exit 1
	  else
                  sleep 2
                  echo "############################################################################################"
		  echo "创建${app}.jar成功，生成md5.....记录时间...."
		  cd $pro_wk_dir || exit 1
		  sha256=$(sha256sum ${app}.jar | awk '{print $1}')
		  if [ ! -z $sha256 ];then
			 echo $sha256 > sha256.txt
		  else
			 echo "error" > sha256.txt
			 echo "md5值生成失败"
			 exit 1
		  fi
		  d=$(date +%Y-%m-%d_%H:%M)
		  echo $d  > time

	  fi
          echo "############################################################################################"
          echo "构建${app}完成."
          echo "############################################################################################"
        else
	  echo "${dir2}$appn 目录不存在"
	  exit 1
        fi
     fi
  else
     echo "构建失败"
     exit 1
  fi

fi



bigdata_t01_ip="172.16.11.137"
config_dir="/data/workspace/config/bigdata/openxn/${app}/"
app_dir="/home/wls81/openxn/$app/"
script_dir="/data/shell2/shell/rundeck/bigdata_jar_update.sh"

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
       bigdata-test01)
           unset cp
           echo "开始部署${app}的测试环境....."
           rsync -az -e "ssh -p 22" $config_dir $bigdata_t01_ip:$app_dir
           rsync -az -e "ssh -p 22" $script_dir $bigdata_t01_ip:$script_dir
           scp -P 22 ${pro_wk_dir}/$app.jar $bigdata_t01_ip:$app_dir
           ssh -p 22 $bigdata_t01_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;
       test02)
           unset cp
           echo "测试环境....."
           rsync -az -e "ssh -p 20022" /data/workspace/config/shanDaiBiz/ $ip3:/data/workspace/config/shanDaiBiz/
           scp -P 20022 ${dir2}/${appn}/${appn}.jar $ip3:$dir22
           rsync -az -e "ssh -p 20022" /data/shell/jar_update.sh $ip3:/data/shell/jar_updata.sh
           ssh -p20022 $ip2 "sh /data/shell/jar_update.sh $appn"

       ;;

       pro)
           echo "Only create pre war..."
       ;;
    esac
fi

