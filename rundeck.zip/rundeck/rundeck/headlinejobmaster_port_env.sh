jobadmin=8092  #shutdown:8001 , jvm:2345
