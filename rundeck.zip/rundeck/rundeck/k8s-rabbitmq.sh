item=$1
appname=$2
env=$3
idc=$4
workdir=/data/workspace/$item/$appname/$env/$idc/
[ ! -d $workdir ] && mkdir -pv $workdir
#k8s命名空间配置 and 数据挂载目录
ns=${item}-${env}-${idc}
datadir="/data/logs/$item/$appname/$env/$idc"
redis="/data/redis"
mongodb="/data/mongodb"
rabbitmq="/var/lib/rabbitmq/mnesia"
emq="/var/log/emqx"
zookeeper="/home/wls81/tomcat/zookeeper/data/"

eval cdata="\$$appname"
echo $cdata
#判断是否是压测环境
if [ $if_pressure == "yes" ];then
  ns=${ns}-pressure
  datadir=${logdir}-pressure
fi

#端口
appnames=${item}_${appname}_${env}_${idc}
echo $appnames
app_port=`curl -sSL "http://apollo.51huihuahua.com:8080/configfiles/json/xiaoniu-app-port-type/default/application?ip=192.168.1.248" |jq .$appnames | awk '{print $1}' |sed -n 's/\"//gp'`
echo $app_port

app_type=`curl -sSL "http://apollo.51huihuahua.com:8080/configfiles/json/xiaoniu-app-port-type/default/application?ip=192.168.1.248" |jq .${appnames}_type|sed -n 's/\"//gp'`
[ -z $app_type ] && app_type=none

if [ "$app_port" == "none" -a "$app_type" == "none" ];then
   echo "port or app_type 没有配置在xiaoniu-app-port-type"
   exit 1
fi
port=`echo $app_port |awk -F '[:]' '{print $1}'`
nodeport=`echo $app_port |awk -F '[:]' '{print $2}'`
echo "$app_type,$app_port"



#harbor_url
harbor_url="172.16.0.175:18080"
#k8s访问harbor仓库认证用的参数
authstr="--docker-server=http://$harbor_url --docker-username=admin --docker-password=admin_123 --docker-email=niehaiyong@xiaoniu.com"
#镜像仓库url,k8s部署使用
if [ ${appname} == emq ];then
   image_url="$harbor_url/common/${appname}:v3.2.1"
else
   image_url="$harbor_url/common/${appname}:v2"
fi
#image_url="$harbor_url/common/centos8888:v1"

cd $workdir
#创建namespace，检查并创建
cat << EOF > namespace.yml
apiVersion: v1
kind: Namespace
metadata:
   name: $ns
   labels: 
     name: $ns

EOF
#检查namespace是否存在
kubectl get namespaces |grep -q $ns
if [ ! $? -eq 0 ];then
   kubectl create -f namespace.yml
fi
#检查k8s对仓库的授权
kubectl get secret -n $ns |grep -q $item
if [ ! $? -eq 0 ];then
   kubectl create secret docker-registry $item -n $ns $authstr > /dev/null
   if [ ! $? -eq 0 ];then
      echo "私有harbor仓库授权认证创建失败"
      exit 1
   fi
fi

echo "k8s开始部署 ${appname}_deployment.yaml"
cat >${appname}_deployment.yaml << EOF
apiVersion: apps/v1beta1
kind: Deployment
metadata:
  name: $appname
  namespace: $ns
  labels:
    name: $appname
spec:
  replicas: 1
  template:
    metadata:
      labels:
        name: $appname
    spec:
      imagePullSecrets:
      - name: $item
      containers:
      - image: $image_url
        name: $appname
        ports:
        - containerPort: $port
        volumeMounts:
        - mountPath: $cdata
          name: data
      volumes:
      - name: data
        hostPath:
         path: $datadir
EOF

kubectl apply -f ${appname}_deployment.yaml -n $ns
if [ ! $? -eq 0 ];then
  echo "创建${appname}_deployment 失败"
  exit 1
fi


#创建${appname}_svc.yaml,对外服务访问
echo "开始应用 ${appname}_svc.yaml"
cat > ${appname}_svc.yaml <<EOF
kind: Service
apiVersion: v1
metadata:
  name: $appname
  namespace: $ns
spec:
  selector:
    name: $appname
  ports:
    - protocol: TCP
      port: $port
      targetPort: $port
      nodePort: $nodeport
      name: $appname
    - protocol: TCP
      port: 5672
      targetPort: 5672
      nodePort: 35674
      name: rabbitmq-35674
  type: NodePort

EOF

kubectl apply -f ${appname}_svc.yaml -n $ns
if [ ! $? -eq 0 ];then
  echo "创建svc 失败"
  exit 1
fi

echo "k8s完成部署"
