#!/bin/bash

dev_pass=dev
develop_pass=dev
test_pass=qytest
master_pass=pro
mock_pass=pro
fat_pass=qytest
uat_pass=pro

eval pass="\$${branch}_pass"

if [ "$password" != "$pass" ];then 
   echo "#################password is error.....#############################"
   exit 1
fi     
