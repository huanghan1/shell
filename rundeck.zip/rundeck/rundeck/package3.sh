#!/bin/bash

if [ $# != 1 ];then
   echo "Usage:$0 输入实例名"
   exit 1
fi

appn=$1
src="/data/maven/repository/com/honglu/loan"
src2="/data/maven/repository/com/honglu/batch"
dest="/data/workspace/war"
d=$(date +%Y-%m-%d_%H:%M)


cd ${dest}/$appn || exit 1
rm -rf ${dest}/${appn}/*


function modify_config {
	config_dir="/data/workspace/config"
        [ ! -d tmp ] && mkdir tmp
	cd tmp ||exit 10
        if [ -f ${appn}.war ];then
		  jar -xf ${appn}.war 
		  unset cp
                  if [ $appn == "crmCenter" ];then
			cp -f ${config_dir}/${appn}/resource/* WEB-INF/classes/
			[ $? -eq 0 ] && rm -f ${appn}.war || exit 16
			#cp -f ${config_dir}/${appn}/js/* commons/
			#[ $? -eq 0 ] && rm -f ${appn}.war || exit 17
                  
                  else
		  	cp -f ${config_dir}/${appn}/* WEB-INF/classes/

		  	[ $? -eq 0 ] && rm -f ${appn}.war || exit 12
		  fi

		  jar -cf ${appn}.war ./*
		  [ ! $? -eq 0 ] && exit 14
                  [ -f ${appn}.war ] && mv ${appn}.war ../ || exit 18
                  		  
		  cd .. || exit 13
		  sha256=$(sha256sum ${appn}.war | awk '{print $1}')
		  if [ ! -z $sha256 ];then
			 echo $sha256 > sha256.txt
		  else
			 echo "error" > sha256.txt
		  fi
		  echo $d  > time
	else
		  echo "拉不到war包"
		  exit 15
	fi
	
	  
	  
}

#定义实例对应的端口

       #_port=(8009 8010 8011 8012 8013 8014 8015 8016 8017 8018 8019 8020)
       #_port=(2345 2346 2347 2348 2349 2350 2351 2352 2353 2354 2355 2356)
instance_port=(8083 8084 8085 8086 8087 8088 8089 8090 8091 8092 8093 8094)

#根据输入的实例名以及上面定义的端口数组来获得实例的tom_pid 并记录对应的端口号port
case  ${appn} in
		       
                authCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-authCenter-api/0.0.1-SNAPSHOT/loan-authCenter-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config
                ;;

                userCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-user-api/0.0.1-SNAPSHOT/loan-user-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;

                backendCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-backend-web/0.0.1-SNAPSHOT/loan-backend-web-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;
                backendtaskCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-backend-task/0.0.1-SNAPSHOT/loan-backend-task-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;

                messageCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-message-api/0.0.1-SNAPSHOT/loan-message-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;

                activityCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-activity-api/0.0.1-SNAPSHOT/loan-activity-api-0.0.1-SNAPSHOT.war tmp/${appn}.war
						  #用生产配置覆盖测试配置
						  modify_config

                ;;
			
	        debitapiCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-debit-api/0.0.1-SNAPSHOT/loan-debit-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;

                debitserviceCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-debit-service-api/0.0.1-SNAPSHOT/loan-debit-service-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config
                ;;
				
	        payCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-pay-api/0.0.1-SNAPSHOT/loan-pay-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;
	        bankCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-bank-api/0.0.1-SNAPSHOT/loan-bank-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config
                ;;
	        payserviceCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan-pay-service-api/0.0.1-SNAPSHOT/loan-pay-service-api-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;
                crmCenter)
						  [ ! -d tmp ] && mkdir tmp
						  cp ${src}/loan_crm_web/0.0.1-SNAPSHOT/loan_crm_web-0.0.1-SNAPSHOT.war tmp/${appn}.war

						  #用生产配置覆盖测试配置
						  modify_config

                ;;
               honglu-batch)
                                                  [ ! -d tmp ] && mkdir tmp
                                                  cp ${src2}/honglu-batch/1.0.0-RELEASE/honglu-batch-1.0.0-RELEASE.war tmp/${appn}.war

                                                  #用生产配置覆盖测试配置
                                                  modify_config
	      ;;


                *)
                    echo "tomcat实例名不正确"
                    exit 1
                ;;

esac

