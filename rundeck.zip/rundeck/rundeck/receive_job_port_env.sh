rejobadmin=8119  #shutdown:8045 , jvm:2381
rejoballot=9091  #jvm:4761
rejoborder=9092  #jvm:4762
rejobsystem=9093  #jvm:4763
