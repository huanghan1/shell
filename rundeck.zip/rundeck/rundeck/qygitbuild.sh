#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#svn://svn.xnshandai.net/shandai/trunk/loan-parent

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
projects=$4
create_pro_war=$5
authority=$6
item=$7
pinpoint=$8

######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/qygitparfile.sh
#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$${item}"
#dir1="${dir}/loan-api"

dir1="${dir}"
#eval dir1="\$${projects}_build"




echo ${parfile}
###############################main############################################################################################
#判断密码
eval password="\$${to}X"
#echo $authority
if [[ ${authority} != ${password} ]];then
   if [ $build_all == "copy_测试包_to_生产包" ];then
      if [ "$authority" == "pro" ];then
         echo "password ok"
      else
         echo "your password is error ................................................."
         exit 1
      fi
   fi
fi

#复制测试包成生产包
if [ $build_all == "copy_测试包_to_生产包" -a $to != "vpro" ];then
   echo "$build_all"
   NF=$(echo $projects | awk -F "," '{print NF}')
   for x in `seq 1 $NF`
   do
       project=`echo $projects |awk -v d=$x -F "," '{ print $d }'`
       [ $project == "None" ] && echo "你选择了None" && exit 1
       #应用类型
       eval type="\$${project}_type"
       filename=${project}_${to}.${type}
       cd ${workspace_dir}/$project || exit 1

       if [ $create_pro_war == "yes" ];then
          unset cp
          #应用类型
          eval type="\$${project}_type"
          \cp -f $filename ${project}.${type}
          echo "只生成vpro环境包，不部署..."
          t1sha=`sha256sum ${project}.${type} | awk '{print $1}'`
          echo $t1sha > sha256.txt
          timetxt=`date +"%Y-%m-%d-%H"`
          echo $timetxt > time
          echo "$bra_name" > version
          chown -R wls81.wls81 ${workspace_dir}/$project
       else
          echo " create_pro_war 不等于 yes"
       fi
   done
   exit 0 
fi
#####################


#执行testall打包
fl=0
cd $dir || fl=1
[ $fl -eq 1 ] && echo "$dir 目录不存在" && exit 1
export BUILD_ID="mvn install"
#替换仓库master分支文件

if [ $build_all == "yes" ];then
   echo "开始构建全量war包....."
   echo "$mvnd --settings $msetting clean package -P${to} -Dmaven.test.skip=true"
   $mvnd --settings $msetting clean package -P${to} -Dmaven.test.skip=true
   #clean install package -Pdev 
   #$mvnd  clean install -Dmaven.test.skip=true
   [ ! $? -eq 0 ] && echo "全量构建失败" && exit 1
   echo "############################################################################################"
   echo "############################################################################################"
else
   echo "没有构建全量war包.....只对所选工程进行构建"
   echo "############################################################################################"
   echo "############################################################################################"
fi
######################################################

NF=$(echo $projects | awk -F "," '{print NF}')

if [ $to == "vhd" ];then
     to=vpro
fi 
for x in `seq 1 $NF`
	do 
    	project=`echo $projects |awk -v d=$x -F "," '{ print $d }'`
        [ $project == "None" ] && echo "你选择了None" && exit 1
        sh /data/shell2/shell/rundeck/qygitshandai2.sh  $to $bra_name $build_all $project $create_pro_war $item $pinpoint 
        #[ $? -eq 1 ] && echo "$project 部署失败" && exit 1
        echo "################################################"
        sleep 2
    done
#[ $fl -eq 1 ] && exit 1
