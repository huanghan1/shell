#!/bin/bash

######################################################################
#定义项目的要svn目录名
user=athletics-user/athletics-user-api
message=athletics-message/athletics-message-api
trade=athletics-trade/athletics-trade-api
community=athletics-community/athletics-community-api
mall=athletics-mall/athletics-mall-api
spback=athletics-back
activity=athletics-activity/athletics-activity-api
activitymq=athletics-activity/athletics-activity-mq
