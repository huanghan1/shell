function aa {
	echo 1
        exit 10
}

t=$(aa)
echo "aa:$t"
a="fdf-ff"


eval d="\\$$a"
echo $d
