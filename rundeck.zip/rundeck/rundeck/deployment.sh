#!/bin/bash
if [ ! $# -eq 3 ];then
   echo "Usage: cluster_name appname env "
   exit 1
fi

cluster_name=$1
appname=$2
env=$3

#加载解析后的apollo配置文件
source  /tmp/apollconfig/$cluster_name/$appname/apollo_par.sh

logdir="/data/$appname/logs"
#转小写
typeset -l  app_name
app_name=$appname


#查询apollo的副本配置
[ -z $replicas ] && replicas=1

#查询apollo里配置的是否需要需要配置k8s的server
[ -z $ifcreate_server ] && ifcreate_server=0

#查询apollo里配置的port
if [ -z $node_port ];then
   node_port=`curl -sSL "http://apollo.51huihuahua.com:8089/configfiles/json/huihuahua-app-port/default/application?ip=192.168.1.248" |jq .${appname} | awk '{print $1}' |sed -n 's/\"//gp'`  
   if [ -z $node_port ] ;then
      echo "node_port 没有配置"
      exit 1
   fi
fi

#查询apollo里配置的type
if [ -z $type ];then
   type=`curl -sSL "http://apollo.51huihuahua.com:8089/configfiles/json/huihuahua-app-type/default/application?ip=192.168.1.248" |jq .${appname}_type | awk '{print $1}' |sed -n 's/\"//gp'`  
   if [ -z $type ];then
      echo "type 没有配置"
      exit 1
   fi
fi

#查询apollo里配置的要部署的集群机器的名字
if [ -z "$nodes_name" ];then
   echo "nodes_name 没有配置"
   exit 1
fi


#configmap的名字
configmap_name=${app_name}
#镜像地址
base_image="registry-vpc.cn-shanghai.aliyuncs.com/xn-test/${cluster_name}:${app_name}"
update_image=${base_image}_$(date +"%Y-%m-%d-%H-%M")

#查询k8s集群中是否有上面apollo中配置的节点,并创建日志目录
for node in $node_name
do
  kubectl get node 2>&1 | grep -q "$node"
  if [ ! $? -eq 0 ];then
     echo "$node 不在k8s的节点列表中"
     exit 1
  else
     ssh $node "[ ! -d $logdir  ] && mkdir -p $logdir"
  fi
done

#调用k8s初始化namespace、 镜像授权 、configmap,node上的本地镜像
sh /data/shell2/shell/rundeck/k8s_namespace_init.sh $cluster_name $appname $env "$base_image" "$update_image"
if [ ! $? -eq 0 ];then
   echo "k8s初始化 false"
   exit 1
fi
#开始部署
echo "#生成k8s 的deployment类型文件"
cat << EOF > ${appname}_deployment.yaml
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  namespace: $cluster_name
  name: $app_name
  labels:
    name: $app_name
spec:
  replicas: $replicas
  template:
    metadata:
      labels:
        app: $app_name
    spec:
      nodeSelector:
        ${app_name}_cluster: $cluster_name
      imagePullSecrets:
      - name: $cluster_name
      containers:
      - name: $app_name
        image: $update_image
        ports:
        - containerPort: 8080  
        envFrom:
        - configMapRef:
            name: $configmap_name
        volumeMounts:
        - mountPath: $logdir
          name: logs
      volumes:
      - name: logs
        hostPath:
          path: $logdir

EOF

#配置server
if [ $ifcreate_server -eq 1 ];then
cat << EOF > ${appname}_svc.yaml
apiVersion: v1
kind: Service
metadata:
  namespace: $proj
  name: $app_name
spec:
  type: NodePort
  ports:
    - port: 8080 
      targetPort: 8080
      nodePort: 2$node_port
  selector:
    app: $app_name
EOF

fi

#查询k8s中应用对应的deployment
kubectl get deployment -n $cluster_name 2>&1 |grep -q -E "\<$app_name\>"
if [ ! $? -eq 0 ];then
  echo "开始创建$app_name 的 deployment"
  #实例化这个部署
  kubectl apply -f ${appname}_deployment.yaml -n $cluster_name
  
fi

#查询k8s中server
if [ $ifcreate_server -eq 1 ];then
   kubectl get svc -n $proj 2>&1 | grep -q -E "\<$app_name\>"
   #是否创建server
   if [ ! $? -eq 0 ];then
      echo "开始创建server"
      kubectl apply -f ${appname}_svc.yaml -n $cluster_name
   fi
   
fi

