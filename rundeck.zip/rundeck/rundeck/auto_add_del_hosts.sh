#!/bin/bash
#自动增加信息到hosts、rundeck、ansible
sh /data/shell2/shell/cron/auto_add_hosts_rundeck_ansible.sh
#自动删除信息hosts、rundeck、ansible
sh /data/shell2/shell/cron/auto_del_hosts_rundeck_ansible.sh
