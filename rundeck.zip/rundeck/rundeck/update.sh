#!/bin/bash
. /etc/profile
if [[ $# != 2 ]];then
  echo "Usage: 实例名 update|roll-back"
  exit 1
fi


app=$1
operation=$2

dir=/home/wls81/tomcat/$app/conf/logging.properties

cd /home/wls81/tomcat/$app || exit 1

##################################################################################
##################################################################################
pid=`ps -ef | grep "${dir}" | grep -v "grep" | awk '{print $2}'`
#关闭
[ ! -z $pid ] && bin/shutdown.sh 
sleep 2

#################################################################################
#备份当前的正在使用的war包
if [[ $operation == "update" ]];then
	d=`date +%Y-%m-%d:%H:%M`
	unset cp
	[ ! -d backup/$app ] && mkdir -p backup/$app
	[ -f webapps/${app}.war ] && cp -f webapps/${app}.war backup/${app}/${app}_${d}.war
	echo 
	#删除备份目录下30天前的包
        find backup/$app -mtime +3 -type f -name "*.war" |xargs rm -rf {} 
fi
##################################################################################
#关闭实例后检查是否成功关闭，及清空目录

for pid in `ps -ef | grep  "${dir}" | grep -v "grep"| awk '{print $2}'`
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
   
    kill -9 $pid 2>/dev/null
done


#[ -f ${app}.war ] &&  rm -rf webapps/${app}.war
[ -f ${app}.war ] && rm -rf webapps/$app
[ ! -f ${app}.war ] && echo "${dir}目录下不存在${app}.war文件,当前只会完成清空work目录并重启的操作"


rm -rf work/* 

pid=`ps -ef | grep "${dir}" | grep -v "grep" | awk '{print $2}'`
[ -z $pid ] && echo "$app 关闭成功"
[ ! -z $pid ] && echo "$app 关闭失败" && exit 1
######################################################################
#移动war文件到webapps目录
unset mv 
[ -f ${app}.war ] && mv -f ${app}.war webapps/
chown -R wls81.wls81 webapps

#启动
echo "等待系统启动成功，可能需要几分钟."
[ -z $pid ] && su wls81 bin/startup.sh 
sleep 2
######################################################################

#

sleep 5 
script_path=$(dirname $0)

#url请求验证
[ -f ${script_path}/check_url.sh ] && sh ${script_path}/check_url.sh $app

[[ $? -eq 0 ]] && echo "http请求成功" 
[[ $? -eq 0 ]] && echo  "$app 启动成功"  && exit 0
[[ $? != 0 ]] && echo "http请求失败" 
[[ $? !=  0 ]] &&echo " $app 启动失败" 
[[ $? !=  0 ]] && exit 1


#pid=`ps -ef | grep -E "${dir}" | grep -v "grep" | awk '{print $2}'`
#echo $pid

#if [[ ! -z $pid ]];then
#  if [[ $code -eq 200 ]];then
#    echo  "$app 启动成功 " 
#    exit 0
#  fi
#fi

#[ -z $pid ] && echo " $app 启动失败" &&  exit 1

 

 
###################################################################


