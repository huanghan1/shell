#!/bin/bash
app=$1
type=$2
options=$3

dir=/home/wls81/tomcat/$app
spideragent="cn.robot.axes.core.LogicEngine"
spiderconsumer="cn.my.gw.client.RabbitCustomConsumer"
spiderserver="cn.my.gw.server.Server"
spiderseeds="com.spider.crawl.SpiderAll"
. /etc/profile
cronlog="/usr/local/sbin/cronolog"
log1="/data/${app}/logs/configuration.out.%Y-%m-%d-%H.log"
log="/data/${app}/logs/catalina.out.%Y-%m-%d-%H.log"
jar_start="java -server -XX:+UseConcMarkSweepGC -XX:CMSInitiatingOccupancyFraction=85 -XX:+CMSParallelRemarkEnabled -XX:+UseParNewGC -Xms1024m -Xmx1024m -jar ${dir}/${app}.jar 2>&1 | $cronlog $log &"


chown -R wls81.wls81 $dir
[ ! -d /data/$app/logs ] && mkdir -p /data/$app/logs
[ -d /data/$app ] && chown -R wls81.wls81 /data/$app
cd $dir || exit 1 

ignore_pid=$$
ignore_ppid=`ps -ef | awk -v pid="$$" '{if($2==pid) print $3}'`
if [ ${type} == "jar" ];then
for pid in `ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}'`
do
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
    if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
    then
        continue
    fi
    kill -9 $pid 2>/dev/null
done

pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')
if [  -z $pid ];then
  echo "$app closed successful"
else
  echo "$app closed false"
  exit 1
fi

unset mv 
if [ -f $dir/${app}.jar ];then
   su wls81 -c "nohup $jar_start"

   sleep 5 
   #echo "启动检验............"
   pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')

   if [ -z $pid ] ;then
      echo "$app start false"
      exit 1
   else
      sleep 1
      echo "pid:$pid"
      echo "$app start sucessful"
      curl -sSL http://127.0.0.1:15001/eastday/spider 2>/dev/null
      exit 0
   fi

else
   echo "$dir目录下没有jar包"
   exit 1
fi
else
eval p="\$${app}"



#############
for pid in `ps -ef | grep -E $p |grep -v "grep" | awk '{print $2}'`
do
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
    if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
    then
        continue
    fi
    kill -9 $pid 2>/dev/null
done
echo "################################################"
if [ "$options" == "stop" ];then
    echo "###############################关闭$app###########################"
    exit 0
fi
pid=$(ps -ef | grep -E $p |grep -v "grep" | awk '{print $2}')
if [  -z $pid ];then
  echo "$app closed successful"
else
  echo "$app closed false"
  exit 1
fi

unset unzip 
if [ -f ${app}.sh ];then
   su wls81 -c "nohup sh $dir/${app}.sh 2>&1 | $cronlog $log &"

   sleep 5 
   #echo "启动检验............"
   pid=$(ps -ef | grep -E $p |grep -v "grep" | awk '{print $2}')

   if [ -z $pid ] ;then
      echo "$app start false"
      exit 1
   else
      sleep 1
      echo "pid:$pid"
      echo "$app start sucessful"
   fi

else
   echo "$dir目录下没有zip包"
   exit 1
fi
fi

