#!/bin/bash
. /etc/profile
if [[ $# != 1 || $1 == None ]];then
  echo "Usage:$0 实例名 "
  exit 1
fi

app=$1

dir=/home/wls81/tomcat/$app

cd $dir || exit 1
chown -R wls81.wls81 $dir
[ ! -d webapps ] && mkdir webapps 2>&1 > /dev/null && chown wls81.wls81 webapps
[ ! -d work ] && mkdir work 2>&1 > /dev/null && chown wls81.wls81 work
[ ! -d temp ] && mkdir temp 2>&1 > /dev/null && chown wls81.wls81 temp
[ ! -d logs ] && mkdir logs 2>&1 > /dev/null && chown wls81.wls81 logs

#################################################################################
#加载实例对应的端口配置
parfile=`dirname $0`
. ${parfile}/parfile.sh

echo $app | grep -q "-"
[ $? -eq 0 ] && appn=`echo $app | sed -n 's/-//gp'`
[ -z $appn ] && appn=$app

eval port="\$${appn}X"

echo "$app的port:$port"
http="http://127.0.0.1:${port}/${app}/index.jsp"


##################################################################################
pid=`ps -ef | grep "${dir}" | grep -v "grep" | awk '{print $2}'`
[[ ! -z $pid ]] && bin/shutdown.sh 
sleep 2

#################################################################################
#备份当前的正在使用的war包
d=`date +"%Y-%m-%d_%H-%M"`
unset cp
[ ! -d /home/wls81/backup/$app ] && mkdir -p /home/wls81/backup/$app
 chown -R wls81.wls81 /home/wls81
[ -f webapps/${app}.war ] && cp -f webapps/${app}.war /home/wls81/backup/${app}/${app}_${d}.war

#删除备份目录下30天前的包
find /home/wls81/backup/$app -mtime +3 -name "*.war" |xargs rm -rf {} \;
##################################################################################

#关闭实例后检查是否成功关闭，及清空目录

for pid in `ps -ef | grep  "${dir}/temp" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
   
    kill -9 $pid 2>/dev/null
done


for f in `ls -d webapps/*`
do
    echo $f | grep -E -q '.war$'
    if [ $? -eq 0 ]
    then
	war_dir=`echo $f |awk -F "." '{print $1}'`
	#删除war文件，及对应的war目录
       [ -f ${app}.war ] &&  rm -rf $f 
       [ -f ${app}.war ] && rm -rf $war_dir
       #[ ! -f ${app}.war ] && echo "${dir}目录下不存在${app}.war文件,当前只会完成清空work目录并重启的操作"
    fi
done

rm -rf work/* >/dev/null 2>&1

pid=`ps -ef | grep "${dir}/temp" | grep -v "grep" | awk '{print $2}'`
[[ -z $pid ]] && echo "$app 关闭成功"
[[ ! -z $pid ]] && echo "$app 关闭失败" && exit 1
######################################################################
#移动war文件到webapps目录
unset mv 
[[ -f ${app}.war ]] && mv -f  ${app}.war webapps/
chown -R wls81.wls81 webapps

#启动
echo "等待系统启动成功，可能需要几分钟."
[[ -z $pid ]] && su wls81 bin/startup.sh 
sleep 2
#######################################################################
echo "当前实例对应的port为$port ......"
sleep 5
#检验
#code=`python /data/shell2/shell/rundeck/check.py $http`
#[[ $code -eq 200 ]] && echo "http请求成功"  

#pid检查验证
pid=`ps -ef | grep -E "${dir}/temp" | grep -v "grep" | awk '{print $2}'`
if [ ! -z $pid ];then
#  if [[ $code == 200 ]];then
    echo  "$app 启动成功 " 
    echo "#################################################"
    exit 0
#  fi
fi

[ -z $pid ] && echo " $app 启动失败" &&  exit 1
 

 
###################################################################
