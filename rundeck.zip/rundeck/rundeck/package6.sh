#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# != 1 ];then
   echo "Usage:$0 输入实例名"
   exit 1
fi

appn=$1
dir=/root/.jenkins/workspace/risk-parent
dir1="/root/.jenkins/workspace/risk-parent/loan-api"
dir2="/home/wls81/tomcat"



mvnd=$(which mvn)

unset cp  
#定义实例对应的端口

       #_port=(8009 8010 8011 8012 8013 8014 8015 8016 8017 8018 8019 8020 8021)
       #_port=(2345 2346 2347 2348 2349 2350 2351 2352 2353 2354 2355 2356 2357)
instance_port=(8083 8084 8085 8086 8087 8088 8089 8090 8091 8092 8093 8094 8095)

#根据输入的实例名以及上面定义的端口数组来获得实例的tom_pid 并记录对应的端口号port
case  ${appn} in   
   testall)
      cd $dir || exit 1
      $mvnd clean install
  ;;

  authCenter)
      cd ${dir1}/loan-authCenter-api || exit 1
      
      [ -d ${dir1}/loan-authCenter-api/target ] &&  rm -rf ${dir1}/loan-authCenter-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-authCenter-api/target/loan-authCenter-api.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-authCenter-api/target/loan-authCenter-api.war ${dir2}/${appn}/${appn}.war
        sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn
      fi
      
    ;;

  userCenter)
      cd ${dir1}/loan-user-api || exit 10
      [ -d ${dir1}/loan-user-api/target ] &&  rm -rf ${dir1}/loan-user-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-user-api/target/loan-user-api.war ]];then
         echo "打包失败"
         exit 1
      else
        cp -f ${dir1}/loan-user-api/target/loan-user-api.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi
      
  ;;

  backendCenter)
      cd ${dir1}/loan-backend-web || exit 1
      [ -d ${dir1}/loan-backend-web/target ] &&  rm -rf ${dir1}/loan-backend-web/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-backend-web/target/loan-backend-web.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-backend-web/target/loan-backend-web.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;
  backendDubbo)
      cd ${dir1}/loan-backend-dubbo || exit 1
      [ -d ${dir1}/loan-backend-dubbo/target ] &&  rm -rf ${dir1}/loan-backend-dubbo/target
      $mvnd package
      if [[ ! -f ${dir1}/loan-backend-dubbo/target/loan-backend-dubbo.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-backend-dubbo/target/loan-backend-dubbo.war ${dir2}/${appn}/${appn}.war
        sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;
  backendtaskCenter)
      cd ${dir1}/loan-backend-task || exit 1
      [ -d ${dir1}/loan-backend-task/target ] &&  rm -rf ${dir1}/loan-backend-task/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-backend-task/target/loan-backend-task.war ]];then
       echo "打包失败"
       exit 1
      else
        cp -f ${dir1}/loan-backend-task/target/loan-backend-task.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi
      
  ;;

  messageCenter)
      cd ${dir1}/loan-message-api || exit 1
      [ -d ${dir1}/loan-message-api/target ] &&  rm -rf ${dir1}/loan-message-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-message-api/target/loan-message-api.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-message-api/target/loan-message-api.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;

  activityCenter)
      cd ${dir1}/loan-activity-api || exit 1
      [ -d ${dir1}/loan-activity-api/target ] &&  rm -rf ${dir1}/loan-activity-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-activity-api/target/loan-activity-api.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-activity-api/target/loan-activity-api.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;

  debitapiCenter)
      cd ${dir1}/loan-debit-api || exit 1
      [ -d ${dir1}/loan-debit-api/target ] &&  rm -rf ${dir1}/loan-debit-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-debit-api/target/loan-debit-api.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-debit-api/target/loan-debit-api.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;

  debitserviceCenter)
      cd ${dir1}/loan-debit-service-api || exit 1
      [ -d ${dir1}/loan-debit-service-api/target ] &&  rm -rf ${dir1}/loan-debit-service-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-debit-service-api/target/debitserviceCenter.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-debit-service-api/target/debitserviceCenter.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

		
      fi

  ;;
  
  payCenter)
      #pass

  ;;
  bankCenter)
      cd ${dir1}/loan-bank-api || exit 1
      [ -d ${dir1}/loan-bank-api/target ] &&  rm -rf ${dir1}/loan-bank-api/target
      $mvnd package 
      if [[ ! -f ${dir1}/loan-bank-api/target/loan-bank-api.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-bank-api/target/loan-bank-api.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;
  payserviceCenter)
      cd ${dir1}/loan-pay-service-api || exit 1
      [ -d ${dir1}/loan-pay-service-api/target ] &&  rm -rf ${dir1}/loan-pay-service-api/target
      $mvnd package
      if [[ ! -f ${dir1}/loan-pay-service-api/target/loan-pay-service-api.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan-pay-service-api/target/loan-pay-service-api.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;
  crmCenter)
      cd ${dir1}/loan_crm_web || exit 1
      [ -d ${dir1}/loan_crm_web/target ] &&  rm -rf ${dir1}/loan_crm_web/target
      $mvnd package
      if [[ ! -f ${dir1}/loan_crm_web/target/loan_crm_web.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/loan_crm_web/target/loan_crm_web.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi

  ;;
  honglu-batch)
      cd ${dir1}/honglu-batch || exit 1
      [ -d ${dir1}/honglu-batch/target ] &&  rm -rf ${dir1}/honglu-batch/target
      $mvnd package
      if [[ ! -f ${dir1}/honglu-batch/target/honglu-batch.war ]];then
        echo "打包失败"
        exit 1
      else
        cp -f ${dir1}/honglu-batch/target/honglu-batch.war ${dir2}/${appn}/${appn}.war
	sh /data/shell2/shell/rundeck/package5.sh $appn
        sh /data/shell/war_update.sh $appn

      fi
 
  ;;

  *)
    echo "tomcat实例名不正确"
    exit 1
  ;;

esac
