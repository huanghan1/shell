#!/bin/bash
type=$1
app=$2
options=$3
spideragent="cn.robot.axes.core.LogicEngine"
spiderconsumer="cn.my.gw.client.RabbitCustomConsumer"
spiderserver="cn.my.gw.server.Server"
spiderseeds="com.spider.crawl.SpiderAll"
dir="/data/workspace/jar/spider/$app"
tom_dir="/home/wls81/tomcat"
script="/data/shell2/shell/rundeck"
ip="139.224.6.147"
[ ! -d $dir ] && mkdir -p $dir
if [ "$type" == "jar" ];then
    cd /root/.jenkins/workspace/${app}/target
    name=`ls |grep -E "*.jar$"`
    if [ ! -f $name ];then
        echo "当前${app}包没有生成"
        exit 1
    fi 
    unset cp
#移包
    cp -f $name $dir/$app.jar
#同步包到各个节点
   if [ "$options" == "deploy" ];then 
       rsync -az -e "ssh -p 133" ${dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null 
       rsync -az -e "ssh -p 133" /home/wls81/$app/ ${ip}:${tom_dir}/${app}/ > /dev/null 
   else
       echo "重启${app}"
   fi
#同步启动脚本
   rsync -az -e "ssh -p 133" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
#重新启动
   echo "############################################################################################"
   echo "开始启动${app},这可能需要几分钟....."
   echo "........"
   sleep 1
   echo "..."
   echo "启动检验............"
   ssh -p 133 $ip "sh /data/shell2/shell/rundeck/spider_start.sh $app $type" &
   exit 0
else
    cd /root/.jenkins/workspace/${app}/
    name=`ls |grep -E "*.zip$"`
    if [ ! -f $name ];then
        echo "当前${app}包没有生成"
        exit 1
    fi 
    unset cp
#移包
    
    #ls $dir/ |grep -Ev "*\.(jar|zip)$" |xargs rm -rf
    rm -rf $dir/*
    cp -f $name $dir/${app}.zip
    ls $dir
    cd $dir
    rm -rf $dir/conf/*
    unzip $dir/${app}.zip
    rm -f $dir/${app}.zip
   cp -f /home/wls81/$app/* $dir/conf/
   cp -f $dir/conf/${app}.sh $dir/ 
#同步包到各个节点
   if [ "$options" == "deploy" ];then
       if [ "$app" == "spideragent" ];then 
           rsync -az -e "ssh -p 155" ${dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null 
           
           rsync -az -e "ssh -p 155" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
       elif [ "$app" == "spiderseeds" ];then

           rsync -az -e "ssh -p 133" ${dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null 
           
           rsync -az -e "ssh -p 133" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
       else
          
           rsync -az -e "ssh -p 144" ${dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null 
           
           rsync -az -e "ssh -p 144" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
       fi
         
   else
       echo "重启${app}"
       
       rsync -az -e "ssh -p 144" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
       rsync -az -e "ssh -p 155" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
       rsync -az -e "ssh -p 133" ${script}/spider_start.sh ${ip}:${script}/ > /dev/null   
   fi
#重新启动
   echo "############################################################################################"
   echo "开始启动${app},这可能需要几分钟....."
   echo "........"
   sleep 1
   echo "..."
   echo "启动检验............"
   if [ "$app" == "spideragent" ];then
   ssh -p 155 $ip "sh /data/shell2/shell/rundeck/spider_start.sh $app $type $options" &
   elif [ "$app" == "spiderseeds" ];then
   ssh -p 133 $ip "sh /data/shell2/shell/rundeck/spider_start.sh $app $type $options" &
   else
   ssh -p 144 $ip "sh /data/shell2/shell/rundeck/spider_start.sh $app $type $options" &
   fi
   exit 0

fi
