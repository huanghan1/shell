#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#svn://svn.xnshandai.net/shandai/trunk/loan-parent

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
projects=$4
create_pro_war=$5
authority=$6
item=$7
pinpoint=$8

######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/hgitparfilehhh.sh
#. /data/shell2/shell/rundeck/hparfile.sh
#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$${item}"
#dir1="${dir}/loan-api"
dir1="${dir}"

if [[ $projects == "hongluoperate" ]];then
   #dir="/root/.jenkins/workspace/huihuahua/trunk/operate-parent"
   dir1="$dir/operate-activity"
elif [[ $projects == hongluoperateApi ]];then
   dir1="${operate_trunk}/operate-operate"
elif [[ $projects == "crmCenter2" ]];then
   dir1="${operate_trunk}/"
elif [[ $projects == "marketCenter" ]];then
   dir1="${market_parent}"
elif [[ $projects == "debitapiCenter" ]];then
   dir1="${debbitapi_trunk}"
elif [[ $projects == "userCenter" ]];then
   dir1="${userCenter_trunk}/loan-user-web"
#elif [[ $projects == "bankCenter" ]];then
#   dir1="$dir2/bank-api-parent"

fi




echo ${parfile}
###############################main############################################################################################
#判断密码
eval password="\$${to}X"
echo $test01X
echo ${to}X
echo ${authority}
echo $password
#echo $authority

hdev_pd="hhhhh"
htest01_pd="xntest"
hpro_pd="pro"

eval pd="\$${To}_pd"

if [ $authority != "$pd" ];then
   echo "your passwd is error...."
   exit
fi

#执行testall打包
fl=0
cd $dir1 || fl=1
[ $fl -eq 1 ] && echo "$dir 目录不存在" && exit 1

export BUILD_ID="mvn install"
if [ $build_all == "yes" ];then
   echo "开始构建全量war包....."
   echo "删除旧的war包...."
   find ./ -type f -name "*.war" |xargs rm -f {}
   $mvnd --settings $msetting clean install -Dmaven.test.skip=true
   #$mvnd  clean install -Dmaven.test.skip=true
   [ ! $? -eq 0 ] && echo "全量构建失败" && exit 1
   echo "############################################################################################"
   echo "############################################################################################"
else
   echo "没有构建全量war包.....只对所选工程进行构建"
   echo "############################################################################################"
   echo "############################################################################################"
fi
######################################################

NF=$(echo $projects | awk -F "," '{print NF}')

for x in `seq 1 $NF`
	do 
    	project=`echo $projects |awk -v d=$x -F "," '{ print $d }'`
        [ $project == "None" ] && echo "你选择了None" && exit 1
        sh /data/shell2/shell/rundeck/hgitshandai3.sh  $to $bra_name $build_all $project $create_pro_war $item $pinpoint 
        [ $? -eq 1 ] && echo "$project 部署失败#######################################"
        echo "################################################"
        sleep 2
    done
#[ $fl -eq 1 ] && exit 1
