#!/bin/bash
jar=`ls lib | grep "..*\.jar$"`
#echo $jar
_classpath="./classes ${jar}"
#echo ${_classpath}
classpath=`echo ${_classpath} | sed -e 's/ /:lib\//g'`
#echo ${classpath}
today=$(date +%F)
java -server -Xms512m -Xmx2048m -XX:PermSize=196m -XX:MaxPermSize=512m -Dlog4j.configuration=file:conf/log4j.properties  -classpath ${classpath} cn.my.server.DataProbeServer dataprobe_1

