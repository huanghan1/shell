#!/bin/bash

if [ $# != 3 ] ;then
  echo "参数不对"
  exit 1
fi

app=$1
class_name=$2
option=$3
dir="/home/wls81/engine"
cronlog="/usr/local/sbin/cronolog"
log="/data/${app}/logs/catalina.out.%Y-%m-%d-%H.log"
script=${app}.sh

if [ $app == "dataprobe" ];then
 dir="/home/wls81/openxn"
 script="server.sh"
fi

#
chown -R wls81.wls81 $dir
cd ${dir}/$app || exit 1

ignore_pid=$$
ignore_ppid=`ps -ef | awk -v pid="$$" '{if($2==pid) print $3}'`
for pid in `ps -ef | grep -E "$class_name" |grep -v "grep" | awk '{print $2}'`
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
    if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
    then
        continue
    fi
    kill -9 $pid 2>/dev/null
done

sleep 2 
#pid=$(ps -ef | grep -E "$class_name" |grep -v "grep" | awk '{print $2}')
#if [[ -z $pid ]];then
#  echo "$app closed successful"
#  echo "#############################################################"
#else
#  echo "$app closed false"
#  exit 0 
#fi
set -m "start $app"
if [ $option != "close" ];then
  cd ${dir}/$app || exit 1
  su wls81 -c "nohup sh ${dir}/${app}/$script 2>&1 | $cronlog $log &"
  echo "启动$app任务"
fi


