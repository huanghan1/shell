#!/bin/bash


To=$1
app=$2
passwd=$3
pinpoint=$4
con=$5
if [ $To = "pro" ];then
    if [ $passwd != "pro" ];then
        echo "your passwd is error...."
        exit
    fi
elif [ $To = "test" ];then
    if [ $passwd != "test" ];then
        echo "your passwd is error...."
        exit
    fi
fi



#svn基准目录
pro_svn_dir=${svn_dir}/${app_dir}
wk_dir=/data/workspace/oa
pro_wk_dir=${wk_dir}/$app

#dev_ip="172.16.11.196"
test_ip="172.16.11.156"
pro_ip="172.16.11.205"
src_config_dir="/data/workspace/config/oa/${app}/$To"
dest_config_dir="/home/wls81/config/${app}"
app_dir="/home/wls81/tomcat/$app"

script_dir="/data/shell2/shell/rundeck/oa_update.sh"
[ ! -d $src_config_dir ] && mkdir -pv $src_config_dir
permanager_port=8081
perconsume_port=8082
pereureka_port=8083
newpermanager_port=8084
eval port="\$${app}_port"
echo $port

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
       dev)
           unset cp
           echo "开始部署${app}的开发环境"
           rsync -az -e "ssh -p 20022" $src_config_dir $dev_ip:$dest_config
           rsync -az -e "ssh -p 20022" $script_dir $dev_ip:$script_dir
           rsync -az -e "ssh -p 20022" ${pro_wk_dir}/${app}_${To}.jar ${dev_ip}:${app_dir}/${app}.jar
           ssh -p 20022 $dev_ip "sh $script_dir $app $pinpoint $con"
           [ $? -eq 0 ] && exit 0

       ;;
       test)
           unset cp
           echo "开始部署${app}的${To}环境....."
           rsync -az -e "ssh -p 22" $src_config_dir/* $test_ip:$dest_config_dir/
           rsync -az -e "ssh -p 22" $script_dir $test_ip:$script_dir
           scp -P 22 ${pro_wk_dir}/${app}_${To}.jar $test_ip:$app_dir/${app}.jar
	   ssh -p 22 $test_ip "sh $script_dir $app $pinpoint $con $port"
	   [ $? -eq 0 ] && exit 0
       ;;

      pre|pro)
           unset cp
           echo "开始部署${app}的${To}环境....."
           rsync -az -e "ssh -p 20022" $src_config_dir/ $pro_ip:$dest_config_dir/
           rsync -az -e "ssh -p 20022" $script_dir $pro_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}.jar $pro_ip:$app_dir
           ssh -p 20022 $pro_ip "sh $script_dir $app $pinpoint $con $port"
           [ $? -eq 0 ] && exit 0
           echo "Only create pro jar..."
       ;;
    esac
fi

