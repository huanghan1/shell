#!/bin/bash
#if [ $# -ne 4 ];then
#    num=$#
#    echo "传的参数有误,需要传三个参数,现在传了${num}"
#    exit 1
#fi
project=$1
appname=$2
time=`date "+%Y-%m-%d %H:%M:%S"`
env=$3
subitem=$4

mysql -uslowsql -pt4FIq6tdkC -h'rm-uf6ik056d0707ng5i.mysql.rds.aliyuncs.com' -e "INSERT INTO monitor.jenkins_update (\`project\`,\`subitem\`,\`appname\`,\`date\`,\`env\`) VALUES (\"$project\",\"$subitem\",\"$appname\",\"$time\",\"$env\");"
if [ $? -eq 0 ];then
   echo -e "\033[41;30m 更新数据库信息成功  \033[0m"
else
   echo -e "\033[46;30m jenkins 打包更新数据库失败 \033[0m"
fi

