#encoding=utf-8
# -*- coding: utf-8 -*-
import sys
import urllib2
if len(sys.argv) == 2:
  try:
    url = sys.argv[1]
    #print(url)
    response = urllib2.urlopen(url)
  except Exception,e:
    print 404
    sys.exit()
	
  print response.getcode()
else:
  print "参数错误"

