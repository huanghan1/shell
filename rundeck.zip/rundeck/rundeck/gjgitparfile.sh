#!/bin/bash
#app_主干命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 trunk crmCenter yes test app_trunk

#app_分支命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 1.4.0 activityCenter no test app_branch

#风控命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 risk-parent_2.7 backendCenter no test risk

#催收命令行测试用例
#sh -x  /data/shell2/shell/rundeck/app_trunk.sh test02 receive receiveWebCenter no test receive
######################################################################
#定义项目对应的maven配置文件路径
#app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
app_trunk_mset="/usr/local/maven-3.5.0/conf/kksq_setting.xml"
app_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
kk_trunk_mset="/usr/local/maven-3.5.0/conf/kksq_setting2.xml"
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/tomcat/"
tom_dir="/home/wls81/tomcat"
jar_config_dir="/home/wls81/config/guanjia"
war_config_idr="/data/workspace/config"
#workspace_dir="/data/workspace/kksq"
workspace_dir="/data/workspace/guanjia"
#配置文件路
vdev_configdir="/data/workspace/config/gjdev"
vtest01_configdir="/data/workspace/config/gjtest01"
vpro_configdir="/data/workspace/config/gjpro"

#定义环境对应的svn物理路径
#app 主干
app_trunk="/root/.jenkins/workspace/guanjia"
dir2="/root/.jenkins/workspace/guanjia"
#kk_trunk="/root/.jenkins/workspace/kksq-calfloadchild"


######################################################################
#定义环境对应的ip
test="172.16.0.187"
test01="172.16.0.221"
pro=""

#定义环境密码
testX="dev"
test01X="qytest"
prodX="pro"

######################################################################

#定义项目的要target目录名
loanCenter_target="calfLoan-loancenter/calfLoan-loancenter_web"
loanCenter_jar_target="calfLoan-loancenter/calfLoan-loancenter_biz"
communityCenter_target="calfLoan-communitycenter/calfLoan-communitycenter_web"
communityCenter_jar_target="calfLoan-communitycenter/calfLoan-communitycenter_biz"
activityCenter_target="calfLoan-activityCenter/calfLoan_activityCenter_web"
activityCenter_jar_target="calfLoan-activityCenter/calfLoan_activityCenter_biz"
gjapiCenter_target="calfLoan-gjapiCenter/calfLoan_gjapiCenter_web"
gjapiCenter_jar_target="calfLoan-gjapiCenter/calfLoan_gjapiCenter_biz"
calfLoanWeb_target="calfLoan-backWeb"
gjapiSC_jar_target="calfLoan-gjapiCenter/calfLoan_gjapiSC_biz"
userCenter_target="calfLoan-usercenter/calfLoan-usercenter_web"
userCenter_jar_target="calfLoan-usercenter/calfLoan-usercenter_biz"
child_jar_target="calfLoad-child-admin"
#定义项目的要打包目录名
loanCenter_build="calfLoan-loancenter"
loanCenter_jar_build="calfLoan-loancenter"
communityCenter_build="calfLoan-communitycenter"
communityCenter_jar_build="calfLoan-communitycenter"
userCenter_build="calfLoan-usercenter"
userCenter_jar_build="calfLoan-usercenter"
activityCenter_build="calfLoan-activityCenter"
child_jar_build="calfLoad-child-admin"
activityCenter_jar_build="calfLoan-activityCenter"
calfLoanWeb_build="calfLoan-backWeb"
gjapiCenter_build="quickcall-common"
gjapiCenter_jar_build="calfLoan-gjapiCenter"
gjapiSC_jar_target_build="calfLoan-gjapiCenter"


#定义实例对应的端口
loanCenterX=8083
loanCenter_jarX=8084
communityCenterX=8085
communityCenter_jarX=8086
userCenterX=8087
userCenter_jarX=8088
activityCenterX=8089
activityCenter_jarX=8090
calfLoanWebX=8091
gjapiCenterX=8092
gjapiCenter_jarX=8093
gjapiSC_jarX=8094
child_jarX=8095

#定义应用类型
loanCenter_type=war
loanCenter_jar_type=jar
communityCenter_type=war
communityCenter_jar_type=jar
userCenter_type=war
userCenter_jar_type=jar
activityCenter_jar_type=jar
activityCenter_type=war
calfLoanWeb_type=war
gjapiCenter_type=war
gjapiCenter_jar_type=jar
gjapiSC_jar_type=jar
child_jar_type=jar

#包名
loanCenter_filename=loanCenter.war
loanCenter_jar_filename=loanCenter.jar
communityCenter_filename=communityCenter.war
communityCenter_jar_filename=communityCenter.jar
userCenter_filename=userCenter.war
userCenter_jar_filename=userCenter.jar
activityCenter_filename=activityCenter.war
activityCenter_jar_filename=activityCenter.jar
calfLoanWeb_filename=calfLoanWeb.war
gjapiCenter_filename=gjapiCenter.war
gjapiCenter_jar_filename=gjapiCenter.jar
gjapiSC_jar_filename=gjapiSC.jar
child_jar_filename=calfLoad-child-admin-0.0.1-SNAPSHOT.jar


