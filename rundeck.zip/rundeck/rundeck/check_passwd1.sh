#!/bin/bash

dev_pass=dev_123456
test_pass=testtesttest
cloud_pass=dev_123456
master_pass=pro
hotfix_pass=pro

eval pass="\$${To}_pass"

if [ "$password" != "$pass" ];then 
   echo "#################password is error.....#############################"
   exit 1
fi     
