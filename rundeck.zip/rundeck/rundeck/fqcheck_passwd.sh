#!/bin/bash

dev_pass=dev_123456
develop_pass=dev_123456
dev_ken_0505=dev_123456
test_pass=2wsx1qaz
master_pass=pro
mock_pass=pro
fat_pass=2wsx1qaz
uat_pass=pro
chulili_fadada_20190508_pass=2wsx1qaz

eval pass="\$${branch}_pass"

if [ "$password" != "$pass" ];then 
   echo "#################password is error.....#############################"
   exit 1
fi     
