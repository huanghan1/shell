#!/bin/bash

if [ $# != 4 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
src_war_dir=$1
appn=$2
to=$3
create_pro_war=$4

src="/data/workspace/war"
d=$(date +%Y-%m-%d_%H:%M)

[ ! -d ${src}/$appn ] && mkdir -p ${src}/$appn
cd ${src}/$appn || exit 1
version=`[ -f version ] && cat version`
rm -rf ${src}/${appn}/*
echo $version > version

[ ! -d tmp ] && mkdir tmp

unset cp
if [ $to == "dev" ];then
   [ -f ${src_war_dir} ] && cp -f  ${src_war_dir} ./${appn}_${to}.war
   [ $? -eq 0 ] && echo "研发环境war包构建完成"
   exit 0
fi

################################################################################
function changeConfig {

   if [ $to != "pre" ];then
      if [ ! -d ${pre_conf}/$appn ];then
	 echo "${appn}的测试配置文件不存在" 
         echo "${appn}的测试包准备失败，，已经退出配置文件替换过程"
	 exit 1
      fi
   else
      if [ ! -d ${pro_conf}/$appn ];then
	echo "${appn}的生产配置文件不存在" 
	echo "${appn}的生产包准备失败，，已经退出配置文件替换过程"
	exit 1
      fi
   fi

   #解包
   jar -xf ${appn}.war
   #删除原包
   [ $? -eq 0 ] && rm -f ${appn}.war || flg=1 

   #替换环境配置
   unset cp
   if [ $to != "pre" ];then
      cp -f ${pre_conf}/${appn}/* WEB-INF/classes/
   else
      cp -f ${pro_conf}/${appn}/* WEB-INF/classes/
   fi
   [ ! $? -eq 0 ] && echo "替换配置文件失败，已退出替换过程" && flg=1
   if [ $appn == "crmCenter" ];then
	 unset mv
	 mv -f WEB-INF/classes/base.js commons/base.js
	 [ ! $? -eq 0 ]&& flg=1
	 [ ! $flg -eq 1 ] && echo "crmCenter的base.js 替换ok"
   fi 
   [ $flg -eq 1 ] && exit 1

}





function modify_config {

pre_conf="/data/workspace/config/pre"
pro_conf="/data/workspace/config/pro"
cd tmp ||exit 10
if [ -f ${appn}.war ];then
  if [ $to != "pre" ];then
      flg=0
      #替换文件
      changeConfig
      [ $flg -eq 1 ] && exit 1
      #封装测试包
      jar -cf ${appn}.war ./*
      [ ! $? -eq 0 ] && exit 14
 
      #移动war包到上层目录
      if [ -f ${appn}.war ];then
         mv ${appn}.war ../${appn}_${to}.war
         [ $? -eq 0 ] && echo "${to}测试环境war包构建完成" || exit 1
      else
         echo "封装测试包失败"
         exit 1
      fi
 
  else
 
    if [ $create_pro_war == "yes" -o $create_pro_war == "ag" ];then
        flg=0
        #替换文件
        changeConfig
        [ $flg -eq 1 ] && exit 1
        #封生产包
        jar -cf ${appn}.war ./*
        [ ! $? -eq 0 ] && exit 14

        #移动war包到workspace/war/xxx目录下
        if [ -f ${appn}.war ];then 
              mv ${appn}.war ../ || exit 1
              [ $? -eq 0 ] &&  echo "预生产环境war包已经构建完成" || exit 1
        else
             echo "封装预生产包失败"
             exit 1
        fi
  
	cd .. || exit 13
   	#生成md5值并保存
   	sha256=$(sha256sum ${appn}.war | awk '{print $1}')
   	if [ ! -z $sha256 ];then
       	   echo $sha256 > sha256.txt
  	 else
       	   echo "error" > sha256.txt
           echo "md5值生成失败"
           exit 1
  	fi
  	echo $d  > time
    else
        echo "create_pro_war is not yes"
        exit 1
    fi
    echo "${to}环境配置文件替换成功.........".
    echo "#################################################"
  fi  

else
  echo "拉不到war包"
  exit 15
fi
  
    
    
}
######################################################################
[ -f ${src_war_dir} ] && cp -f  ${src_war_dir} tmp/${appn}.war
   
modify_config

