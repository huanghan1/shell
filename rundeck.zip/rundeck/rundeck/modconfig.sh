#############################################
#动态配置
#mod status
online_mod=mod2

#running stat
run_stat=open

#sleep time
sleep_time=20

#version dir
version=model_1.2

#############################################
#静态配置
#python环境路径
python="/home/wls81/anaconda3/bin/python"
#线上模型主脚本
main="main_.py"
#模型路径
dir="/home/wls81/model"

#模型组
mods=(mod1 mod2 mod3 mod4)

#模型对应的序号
mod1_num="1"
mod2_num="2"
mod3_num="3"
mod4_num="4"

#模型对应的主脚本名
mod1="model_1_2_1.py"
mod2="model_1_2_2.py"
mod3="model_1_2_3.py"
mod4="model_1_2_4.py"




