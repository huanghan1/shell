#!/bin/bash



To=$1
app=$2
passwd=$3


dev_pd="zhangwu_123"
test01_pd="xntest"
test02_pd="xntest"
pro_pd="pro"

eval pd="\$${To}_pd"

if [ $passwd != "$pd" ];then
   echo "your passwd is error...."
   exit
fi


financewebX="finance-web/loan-finance-system"
financepayX="finance-pay/pay-api" 
financejobX="finance-job"
financexnhuyuX="finance-xnhuyu/xnhuyu-api"
financecommonserviceX="finance-common-service"
financemicromqconsumerX="finance-micro-mq-consumer"
paybaseX="pay-base"
financewebgatewayX="finance-web-gateway/gateway-api"
financeguanjiaX="finance-guanjia/guanjia-api"
financevoiceX="finance-voice/voice-api"
financekakaX="finance-kaka/kaka-api"

eval file="\$${app}X"
#dir=$3
mvnd=$(which mvn)
setting="/usr/local/maven-3.5.0/conf/shandaicaiwu_trunk_settings.xml"

#svn基准目录
svn_dir=/root/.jenkins/workspace/financevoice
pro_svn_dir=${svn_dir}/$file
wk_dir=/data/workspace/huihuahua
pro_wk_dir=${wk_dir}/$app


#if [ $app != "dataprope" ];then
  #cd ${pro_svn_dir} || exit 1
if [[ $app == "financepay" || $app == "financeweb"|| $app = "financejob"|| $app == "financexnhuyu" || $app == "financewebgateway" || $app == "financeguanjia"|| $app == "financevoice" ||$app == "financekaka" ]];then
  cd ${svn_dir} || exit 1
  echo "开始构建${app}。。。。"
  echo "############################################################################################"
  echo "############################################################################################"
  if [ $To == "pro" ];then
     $mvnd clean  package install --settings $setting -P prod -Dmaven.test.skip=true
     #$mvnd clean  package install --settings $setting  -Dmaven.test.skip=true
  else
     #$mvnd clean  package install --settings $setting -P dev -Dmaven.test.skip=true
     $mvnd clean  package install --settings $setting  -Dmaven.test.skip=true
  fi
  num=$?
  echo "############################################################################################"
  echo "############################################################################################"
  echo "构建${app}完成，开始生成${app}.jar"
  if [ $num -eq 0 ];then
     #取得jar包文件名
     cd ${pro_svn_dir} || exit 1
     [ -d target ] && filedir=`find target -name "*.jar" `
     [ ! -z $filedir ] && jarfile=`basename $filedir ` 
     if [[ ! -f ${pro_svn_dir}/target/$jarfile ]];then
        echo "############################################################################################"
        echo "############################################################################################"
        echo "打包失败"
        echo "构建${app}失败,请找开发确定是否还有未提交的代码"
        exit 1
     else
        [ ! -d $pro_wk_dir ] && mkdir -p $pro_wk_dir
        if [ -d $pro_wk_dir ];then
	  src_dir="${pro_svn_dir}/target/$jarfile"
	  #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
          unset cp
	  cp -f $src_dir  ${pro_wk_dir}/$app.jar

	  if [[ ! $? -eq 0 ]];then
		 echo "转移${app}的jar包失败"
		 exit 1
	  else
                 sleep 2
                 echo "############################################################################################"
		 echo "创建${app}.jar成功，生成md5.....记录时间...."
		 cd $pro_wk_dir || exit 1
		 sha256=$(sha256sum ${app}.jar | awk '{print $1}')
                 if [ ! -z $sha256 ];then
		       echo $sha256 > sha256.txt
		 else
		       echo "error" > sha256.txt
		       echo "md5值生成失败"
		       exit 1
		 fi
		 d=$(date +%Y-%m-%d_%H:%M)
		 echo $d  > time

	  fi
              echo "############################################################################################"
              echo "构建${app}完成."
              echo "############################################################################################"
        else
	      echo "${dir2}$appn 目录不存在"
	      exit 1
            fi
         fi
      else
         echo "构建失败"
         exit 1
      fi
else
  #cd ${svn_dir}/$file || exit 1
  cd ${pro_svn_dir} || exit 1
  echo "开始构建${app}。。。。"
  echo "############################################################################################"
  echo "############################################################################################"
  if [ $To == "pro" ];then
     $mvnd clean  package install --settings $setting -P prod -Dmaven.test.skip=true
     #$mvnd clean  package install --settings $setting  -Dmaven.test.skip=true
  else
     #$mvnd clean  package install --settings $setting -P dev -Dmaven.test.skip=true
     $mvnd clean  package install --settings $setting  -Dmaven.test.skip=true
  fi
  num=$?
  echo "############################################################################################"
  echo "############################################################################################"
  echo "构建${app}完成，开始生成${app}.jar"
  if [ $num -eq 0 ];then
     #取得jar包文件名
     #cd ${pro_svn_dir} || exit 1
     cd ${pro_svn_dir}
     [ -d target ] && filedir=`find target -name "*.jar" `
     [ ! -z $filedir ] && jarfile=`basename $filedir `
     if [[ ! -f ${pro_svn_dir}/target/$jarfile ]];then
        echo "############################################################################################"
        echo "############################################################################################"
        echo "打包失败"
        echo "构建${app}失败,请找开发确定是否还有未提交的代码"
        exit 1
     else
        [ ! -d $pro_wk_dir ] && mkdir -p $pro_wk_dir
        if [ -d $pro_wk_dir ];then
          src_dir="${pro_svn_dir}/target/$jarfile"
          #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
          unset cp
          cp -f $src_dir  ${pro_wk_dir}/$app.jar

          if [[ ! $? -eq 0 ]];then
                 echo "转移${app}的jar包失败"
                 exit 1
          else
                 sleep 2
                 echo "############################################################################################"
                 echo "创建${app}.jar成功，生成md5.....记录时间...."
                 cd $pro_wk_dir || exit 1
                 sha256=$(sha256sum ${app}.jar | awk '{print $1}')
                 if [ ! -z $sha256 ];then
                       echo $sha256 > sha256.txt
                 else
                       echo "error" > sha256.txt
                       echo "md5值生成失败"
                       exit 1
                 fi
                 d=$(date +%Y-%m-%d_%H:%M)
                 echo $d  > time

          fi
              echo "############################################################################################"
              echo "构建${app}完成."
              echo "############################################################################################"
        else
              echo "${dir2}$appn 目录不存在"
              exit 1
            fi
         fi
      else
         echo "构建失败"
         exit 1
      fi
 
fi
#exit 0

dev_ip="106.15.48.19"
test01_ip="172.16.0.197"
test02_ip="172.16.0.190"
htest02_ip="172.16.11.193"
config_dir="/data/workspace/config/caiwu/${app}/"
config_dir2="/data/workspace/config/caiwu/${app}-pre/"
config_dir3="/data/workspace/config/caiwu/${app}-dev/"
config_dir4="/data/workspace/config/caiwu/${app}-test02/"
app_dir="/home/wls81/jar/caiwu/$app/"
script_dir="/data/shell2/shell/rundeck/oldcaiwu_update.sh"
chown -R wls81.wls81 $app_dir

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
        dev)
           unset cp
           echo "开始部署${app}的开发环境....."
           rsync -az -e "ssh -p 20022" $config_dir3 $dev_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $dev_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $dev_ip:$app_dir
           ssh -p 20022 $dev_ip "sh $script_dir $app $To"
           [ $? -eq 0 ] && exit 0

       ;;

       test01)
           unset cp
           echo "开始部署${app}的测试环境....."
           rsync -az -e "ssh -p 20022" $config_dir $test01_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test01_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $test01_ip:$app_dir
           ssh -p 20022 $test01_ip "sh $script_dir $app $To"
           [ $? -eq 0 ] && exit 0

       ;;
       test02)
           unset cp
           echo "预发布环境....."
           rsync -az -e "ssh -p 20022" $config_dir2 $test02_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test02_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $test02_ip:$app_dir
           ssh -p 20022 $test02_ip "sh $script_dir $app $To"
           [ $? -eq 0 ] && exit 0
       ;;

        htest02)
           unset cp
           echo "htest02环境....."
           rsync -az -e "ssh -p 20022" $config_dir4 $htest02_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $htest02_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $htest02_ip:$app_dir
           ssh -p 20022 $htest02_ip "sh $script_dir $app $To"
           [ $? -eq 0 ] && exit 0
       ;;

       pro)
           echo "Only create pre war..."
       ;;
    esac
fi

