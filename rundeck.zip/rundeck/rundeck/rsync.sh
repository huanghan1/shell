#!/bin/bash
if [  $# != 1 ];then
  echo "Usage: appname "
  exit 1
fi
app=$1

chown -R wls81.wls81 /home/wls81
dir=/home/wls81/
packagedir=/data/workspace/war/$app

[ ! -d $packagedir ] && mkdir -p $packagedir
cd  $packagedir || exit 1
rm -rf ${packagedir}/*
rsync -avz -e "ssh -p 20022" root@106.15.48.19:$packagedir/ $packagedir/

[ -f ${packagedir}/${app}.war ] && t1sha=`sha256sum ${packagedir}/${app}.war | awk '{print $1}'`
[ -f ${packagedir}/sha256.txt ] && t2sha=`cat ${packagedir}/sha256.txt`


if [ -f ${packagedir}/${app}.war ];then

  if [ "${t1sha}x" != "${t2sha}x" ];then
		echo $t2sha
		echo "文件校验错误"
		exit 1
  else
        cat ${packagedir}/time
        echo "文件校验成功"
        cd $dir || exit 1
#        unset cp
#        d=`date +%Y-%m-%d_%H:%M`
#        [ ! -d backup/$app ] && mkdir -p backup/$app
#        [ -f ${packagedir}/${app}.war ] && cp -f ${packagedir}/${app}.war backup/${app}/${app}_${d}_${t2sha}.war
        find backup/$app -mtime +5 -type f -exec rm -f {} \;
#        echo "备份的文件名：${app}_${d}_${t2sha}.war "
        
  fi
else
  echo "拉包失败"
  exit 1
fi

echo "################################################"

unset cp 
cp -f ${packagedir}/${app}.war ${dir}/tomcat/${app}/${app}.war
sh /data/shell/war_update.sh $app
