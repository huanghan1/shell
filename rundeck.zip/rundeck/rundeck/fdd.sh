
bra_name=$1
target_dir=$2
option=$3
app=$4
jar_name_str=$5
start_option="$6"
pinpoint="$7"
if_to_beta1="$8"


#bra_name=`echo $GIT_BRANCH |awk -F "/" '{print $2}'`
work_dir="/data/workspace/jar/fdd/${app}/$bra_name"
dir=/root/.jenkins/workspace/fdd/${target_dir}/target
conf_dir=/home/wls81/config/fdd/$app
dest_dir=$conf_dir
if [ "$app" == "osplatformweb" ];then
   [ $bra_name == "develop" ] && conf_dir="/data/workspace/config/osplatform_parent/dev/osplatformweb/"
   [ $bra_name == "test" ] && conf_dir="/data/workspace/config/osplatform_parent/test01/osplatformweb/"
   [ $bra_name == "beta1" ] && conf_dir="/data/workspace/config/osplatform_parent/beta1/osplatformweb/"
fi

conf_dir1=/home/wls81/config/fdd/pre/$app
tom_dir=/home/wls81/tomcat
tomcat_dir=${tom_dir}/fdd/$app
dev_ip=172.16.18.52
test_ip=172.16.11.194
fat_ip=172.16.11.194
pre_ip=172.16.0.190
uat_ip=172.16.0.190
cloud_ip=172.16.0.192
beta1_ip=172.16.11.242
mock_ip=172.16.18.52
pro_ip=""
[ ! -d $work_dir ] && mkdir -p $work_dir
[ ! -d $tomcat_dir ] && mkdir -p $tomcat_dir
[ ! -d $conf_dir  ] && mkdir -p $conf_dir

eval ip="\$${bra_name}_ip"

#压测环境ip
loanapigateway_ip="172.16.11.3"
loanapply_ip="172.16.11.21"
loanbigdataconsumer_ip="172.16.11.22"
loanconfig_ip="172.16.11.14"
loancustomer_ip="172.16.11.12"
loanjob_ip=""
loanmanagement_ip="172.16.11.13"
loanorder_ip="172.16.11.2"
loanunionlogin_ip="172.16.11.6 "
microservicesmonitor_ip="172.16.11.11"
registryserver_ip="172.16.11.4"
umanagement_ip="172.16.11.5"
xxljob_ip=""



if [ "$if_to_beta1" == "yes" ];then
   eval ip="\$${app}_ip"
   ip=$ip
   [ ! -f /opt/settings ] && mkdir -p /opt/settings
   #echo "idc=beta1" > /opt/settings/server.properties
fi
echo $ip
[ ! -n $ip ] && echo "环境ip没有配置" && exit 1

cd $dir
#jar_name=`ls | grep -E "$jar_name_str"`
jar_name=`ls | grep -E *.jar$`
[[ ! -f $jar_name ]] && echo "没有可用的jar包" &&  exit 1
unset cp
cp -f $jar_name ${work_dir}/${app}.jar

chown -R wls81. $work_dir

case ${bra_name} in
   pro)      
    #记录打包时间
    echo "记录打包时间.................."
    md5=$(sha256sum ${work_dir}/${app}.jar  |awk '{print $1}')
    dt=`date +"%Y-%m-%d %H:%M"`
    echo $md5 > ${work_dir}/sha256.txt
    echo $dt > ${work_dir}/time
    echo "$bra_name" > ${work_dir}/version
    echo "生产包已经准备好..............."
     #比较生产包与测试包的md5
    if [ -f /data/workspace/jar/fdd/${app}/fat/sha256.txt ];then
       fat_sha256=`cat /data/workspace/jar/fdd/${app}/fat/sha256.txt`
       if [ "$md5" != "$fat_sha256" ];then
          echo "此生产包与最后一次构建的测试包md5值不一致,此生产包未经测试验证。"   
          echo "0" > ${work_dir}/if_pass_verify.txt
          exit 1
       else
          echo "此生产包与最后一次构建的测试包md5值一致,此生产包已经测试验证。"
          echo "1" > ${work_dir}/if_pass_verify.txt
          exit 0
       fi
    else
       echo "此生产包与最后一次构建的测试包md5值不一致,此生产包未经测试验证。"   
       echo "0" > ${work_dir}/if_pass_verify.txt
       exit 1
    fi


        
  # if [ $bra_name != "master"  ] ;then
  #  ##同步pinpoint 
  #  rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${pre_ip}:${tom_dir}/pinpoint/ > /dev/null
  #  #同步tomcat
  #  if [ $option == "restart" ];then
  #    rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
  #  else
  #    rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
  #  fi
  #      
  #  #同步配置文件
  #  [ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir1}/ ${pre_ip}:${dest_dir}/
  #  #同步脚本
  #  rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ ${pre_ip}:/data/shell2/shell/rundeck/
  #      
  #  #同步jar包
  #  [ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ ${pre_ip}:${tom_dir}/${app}/

  #  #重新启动
  #  echo "############################################################################################"
  #  echo "开始启动${app},这可能需要几分钟....."
  #  echo "........"
  #  sleep 1
  #  echo "..."
  #  echo "启动检验............"
  #  ssh -p 20022 ${pre_ip} "sh /data/shell2/shell/rundeck/fdd_update.sh $app $start_option $pinpoint $if_to_beta1" &
  #  sleep 12
  #  ssh -p 20022 ${pre_ip} "ps -ef |grep  ${app}.jar |grep -v grep "
  #  [ ! $? -eq 0 ] && echo "$app start false." && exit 1
  #  #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
  #  #kill -9 $pid
    exit 0
   #fi
       
   ;;
    
   dev|fat|pre|cloud|beta1|mock|uat)
    ##同步pinpoint 
    rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${ip}:${tom_dir}/pinpoint/ > /dev/null 
    #同步tomcat
    if [ $option == "restart" ];then
      rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    else
      rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    fi
        
    #同步配置文件
    #[ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir}/ ${ip}:${dest_dir}/
    #同步脚本
    rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
        
    #同步jar包
    [ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ $ip:${tom_dir}/${app}/

    #重新启动
    echo "############################################################################################"
    echo "开始启动${app},这可能需要几分钟....."
    echo "........"
    sleep 1
    echo "..."
    echo "启动检验............"
    set -m "test"
    ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/fdd_update.sh $app $start_option $pinpoint $if_to_beta1" &
    sleep 12
    ssh -p 20022 $ip "ps -ef |grep  ${app}.jar |grep -v grep "
    [ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    md5=$(sha256sum ${work_dir}/${app}.jar  |awk '{print $1}')
    echo $md5 > ${work_dir}/sha256.txt
    exit 0
  
  ;;    
    
  *)
    echo "分支不存在"
    exit 1
  ;;
esac

