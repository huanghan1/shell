#!/bin/bash
. /etc/profile
if [[ $# != 3  ]];then
  echo "Usage:$0 实例名 "
  exit 1
fi

app=$1
ptype=$2
to=$3

[ ! -d /opt/settings ] && mkdir -p /opt/settings
if [ $to == "vdev" ];then
   echo "env=dev" > /opt/settings/server.properties
else
   echo "env=fat" > /opt/settings/server.properties
fi

#加载实例对应的端口配置
parfile=`dirname $0`
. ${parfile}/vgsgitparfile.sh

eval port="\$${app}X"

d=`date +"%Y-%m-%d"`
dir=/home/wls81/tomcat/$app
cronlog=/usr/local/sbin/cronolog
log=/data/$app/logs/catalina.out.${d}.log
logdir=/data/$app/logs
[ ! -d $logdir ] && mkdir -p $logdir && chown -R wls81. $logdir
[ ! -d $dir ] && mkdir -p $dir && chown -R wls81. $dir


cd $dir || exit 1
chown -R wls81.wls81 $dir

if [ $ptype == "war" ];then
   [ ! -d webapps ] && mkdir webapps 2>&1 > /dev/null && chown wls81.wls81 webapps
   [ ! -d work ] && mkdir work 2>&1 > /dev/null && chown wls81.wls81 work
   [ ! -d temp ] && mkdir temp 2>&1 > /dev/null && chown wls81.wls81 temp
   [ ! -d logs ] && mkdir logs 2>&1 > /dev/null && chown wls81.wls81 logs
fi

#################################################################################

echo $app | grep -q "-"
[ $? -eq 0 ] && appn=`echo $app | sed -n 's/-//gp'`
[ -z $appn ] && appn=$app

##################################################################################
pid=`ps -ef | grep "${dir}" | grep -v "grep" | awk '{print $2}'`
if [[ ! -z $pid ]];then
   [ $ptype == "war" ] &&  bin/shutdown.sh 
fi
sleep 2
cd $dir && rm -rf $dir/webapps/$app
#################################################################################


#关闭实例后检查是否成功关闭，及清空目录
if [ $ptype == "war" ];then
   pids=`ps -ef | grep  "${dir}/temp" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
else
   pids=`ps -ef | grep  "${dir}/${app}.jar" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
fi

for pid in $pids
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
   
    kill -9 $pid 2>/dev/null
done


if [ $ptype == "war" ];then

for f in `ls -d webapps/*`
do
    echo $f | grep -E -q '.war$'
    if [ $? -eq 0 ]
    then
       echo $f
       war_dir=`echo $f |awk -F "." '{print $1}'`
       echo  "删除war文件，及对应的war目录"
       [ -f ${app}.war ] &&  rm -rf $f 
       [ -f ${app}.war ] && rm -rf $war_dir
       [ ! -f ${app}.war ] && echo "${dir}目录下不存在${app}.war文件,当前只会完成清空work目录并重启的操作"
    fi
done

fi

if [ $ptype == "war" ];then
   pids=`ps -ef | grep  "${dir}/temp" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
else
   pids=`ps -ef | grep  "${dir}/${app}.jar" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
fi


[[ -z $pids ]] && echo "$app 关闭成功"
[[ ! -z $pids ]] && echo "$app 关闭失败" && exit 1
######################################################################
#启动
echo "等待系统启动成功，可能需要几分钟."
if [ $ptype == "war" ];then
   [[ -z $pids ]] && su wls81 bin/startup.sh 
else
   cd $dir || exit 1

   jar_start="java -server -XX:+PrintGCDetails -Xms1024m -Xmx1024m -XX:PermSize=196m -XX:MaxPermSize=512m -jar ${dir}/${app}.jar --server.port=$port  2>&1 | $cronlog $log >> /dev/null & "
   su wls81 -c  "nohup $jar_start "
fi	
#######################################################################
sleep 5
#检验

#pid检查验证
if [ $ptype == "war" ];then
   pids=`ps -ef | grep  "${dir}/temp" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
else
   pids=`ps -ef | grep  "${dir}/${app}.jar" | grep -v "grep" |grep -v 'tailf'| awk '{print $2}'`
fi

if [ ! -z $pids ];then
    echo  "$app 启动成功 " 
    echo "#################################################"
    exit 0
fi

[ -z $pids ] && echo " $app 启动失败" &&  exit 1
 

 
###################################################################
