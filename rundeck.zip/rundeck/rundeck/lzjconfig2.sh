#!/bin/bash

if [ $# != 6 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
src_war_dir=$1
appn=$2
to=$3
create_pro_war=$4
src=$5
config_dir=$6

d=$(date +%Y-%m-%d_%H:%M)

[ ! -d ${src}/$appn ] && mkdir -p ${src}/$appn
cd ${src}/$appn || exit 2
version=`[ -f version ] && cat version`
[ -f ${src}/${appn}/${appn}_${to}.war ] && rm -rf ${src}/${appn}/${appn}_${to}.war
[ -d ${src}/${appn}/tmp ] && rm -rf ${src}/${appn}/tmp
echo $version > version

[ ! -d tmp ] && mkdir tmp

unset cp
#if [ $to == "vdev" ];then
#   [ -f ${src_war_dir} ] && cp -f  ${src_war_dir} ./${appn}_${to}.war
#   [ $? -eq 0 ] && echo "研发环境war包构建完成"
#   exit 0
#fi

################################################################################
function changeConfig {

   if [ ! -d ${config_dir}/$appn ];then
      echo "${appn}的测试配置文件不存在" 
      echo "${appn}的测试包准备失败，，已经退出配置文件替换过程"
      exit 3 
   fi

   #解包
   jar -xf ${appn}.war
   #删除原包
   rm -f ${appn}.war 

   #替换环境配置
   unset cp
   echo "开始准备${to}环境配置文件"
   rsync -az ${config_dir}/${appn}/  WEB-INF/classes/
   [ ! $? -eq 0 ] && echo "替换配置文件失败，已退出替换过程" && flg=1
   [ -f  WEB-INF/classes/logback.xml ] && rm -f WEB-INF/classes/logback.xml
   [ -f  WEB-INF/classes/logback-spring.xml ] && rm -f WEB-INF/classes/logback-spring.xml
   
   [ $flg -eq 1 ] && exit 6

}





function modify_config {
cd tmp ||exit 7
if [ -f ${appn}.war ];then
  if [ $to != "lzjpro" -a $to != "hpre" ];then
      flg=0
      #替换文件
      changeConfig
      [ $flg -eq 1 ] && exit 8
      #封装测试包
      jar -cf ${appn}.war ./*
      [ ! $? -eq 0 ] && exit 9
 
      #移动war包到上层目录
      if [ -f ${appn}.war ];then
         unset mv
         mv -f ${appn}.war ../${appn}_${to}.war
         [ $? -eq 0 ] && echo "${to}测试环境${appn} 构建完成" || exit 10
      else
         echo "封装测试包失败"
         exit 11
      fi
 
  else
 
    if [ $create_pro_war == "yes"  ];then
        [ -f ../${appn}.war ] && rm -f ../${app}.war
        flg=0
        #替换文件
        changeConfig
        [ $flg -eq 1 ] && exit 12
        #封生产包
        jar -cf ${appn}.war ./*
        [ ! $? -eq 0 ] && exit 13

        #移动war包到workspace/war/xxx目录下
        if [ -f ${appn}.war ];then 
              unset mv
              mv -f ${appn}.war ../ || exit 15
              [ $? -eq 0 ] &&  echo "预生产环境${appn} 已经构建完成" || exit 16
        else
             echo "封装预生产包失败"
             exit 17
        fi
  
    else
        echo "create_pro_war 没有设置为yes "
        exit 20
    fi
  fi  
  echo "#################################################"

else
  echo "拉不到war包"
  exit 21
fi
  
    
    
}
######################################################################
[ -f ${src_war_dir} ] && cp -f  ${src_war_dir} tmp/${appn}.war
   
modify_config

