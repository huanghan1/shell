#!/bin/bash
#app_主干命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 trunk crmCenter yes test app_trunk

#app_分支命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 1.4.0 activityCenter no test app_branch

#风控命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 risk-parent_2.7 backendCenter no test risk

#催收命令行测试用例
#sh -x  /data/shell2/shell/rundeck/app_trunk.sh test02 receive receiveWebCenter no test receive
######################################################################
#定义项目对应的maven配置文件路径
#app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
app_trunk_mset="/usr/local/maven-3.5.0/conf/voice_setting.xml"
app_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/tomcat/voice"
tom_dir="/home/wls81/tomcat"
jar_config_dir="/home/wls81/config/voice"
war_config_idr="/data/workspace/config"
workspace_dir="/data/workspace/voicehuidu"
#配置文件路
vdev_configdir="/data/workspace/config/vdev"
vtest01_configdir="/data/workspace/config/vtest01"
vpro_configdir="/data/workspace/config/vpro"

#定义环境对应的svn物理路径
#app 主干
app_trunk="/root/.jenkins/workspace/gsanvoice"
dir2="/root/.jenkins/workspace/gsanvoice"


######################################################################
#定义环境对应的ip
#vdev="172.16.11.195"
vtest01="172.16.11.213"
vpro="172.16.0.191"

#定义环境密码
vdevX="dev"
vtest01X="qytest"
vproX="pro"

######################################################################

#定义项目的要target目录名
qyactivitywar_target="quickcall-activity/quickcall-activity-web"
qyactivityjar_target="quickcall-activity/quickcall-activity-service"
qyaccountwar_target="quickcall-account/quickcall-account-web"
qyaccountjar_target="quickcall-account/quickcall-account-service"
qyuserwar_target="quickcall-user/quickcall-user-web"
qyuserjar_target="quickcall-user/quickcall-user-service"
qycommonjar_target="quickcall-common/quickcall-cmomon-third"
qyadminwar_target="quickcall-admin"
qytaskjar_target="quickcall-task"
qyconsumerjar_target="quickcall-consumer/quickcall-consumer-service"
qyproducerjar_target="quickcall-producer/quickcall-producer-service"
qydataburyjar_target="quickcall-databury/quickcall-databury-services"


#定义项目的要打包目录名
qyactivitywar_build="quickcall-activity"
qyactivityjar_build="quickcall-activity"
qyaccountwar_build="quickcall-account"
qyaccountjar_build="quickcall-account"
qyuserwar_build="quickcall-user"
qyuserjar_build="quickcall-user"
qycommonjar_build="quickcall-common"
qyadminwar_build="quickcall-admin"
qytaskjar_build="quickcall-task"
qyconsumerjar_build="quickcall-consumer"
qyproducerjar_build="quickcall-producer"
qydataburyjar_build="quickcall-databury"


#定义实例对应的端口
qyactivitywarX=18083
qyactivityjarX=18084
qyaccountwarX=18085
qyaccountjarX=18086
qyuserwarX=18087
qyuserjarX=18088
qycommonjarX=18089
qyadminwarX=18090
qytaskjarX=18091
qyconsumerjarX=18092
qyproducerjarX=18093
qydataburyjarX=18094

#定义应用类型
qyactivitywar_type=war
qyactivityjar_type=jar
qyaccountwar_type=war
qyaccountjar_type=jar
qyuserwar_type=war
qyuserjar_type=jar
qycommonjar_type=jar
qyadminwar_type=war
qytaskjar_type=jar
qyconsumerjar_type=jar
qyproducerjar_type=jar
qydataburyjar_type=jar

#包名
qyactivitywar_filename=activityCenter.war
qyactivityjar_filename=activityCenter.jar
qyaccountwar_filename=accountCenter.war
qyaccountjar_filename=accountCenter.jar
qyuserwar_filename=userCenter.war
qyuserjar_filename=userCenter.jar
qycommonjar_filename=quickcall.jar
qyadminwar_filename=admin.war
qytaskjar_filename=voice-task.jar
qyconsumerjar_filename=consumerjar.jar
qyproducerjar_filename=producerjar.jar
qydataburyjar_filename=databuryjar.jar
