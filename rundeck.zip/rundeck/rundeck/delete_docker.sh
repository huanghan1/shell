image_id=`docker images | grep registry-vpc.cn-shanghai.aliyuncs.com | awk '{print $3}'`
for id in $image_id
do
  if [ -n "${id}" ];then
     docker rmi -f $id
  fi
done
