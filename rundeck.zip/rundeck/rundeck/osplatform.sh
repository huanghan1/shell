#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
projects=$4
authority=$5
item=$6


######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/osplatform_main_env.sh

#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$${item}"
eval dir1="\$${item}Api"
###############################main############################################################################################
#判断密码
eval password="\$${to}X"
if [ $authority != $password ];then
   echo "############################################################################################"
   echo "your password is error ................................................."
   echo "############################################################################################"
   exit 1
fi


#执行testall打包
fl=0
cd $dir || fl=1
[ $fl -eq 1 ] && echo "build_all 目录 $dir 不存在" && exit 1

export BUILD_ID="mvn install"
if [ $build_all == "yes" ];then
   echo "清除所有旧包......................"
   echo "开始重新构建全量包..................."
   find ./ -type f -name "*.war" |xargs rm -f {}
   find ./ -type f -name "*.jar" |xargs rm -f {}

   #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
   if [ $item == "microservices" ];then
      $mvnd --settings $msetting clean install  -Dmaven.test.skip=true
      [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5
   elif [ $item == "headline" ];then
        if [ $to == "online" ];then
           $mvnd  --settings $msetting clean install -Dmaven.test.skip=true -Ddubbo.registry.address=zookeeper://zk.xnheadline.com:2181  -Pprod
           [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5
           #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
        elif [ $to == "test01" ];then
           $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true -Ptest
           [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5
           #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
        else
           $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true -Pdev
           [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5
           #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
        fi
   
  else 
         if [ $to == "online" ];then
           $mvnd  --settings $msetting clean install -Dmaven.test.skip=true  -P online
           [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5

        elif [ $to == "test01" ];then
           $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true -P qa
           [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5
        else
           $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true -P rd
           [ ! $? -eq 0 ] && echo "构建全量包失败" && exit 5
        fi
   fi
 
   echo "############################################################################################"
   echo "############################################################################################"
else
   echo "没有构建全量包.....下面将只对所选工程进行构建"
   echo "############################################################################################"
   echo "############################################################################################"
fi
######################################################

NF=$(echo $projects | awk -F "," '{print NF}')

for x in `seq 1 $NF`
	do 
    	project=`echo $projects |awk -v d=$x -F "," '{ print $d }'`
        echo $project
        [ $project == "None" ] && echo "你选择了None" && fl=1 && break
        sh /data/shell2/shell/rundeck/osplatform_deploy.sh  $to $bra_name $build_all $project $item
        echo "################################################"
        sleep 1
    done
#[ $fl -eq 1 ] && exit 1
