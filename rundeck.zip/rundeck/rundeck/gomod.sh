#!/bin/bash
if [ ! $# -eq 6 ];then
   echo "参数错误"
   exit 1
fi
option=$1
deploy=$2
online_mod=$3
run_stat=$4
sleep_time=$5
version=$6

config_dir="/data/shell2/shell/rundeck/modconfig.sh"
call_script="/data/shell2/shell/rundeck/mod.sh"
yaml_file="/root/ansible/bigdata/model_control.yaml"

node="bigdata-test01"

function change_config {
	sed -i "s/^online_mod.*/online_mod=$online_mod/" $config_dir
	sed -i "s/^run_stat.*/run_stat=$run_stat/" $config_dir
	sed -i "s/^sleep_time.*/sleep_time=$sleep_time/" $config_dir
	sed -i "s/^version.*/version=$version/" $config_dir
        ##同步调度脚本与配置脚本
	ansible-playbook $yaml_file  > /dev/null
}

##################################################################
#更新代码
if [ $deploy == "yes" ];then
   
   chown -R wls81.wls81 /data/workspace/model
   rsync -az /data/workspace/config/bigdata/model/${version}/ 172.16.0.211:/home/wls81/model/${version}/
   rsync -az /data/workspace/model/${version}/ 172.16.0.211:/home/wls81/model/${version}/  --exclude-from=/data/workspace/exclude.txt --delete=yes
fi


echo "当前配置信息"

sed -n '1,15p' $config_dir

if [ $option == "初始化运行" ];then
   
   echo "初始化运行调度脚本"
   echo "#############################################"
   sed -i "s/^run_stat.*/run_stat=close/" $config_dir
   #同步配置调度脚本与配置脚本
   ansible-playbook $yaml_file > /dev/null
   
   ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
   num=$?
   while [ $num -eq 0 ]
      do 
         sleep 1
         ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
         num=$?
   done
      
    
   #开启调度脚本
   if [ $run_stat != close ];then
		echo "修改调度配置文件"
		echo "#############################################"
                change_config
		
		echo "开启节点bigdata-mod01上的R模型调度脚本"
                ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
                if [ ! $? -eq 0 ];then
                   ansible $node -m script -a "$call_script $version"
                fi
                
                ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
                
		echo "#############################################"
		echo "检测......"
		ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
		if [ $? -eq 0 ] ;then
		   echo "开启调度成功"
		   echo "#############################################"
		else
		   echo "开启调度失败"
		   echo "#############################################"
		   exit 1
		fi
		
   else
		echo "初始化运行时 run_stat 不能为close"
		exit 1
   fi
   
else
	echo "修改调度配置文件"
	echo "#############################################"
	change_config
	
	echo "检测......"
	ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
	
	if [ $? -eq 0 ] ;then
	   echo "动态配置调度脚本成功"
	   echo "#############################################"
	else
	   echo "开启节点bigdata-mod01上的R模型调度脚本"
           ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
           if [ ! $? -eq 0 ];then
              ansible $node -m script -a "$call_script $version"
           fi

	   ansible $node -m shell -a "ps -ef |grep -v grep |grep mod_control.sh" 2>&1 |grep -q "$node | SUCCESS"
	   
	   if [ $? -eq 0 ] ;then
		   echo "动态配置调度脚本成功"
		   echo "#############################################"
	   else
		   echo "动态配置调度脚本失败"
		   echo "#############################################"
		   exit 1
	   fi
	fi
fi

echo "当前配置信息"

sed -n '1,15p' $config_dir




