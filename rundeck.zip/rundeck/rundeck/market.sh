#!/bin/bash
if [ $# != 2 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi

To=$1
appn=$(echo $2 | awk -F "_" '{print $1}')
ptype=$(echo $2 | awk -F "_" '{print $2}')
ip1="106.15.48.19"
ip2="172.16.0.188"
ip3="172.16.0.190"
setting="/usr/local/maven-3.5.0/conf/settings_market.xml"

#jar包路径
dir="/root/.jenkins/workspace/market/trunk/java/market"
dir1="${dir}/market_biz/market_base_biz/target/"
dir2="/data/workspace/jar"
dir22="/home/wls81/jar/$appn"

#war包路径
dir3="/root/.jenkins/workspace/market/trunk/java/market/loan-parent"
dir4="${dir3}/loan-api/loan-receive-web/target/"
dir5="/home/wls81/tomcat"




mvnd=$(which mvn)

unset cp  
       #_port=(30881)
instance_port=(8808)

#根据输入的实例名以及上面定义的端口数组来获得实例的tom_pid 并记录对应的端口号port
###########################################################################################################
#开始构建
case  ${appn} in   
 shanDaiBiz)
      cd $dir || exit 1
      [ -f ${dir1}/${appn}.jar ] &&  rm -rf ${dir1}/${appn}.jar
      #$mvnd install --settings $setting  -Dmaven.test.skip=true
      $mvnd clean  package install --settings $setting -P test -Dmaven.test.skip=true
      if [ $? -eq 0 ];then
        if [[ ! -f ${dir1}/${appn}.jar ]];then
          echo "打包失败"
          exit 1
        else
           [ ! -d ${dir2}/$appn ] && mkdir -p ${dir2}/$appn && chown -R wls81.wls81 ${dir2}/$appn
           if [ -d ${dir2}/$appn ];then
              src_dir="${dir1}/${appn}.jar"
              #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
              cp -f $src_dir ${dir2}/$appn/
              
              if [[ ! $? -eq 0 ]];then
		 echo "转移jar包失败"
                 exit 1
              else
                  #生成md5值并保存
                  cd ${dir2}/$appn/ || exit 1
                  sha256=$(sha256sum ${appn}.jar | awk '{print $1}')
                  if [ ! -z $sha256 ];then
                     echo $sha256 > sha256.txt
                  else
                     echo "error" > sha256.txt
                     echo "md5值生成失败"
                     exit 1
                  fi
                  d=$(date +%Y-%m-%d_%H:%M)
                  echo $d  > time

	      fi
           else
              echo "${dir2}$appn 目录不存在"
              exit 1
           fi
       fi
     else
        echo "构建失败"
        exit 1
     fi
  ;;
  operationWeb)
      cd $dir3 || exit 1
      [ -d ${dir4}/${appn}.war ] &&  rm -rf ${dir4}/${appn}.war
      $mvnd clean install --settings $setting  -Dmaven.test.skip=true
      if [ $? -eq 0 ];then
      	 if [[ ! -f ${dir4}/${appn}.war ]];then
            echo "打包失败"
            exit 1
         else
            src_dir="${dir4}/${appn}.war"
            create_pro_war=yes
            sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
            
         fi
      else
	 echo "构建失败"
         exit 1
       fi
  ;;

  *)
     echo "实例名不正确"
     exit 1
  ;;

esac
################################################################################################################
#开始部署war包
#echo $appn |grep -q "testall"
if [[ $ptype == "war" ]];then
#if [[ ! $? -eq 0 ]];then
  case $To in
    dev)
       echo "研发环境....."
       scp -P 20022 /data/workspace/war/${appn}/${appn}_svn.war $ip1:${dir5}/${appn}/${appn}.war
       scp -P 20022 /data/shell/war_update.sh $ip1:/data/shell/
       ssh -p 20022 $ip1 "sh /data/shell/war_update.sh $appn"
    ;;
    test01)
       unset cp
       echo "测试环境....."
       scp -P 20022 /data/workspace/war/${appn}/${appn}_test.war $ip2:${dir5}/${appn}/${appn}.war
       rsync -az -e "ssh -p 20022" /data/shell/war_update.sh $ip2:/data/shell/war_updata.sh
       ssh -p 20022 $ip2 "sh /data/shell/war_update.sh $appn"
    ;;
     test02)
       unset cp
       echo "测试环境....."
       scp -P 20022 /data/workspace/war/${appn}/${appn}_svn.war $ip3:${dir5}/${appn}/${appn}.war
       rsync -az -e "ssh -p 20022" /data/shell/war_update.sh $ip3:/data/shell/war_update.sh
       ssh -p 20022 $ip3 "sh /data/shell/war_update.sh $appn"
    ;;

    pro)

       echo "Only create pre war..."
    ;;
 esac
fi
##################################################################################################################
#部署jar包
if [[ $ptype == "jar" ]];then
    case $To in 
	dev)
	   echo "研发环境....."
           rsync -az -e "ssh -p 20022" /data/workspace/config/shanDaiBiz/ $ipi1:/data/workspace/config/shanDaiBiz/
           scp -P 20022 ${dir2}/${appn}/${appn}.jar $ip1:$dir22
           scp -P 20022 /data/shell/jar_update.sh $ip1:/data/shell/
           ssh -p20022 $ip1 "sh /data/shell/jar_update.sh $appn"
        ;;

       test01)
           unset cp
           echo "测试环境....."
           rsync -az -e "ssh -p 20022" /data/workspace/config/shanDaiBiz/ $ip2:/data/workspace/config/shanDaiBiz/
           scp -P 20022 ${dir2}/${appn}/${appn}.jar $ip2:$dir22
           scp -P 20022 /data/shell/jar_update.sh $ip2:/data/shell/
           ssh -p20022 $ip2 "sh /data/shell/jar_update.sh $appn"

       ;;
       test02)
           unset cp
           echo "测试环境....."
           rsync -az -e "ssh -p 20022" /data/workspace/config/shanDaiBiz/ $ip3:/data/workspace/config/shanDaiBiz/
           scp -P 20022 ${dir2}/${appn}/${appn}.jar $ip3:$dir22
           rsync -az -e "ssh -p 20022" /data/shell/jar_update.sh $ip3:/data/shell/jar_updata.sh
           ssh -p20022 $ip2 "sh /data/shell/jar_update.sh $appn"

       ;;

       pro)
           echo "Only create pre war..."
       ;;
    esac
fi

     
