#!/bin/bash
. /etc/profile
if [ $# != 3 ];then
  echo "Usage:$0 实例名 "
  exit 1
fi

app=$1
item=$2
to=$3

. /data/shell2/shell/rundeck/${item}_port_env.sh
eval port="\$$app"
[ ! -z $port ] && serverport="--server.port=$port"

. /data/shell2/shell/rundeck/main_env.sh
#获取配置中心对应的变量值
eval conf_host="\$${to}_host"
eval conf_port="\$${to}_port"
eval conf_env="\$${to}_env"
conf_app=${item}_$app

echo $conf_host
dir=/home/wls81/tomcat/$app
#config="/home/wls81/tomcat/$app/finance-web/classes/"
cronlog="/usr/local/sbin/cronolog"
log1="/data/${app}/logs/catalina.out.%Y-%m-%d.log"
log2="/data/${app}/logs/difconfig.out.%Y-%m-%d.log"

#[ $item == "sports" ] && dosport="--spring.config.location=file:/home/wls81/tomcat/${app}/disconf/download"

jar_start1="java -Ddisconf.env=$conf_env \
                -Ddisconf.app=$conf_app \
                -Ddisconf.conf_server_host=$conf_host \
                -Ddisconf.enable.remote.conf=true \
                -server -Xms1024m -Xmx1024m -jar ${dir}/${app}.jar $serverport $dosport  2>&1 | $cronlog $log1 >> /dev/null &"
jar_start2="java -server -Xms1024m -Xmx1024m -jar ${dir}/${app}.jar $serverport  2>&1 | $cronlog $log1 &"   
jar_config="java -Ddisconf.conf_server_host=$conf_host -Ddisconf.app=$conf_app -Ddisconf.version=1.0.0 -Ddisconf.enable.remote.conf=true -Ddisconf.env=$conf_env -jar ${dir}/configuration.jar 2>&1 | $cronlog $log2 "

##################################################################################
chown -R wls81.wls81  $dir
[ ! -d /data/$app/logs ] && mkdir -p /data/$app/logs
[ -d /data/$app ] && chown -R wls81.wls81 /data/$app
cd $dir || exit 1 


ignore_pid=$$
ignore_ppid=`ps -ef | awk -v pid="$$" '{if($2==pid) print $3}'`

function killapp {
   for pid in `ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}'`
   do
    
      echo $pid | grep -E -q '^[0-9]+$' 
      if [ $? -ne 0 ]
      then
          continue
       fi
       if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
       then
          continue
       fi
       kill -9 $pid 2>/dev/null
    done

    pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')
    if [  -z $pid ];then
    echo "$app closed successful"
    else
        echo "$app closed false"
       exit 1
    fi
}

killapp

###########################################################################
echo "############################################################################################"
echo "开始启动${app},这可能需要几分钟....."
sleep 1

unset mv 
if [ -f ${app}.jar ];then
   if [ $item == "microservices" ];then
      echo "############################################################################################"
      su  wls81 -c "$jar_config"
     
      echo "配置文件下载成功"
      sleep 1
      #启动
      su wls81 -c "nohup $jar_start1"
   else
      #启动
      su wls81 -c  "nohup $jar_start1 "
      sleep 6
      if [ $item == "sports" ];then
         killapp
	 sleep 1
         su wls81 -c  "nohup $jar_start1 "
      fi
   fi

   sleep 5 
   echo "启动检验............"
   pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')
   echo $pid
   if [ -z $pid ] ;then
      echo "$app start false"
      exit 1
   else
      sleep 1
      echo "$app start sucessful"
      exit 0
   fi

else
   echo "$dir目录下没有jar包"
   exit 1
fi
   
   

