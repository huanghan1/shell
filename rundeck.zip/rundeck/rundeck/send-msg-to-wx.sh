#!/bin/bash

token=`curl "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=wx7aeed706587b0ec5&corpsecret=nGR6J3Gzv9Gbsa_ejwKpE7FHaxXqGVRZxyumoa0uwRJesMzDyjOkvo4VmELoKmJz"`


acc_token=`echo $token | sed -r 's/.*:"(.*)",.*/\1/'`


curl "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=$acc_token" -d  "{ \

                \"touser\": \"multimacd\", \

                \"msgtype\": \"text\", \

                \"agentid\": 6, \

                \"text\": { \

                \"content\": \"$1\" \

                }, \

                \"safe\":\"0\" \

                 }"
