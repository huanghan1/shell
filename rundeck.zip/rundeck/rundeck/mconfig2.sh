#!/bin/bash

if [ $# != 4 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
src_war_dir=$1
appn=$2
to=$3
create_pro_war=$4

src="/data/workspace/miaogou"
d=$(date +%Y-%m-%d_%H:%M)

[ ! -d ${src}/$appn ] && mkdir -p ${src}/$appn
cd ${src}/$appn || exit 2
version=`[ -f version ] && cat version`
[ -f ${src}/${appn}/${appn}_${to}.war ] && rm -rf ${src}/${appn}/${appn}_${to}.war
[ -d ${src}/${appn}/tmp ] && rm -rf ${src}/${appn}/tmp
echo $version > version

[ ! -d tmp ] && mkdir tmp

unset cp
if [ $to == "mdev" ];then
   [ -f ${src_war_dir} ] && cp -f  ${src_war_dir} ./${appn}_${to}.war
   [ $? -eq 0 ] && echo "研发环境war包构建完成"
   exit 0
fi

################################################################################
function changeConfig {

   if [ $to != "mpro" ];then
      if [ $to != "mtest01" ];then 
         if [ ! -d ${mpre1_conf}/$appn ];then
	    echo "${appn}的测试配置文件不存在" 
            echo "${appn}的测试包准备失败，，已经退出配置文件替换过程"
	    exit 3 
         fi
      fi

      if [ $to == "mpre" ];then
         if [ ! -d ${mpre2_conf}/$appn ];then
            echo "${appn}的测试配置文件不存在" 
            echo "${appn}的测试包准备失败，，已经退出配置文件替换过程"
            exit 4
         fi
      fi

      if [ $to == "mtest02" ];then
         if [ ! -d ${mtest02_conf}/$appn ];then
            echo "${appn}的测试配置文件不存在" 
            echo "${appn}的测试包准备失败，，已经退出配置文件替换过程"
            exit 6
         fi
      fi


      if [ $to == "hdmpro" ];then
         if [ ! -d ${hdmpro_conf}/$appn ];then
            echo "${appn}的测试配置文件不存在" 
            echo "${appn}的测试包准备失败，，已经退出配置文件替换过程"
            exit 6
         fi
      fi












   else
      if [ ! -d ${mpro_conf}/$appn ];then
	echo "${appn}的生产配置文件不存在" 
	echo "${appn}的生产包准备失败，，已经退出配置文件替换过程"
	exit 5
      fi
   fi

   #解包
   jar -xf ${appn}.war
   #删除原包
   rm -f ${appn}.war 

   #替换环境配置
   unset cp
   echo "开始准备${to}环境配置文件"
   if [ $to != "mpro" ];then
      if [ $to == "mtest01" ] ;then
          rsync -az ${mpre1_conf}/${appn}/  WEB-INF/classes/
         [ ! $? -eq 0 ] && echo "替换配置文件失败，已退出替换过程" && flg=1
      fi
      
      if [ $to == "mpre" ] ;then
          rsync -az ${mpre2_conf}/${appn}/ WEB-INF/classes/
          [ ! $? -eq 0 ] && echo "替换配置文件失败，已退出替换过程" && flg=1
      fi
     
      if [ $to == "mtest02" ] ;then
          rsync -az ${mtest02_conf}/${appn}/ WEB-INF/classes/
          [ ! $? -eq 0 ] && echo "替换配置文件失败，已退出替换过程" && flg=1
      fi


      if [ $to == "hdmpro" ] ;then
          rsync -az ${hdmpro_conf}/${appn}/ WEB-INF/classes/
          [ ! $? -eq 0 ] && echo "替换配置文件失败，已退出替换过程" && flg=1
      fi







   else
      #cp -a ${pro_conf}/${appn}/* WEB-INF/classes/
      rsync -az ${mpro_conf}/${appn}/ WEB-INF/classes/
   fi
   if [ $appn == "crmCenter" ];then
	 unset mv
	 mv -f WEB-INF/classes/base.js commons/base.js
	 [ ! $? -eq 0 ]&& flg=1
	 [ ! $flg -eq 1 ] && echo "crmCenter的base.js 替换ok"
   fi 
   
   if [ $appn == "crmCenter2" ];then
         unset mv
         mv -f WEB-INF/classes/base.js WEB-INF/classes/static/js/base.js
         [ ! $? -eq 0 ]&& flg=1
         [ ! $flg -eq 1 ] && echo "crmCenter2的base.js 替换ok"
   fi

   [ $flg -eq 1 ] && exit 6

}





function modify_config {

mpre1_conf="/data/workspace/config/mpre1"
mpre2_conf="/data/workspace/config/mpre2"
mtest02_conf="/data/workspace/config/mtest02"
mpro_conf="/data/workspace/config/mpro"
hdmpro_conf="/data/workspace/config/hdmpro"
cd tmp ||exit 7
if [ -f ${appn}.war ];then
  if [ $to != "mpro" -a $to != "mpre" -a $to != "hdmpro" ];then
      flg=0
      #替换文件
      changeConfig
      [ $flg -eq 1 ] && exit 8
      #封装测试包
      jar -cf ${appn}.war ./*
      [ ! $? -eq 0 ] && exit 9
 
      #移动war包到上层目录
      if [ -f ${appn}.war ];then
         unset mv
         mv -f ${appn}.war ../${appn}_${to}.war
         [ $? -eq 0 ] && echo "${to}测试环境${appn} 构建完成" || exit 10
      else
         echo "封装测试包失败"
         exit 11
      fi
 
  else
 
    if [ $create_pro_war == "yes"  ];then
        [ -f ../${appn}.war ] && rm -f ../${app}.war
        flg=0
        #替换文件
        changeConfig
        [ $flg -eq 1 ] && exit 12
        #封生产包
        jar -cf ${appn}.war ./*
        [ ! $? -eq 0 ] && exit 13

        #移动war包到workspace/war/xxx目录下
        if [ -f ${appn}.war ];then 
              unset mv
              mv -f ${appn}.war ../ || exit 15
              [ $? -eq 0 ] &&  echo "预生产环境${appn} 已经构建完成" || exit 16
        else
             echo "封装预生产包失败"
             exit 17
        fi
  
	cd .. || exit 18
   	#生成md5值并保存
   	sha256=$(sha256sum ${appn}.war | awk '{print $1}')
   	if [ ! -z $sha256 ];then
       	   echo $sha256 > sha256.txt
  	 else
       	   echo "error" > sha256.txt
           echo "md5值生成失败"
           exit 19
  	fi
  	echo $d  > time
    else
        echo "create_pro_war 没有设置为yes "
        exit 20
    fi
  fi  
  echo "#################################################"

else
  echo "拉不到war包"
  exit 21
fi
  
    
    
}
######################################################################
[ -f ${src_war_dir} ] && cp -f  ${src_war_dir} tmp/${appn}.war
   
modify_config

