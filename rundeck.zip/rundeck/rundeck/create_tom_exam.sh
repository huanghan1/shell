#!/bin/bash


if [ $# != 3 ];then
  echo "Useage:$0 Name Port1 Port2"
  exit 1
fi

dir=~wls81/tomcat
nginx_dir=/home/wls81/nginx/conf/vhost/
pro_name=$1
port1=$2
port2=$3
instance_exam=process1

cd $dir

if [ -d $instance_exam ];then
   cp -f   $pro_name
   #sed -i "s#process1#${pro_name}#" ${pro_name}/conf/logging.properties
   #cp ${nginx_dir}/test.conf ${nginx_dir}/${pro_name}.conf
  # cp ${nginx_dir}/test_upstream.cf ${nginx_dir}/${pro_name}.cf
   
   
fi


   


