#!/bin/bash
app_trunk_mset="/usr/local/maven-3.5.0/conf/walking_setting.xml"

#app_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/tomcat/walking"
tom_dir="/home/wls81/tomcat"
jar_config_dir="/home/wls81/config/walking"
war_config_idr="/data/workspace/config"
workspace_dir="/data/workspace/walking"
#配置文件路
dev_configdir="/data/workspace/config/dev"
test_configdir="/data/workspace/config/test"

#定义环境对应的svn物理路径
#app 主干
app_trunk="/root/.jenkins/workspace/walking"
app_branch="/root/.jenkins/workspace/waling"
dir2="/root/.jenkins/workspace/walking"



######################################################################
#定义环境对应的ip
dev="172.16.0.187"
test="172.16.0.186"

#定义环境密码
devX="dev"
testX="qytest"
proX="pro"


######################################################################

#定义项目的要target目录名
synccache_target="synccache"
walkeureka_target="walkeureka/walking-eureka-server"
activitycenter_target="activitycenter/walking-activity-center-core"
accountcenter_target="accountcenter/walking-account-center-core"
usercenter_target="usercenter/walking-user-center-core"
walkingapigateway_target="walkingapigateway"
webconfig_target="webconfig/walking-web-config-core"
walkjob_target="walkjob/job-core"
walkjobadmin_target="walkjobadmin/job-admin"
riskcenter_target="riskcenter/walking-risk-center-core"

#定义项目的要打包目录名
synccache_build="synccache"
walkeureka_build="walkeureka"
activitycenter_build="activitycenter"
accountcenter_build="accountcenter"
usercenter_build="usercenter"
walkingapigateway_build="walkingapigateway"
webconfig_build="webconfig"
walkjob_build="walkjob/job-core"
walkjobadmin_build="walkjobadmin"
riskcenter_build="riskcenter"


#定义实例对应的端口
synccacheX=9255
walkeurekaX=9214
activitycenterX=9254
accountcenterX=9253
usercenterX=9252
walkingapigatewayX=9227
webconfigX=9213
walkjobX=9256
walkjobadminX=9257
riskcenterX=9258

#定义应用类型
synccache_type=jar
walkeureka_type=jar
activitycenter_type=jar
accountcenter_type=jar
usercenter_type=jar
walkingapigateway_type=jar
webconfig_type=jar
walkjob_type=jar
walkjobadmin_type=war
riskcenter_type=jar
#包名
synccache_filename=walking-sync-cache.jar
walkeureka_filename=walking-eureka-server.jar
activitycenter_filename=walking-activity-center.jar
usercenter_filename=walking-user-center.jar
walkingapigateway_filename=walking-api-gateway.jar
accountcenter_filename=walking-account-center.jar
webconfig_filename=walking-web-config.jar
walkjob_filename=job-core.jar
walkjobadmin_filename=job-admin-1.3.2-SNAPSHOT.war
riskcenter_filename=walking-risk-center.jar
