#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#svn://svn.xnshandai.net/shandai/trunk/loan-parent

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
app=$4
create_pro_war=$5
item=$6
pinpoint=$7
[ -z $pinpoint ] && pinpoint=no

[ $app == "None" -o -z $app ] && echo "The project name is error........" && exit 1
######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/qygitparfile.sh

#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$$item"
dir1="${dir}"
eval build_dir="$dir/\$${app}_build"
eval target_dir="$dir/\$${app}_target"

#应用类型
eval ptype="\$${app}_type"

#包名
eval filename="\$${app}_filename"
#获取环境对应的ip
eval ip="\$$to"
#配置文件路径
eval config_dir="\$${to}_configdir"
######################################################################
#获取项目对应的svn目录名
#echo $app | grep -q "-"
#[ $? -eq 0 ] && appn=`echo $app | sed -n 's/-//gp'`
#[ -z $appn ] && appn=$app
pdir=${target_dir}

############下面是主要方法的定义#######################################
#配置替换
function package {
  fg=0
  cd ${target_dir}  || fg=1
  [ $fg -eq 1 ] && echo "目录${bra_name}下没有${app}这个工程目录" && exit 1
  flag=0
  if [ $build_all == "no" ];then
       cd ${build_dir} 
       #$mvnd --settings $msetting clean install  -Dmaven.test.skip=true
       $mvnd --settings $msetting clean package -P${to} -Dmaven.test.skip=true
       if [ $? != 0 ];then
           echo "$app构建失败" 
           echo "############################################################################################"
           echo "############################################################################################"
           cd ${target_dir} 
           exit 2
       fi
  fi
  
  src_dir="${target_dir}/target/$filename"
  [ ! -f $src_dir ] && echo "$app构建失败" && exit 1
  [ ! -d ${workspace_dir}/$app  ] && mkdir -p ${workspace_dir}/$app
  #替换配置文件，生成各环境war包
  if [ $ptype == "war" ];then
     #appname='userwar'
     #appname='qyaccountwar qyactivitywar  qyadminwar qyuserwar'
     #echo $appname|grep $app
     echo "配置不替换"
     if [ $? = 0 ];then
      unset cp
      [ $to == "vpro" ] && \cp -f  $src_dir ${workspace_dir}/$app/$app.war
      [ $to != "vpro" ] && \cp -f  $src_dir ${workspace_dir}/$app/$app\_$to.war
     else
       sh /data/shell2/shell/rundeck/qygitconfig2.sh  "$src_dir" $app $to $create_pro_war ${workspace_dir} $config_dir
     fi
  else
     unset cp
     [ ! -d ${jar_config_dir}/$app ] && mkdir -p ${jar_config_dir}/$app

     #ssh -p 22 $ip "[ ! -d ${tom_dir}/${app}/config ] && mkdir -p ${tom_dir}/${app}/config"
     #rsync -az -e "ssh -p 22" ${jar_config_dir}/$app ${ip}:${tom_dir}/${app}/config/   
     
     #[ ! $? -eq 0 ] && echo "jar配置文件同步失败...." && exit 1
     
     #appname='qyaccountjar qyactivityjar qyuserjar qytaskjar qyconsumerjar qyproducerjar qydataburyjar'
     #echo $appname|grep $app
     echo "配置不替换"
     if [ $? != 0 ];then
        [ ! -d ${workspace_dir}/$app/tmp ] && mkdir -p ${workspace_dir}/$app/tmp
        cd ${workspace_dir}/$app/tmp || exit 1 
        rm -rf ./*
        cp $src_dir ./${app}_${to}.$ptype

        jar -xf ${app}_${to}.$ptype && rm -f ${app}_${to}.$ptype 
        #配置文件
        \cp -f  $config_dir/$app/* ./
        #[ -f  WEB-INF/classes/logback.xml ] &&   rm -f WEB-INF/classes/logback.xml
        #[ -f  WEB-INF/classes/logback-spring.xml ] &&   rm -f WEB-INF/classes/logback-spring.xml
        chown -R wls81.wls81 ${workspace_dir}/$app 
        jar -cfm ${app}_${to}.$ptype META-INF/MANIFEST.MF ./*

        [ $to == "vpro" ] && \cp -f ${app}_${to}.$ptype ../${app}.$ptype && [ $? -eq 0 ] && echo "环境对应的包已经构建完成"
        [ $to != "vpro" ] && \cp -f ${app}_${to}.$ptype ../${app}_${to}.$ptype
        [ $? -eq 0 ] && echo "环境对应的包已经构建完成"
        rm -f  ${app}_${to}.$ptype
     else 
        unset cp
        cd ${workspace_dir}/$app || exit 1
        [ $to == "vpro" ] && \cp -f $src_dir ${app}.$ptype
        [ $to != "vpro" ] && \cp -f $src_dir ${app}_${to}.$ptype
     fi
 fi
	 
}

#部署
function deploy {
   echo "开始部署${to}环境${app}项目....."
   chown -R wls81.wls81  ${workspace_dir}/$app
   #[ $to == "test01" -o $to == "test02" ] && rsync -avz -e "ssh -p 20022" /etc/hosts ${ip}:/etc/hosts > /dev/null
   cd ${workspace_dir}/$app || exit 1
   if [ $to = "vpro" ];then
      [ -d tmp ] && rm -rf tmp
      filename=`find ${workspace_dir}/${app}/ -name ${app}.${ptype}`
      [[ ! -f $filename ]] && echo "没有可用的$ptype 包" && exit 1
      echo "只生成${to}环境包，不部署..."
      t1sha=`sha256sum ${workspace_dir}/$app/${app}.${ptype} | awk '{print $1}'`
      echo $t1sha > sha256.txt
      timetxt=`date +"%Y-%m-%d-%H"`
      echo $timetxt > ${workspace_dir}/${app}/time
      echo "$bra_name" > ${workspace_dir}/${app}/version
      chown -R wls81.wls81 ${workspace_dir}/${app}
   elif [ $to = "vdev" ];then
      [ -d tmp ] && rm -rf tmp
      filename=`find ${workspace_dir}/${app}/ -name ${app}.${ptype}`
      [[ ! -f $filename ]] && echo "没有可用的$ptype 包" && exit 1
      echo "只生成${to}环境包，不部署..."
      t1sha=`sha256sum ${workspace_dir}/$app/${app}.${ptype} | awk '{print $1}'`
      echo $t1sha > sha256.txt
      timetxt=`date +"%Y-%m-%d-%H"`
      echo $timetxt > ${workspace_dir}/${app}/time
      echo "$bra_name" > ${workspace_dir}/${app}/version
      chown -R wls81.wls81 ${workspace_dir}/${app}
   
   elif [ $to = "vtest02" ];then
      [ -d tmp ] && rm -rf tmp
      filename=`find ${workspace_dir}/${app}/ -name ${app}.${ptype}`
      [[ ! -f $filename ]] && echo "没有可用的$ptype 包" && exit 1
      echo "只生成${to}环境包，不部署..."
      t1sha=`sha256sum ${workspace_dir}/$app/${app}.${ptype} | awk '{print $1}'`
      echo $t1sha > sha256.txt
      timetxt=`date +"%Y-%m-%d-%H"`
      echo $timetxt > ${workspace_dir}/${app}/time
      echo "$bra_name" > ${workspace_dir}/${app}/version
      chown -R wls81.wls81 ${workspace_dir}/${app}

   elif [ $to = "vtest01" ];then
      [ -d tmp ] && rm -rf tmp
      filename=`find ${workspace_dir}/${app}/ -name ${app}.${ptype}`
      [[ ! -f $filename ]] && echo "没有可用的$ptype 包" && exit 1
      echo "只生成${to}环境包，不部署..."
      t1sha=`sha256sum ${workspace_dir}/$app/${app}.${ptype} | awk '{print $1}'`
      echo $t1sha > sha256.txt
      timetxt=`date +"%Y-%m-%d-%H"`
      echo $timetxt > ${workspace_dir}/${app}/time
      echo "$bra_name" > ${workspace_dir}/${app}/version
      chown -R wls81.wls81 ${workspace_dir}/${app}
  else
      [[ ! -f ${app}_${to}.$ptype ]] && echo "没有可用的${ptype}包" && exit 1
      #同步原tomcat目录
      [ -d ${src_tom_dir}/${app} ] &&  rsync -az -e "ssh -p 22" ${src_tom_dir}/${app}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude1.txt > /dev/null
      rsync -az -e "ssh -p 22" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
      #同步java包
      if [ $ptype == "war" ];then
         ssh ${ip} "rm -rf ${tom_dir}/${app}/webapps/${app}.war"
         [ $build_all != "only_restart" ] && scp -rp -P 22 ${workspace_dir}/${app}/${app}_${to}.${ptype} ${ip}:${tom_dir}/${app}/webapps/${app}.war
      else
         [ $build_all != "only_restart" ] && scp -rp -P 22 ${workspace_dir}/${app}/${app}_${to}.${ptype} ${ip}:${tom_dir}/${app}/${app}.jar
      fi
      #echo  "ssh -p 22 $ip "sh /data/shell2/shell/rundeck/qyjar_war_start.sh $app $ptype $to""
      ssh -p 22 $ip "sh /data/shell2/shell/rundeck/qyjar_war_start.sh $app $ptype $to"
      [ ! $? -eq  0 ] && exit 1
      #echo "$bra_name" > /data/workspace/war/${app}/version
      
   fi
  
}

#########define function end ###################################################################################################

#执行package方法
if [ $build_all != "only_restart" ];then
    package
    echo "hconfig2 result:$?"
    [ ! $? -eq 0 ] && echo "配置文件替换失败" && exit 1 
fi

[ $build_all == "only_restart" ] && echo "重启所选应用。。。。。"

#[ $? -eq 1 ] && echo "配置文件替换失败" && exit 1 
#执行部署
export BUILD_ID=restarttomcat_${app}
deploy





