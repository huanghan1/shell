#!/bin/bash
if [ $# != 2 ];then
  echo "参数错误"
  exit 1
fi

app=$1
opt=$2


w_dir="/data/workspace/openxn/dataprobe"
[ $app == "dataprobe" ] && w_dir="/data/workspace/openxn/dataprobe"

dir="/data/shell2/shell/rundeck"

dataprobe="bigdata-openxn"
consumer="bigdata-consumer"
harmonizes="bigdata-engine"
maestro="bigdata-engine"
eval cluster="\$$app"
echo "集群名:$cluster"

cluster_openxn_node=(bigdata-test01 )
cluster_openxn_num=${#cluster_consumer_num[@]}
cluster_consumer_node=(bigdata-test01)
cluster_consumer_num=${#cluster_consumer_node[@]}

cluster_engine_node=(bigdata-test01)
cluster_engine_num=${#cluster_engine_node[@]}


dataprobeX="DataProbe"
consumerX="cn.my.gw.client.RabbitCustomConsumer"
harmonizesX="cn.my.gw.server.Server"
maestroX="cn.robot.axes.LogicEngine"
eval class_name="\$${app}X"
echo "grep key:$class_name"

#关闭consumer的过程
function close_consumer {
  option=$1
  if [ $option == "close" ];then
     for x in `seq 0 $(($cluster_consumer_num-1))`
	   do
	     node=${cluster_consumer_node[x]}
	     echo "关闭集群bigdata-consumer中节点${node} 上的consumer任务"
	     ansible $node -m script -a "${dir}/engine.sh consumer $consumerX $option"
	     echo "#####################################################"
	    sleep 3
     done
     
	 ansible bigdata-consumer -m shell -a "ps -ef|grep -v grep |grep $consumerX" > /dev/null
	 if [ ! $? -eq 0 ];then
            echo "所有consumer 关闭成功"
	 else
	    echo "有consumer 关闭失败"
	    exit 1
	 fi
  else
    echo "close_consumer 的参数不对"
  fi
		 
}
#启动consumer
function start_consumer {
	echo "#####################################################"
	ansible bigdata-consumer -m script -a "${dir}/engine.sh consumer $consumerX start"
	
	ansible bigdata-consumer -m shell -a "ps -ef|grep -v grep |grep $consumerX" > /dev/null
        num=$?
	if [ $num -eq 0 ];then
		echo "start consumer成功 "
		echo "#####################################################"
	else
		echo "start consumer失败 "
		echo "#####################################################"
		exit 1
	fi
}

#操作harmonize或maestro
function go_app {
   ansible $cluster -m script -a "${dir}/engine.sh $app $class_name $opt"
   
   ansible $cluster -m shell -a "ps -ef |grep -v grep |grep $class_name" > /dev/null
   num=$?
   if [ $opt != "close" ];then
	  if [ $num -eq 0 ];then
		echo "${opt} $app成功 "
		echo "#####################################################"
	  else
		echo "${opt} $app失败 "
		echo "#####################################################"
		exit 1
	  fi
	  
   else
      if [ ! $? -eq 0 ];then 
		echo "${opt} $app成功 "
		echo "#####################################################"
	  else
	    echo "${opt} $app失败 "
		echo "#####################################################"
		exit 1
	  fi
   fi
	  
}
############################################################################################################
############################################################################################################

if [ $opt == "deploy"  ];then

	if [ $app == "dataprobe" ];then
           src="/root/.jenkins/workspace/openplatform/dataprobe"
        else
           src="/root/.jenkins/workspace/bigdata-engine/engine/$app"
        fi

        echo "同步代码"
        rm -rf /data/workspace/openxn/${app}/*
        find $src -name "*.zip" -exec cp {} /data/workspace/openxn/${app}/${app}.zip \;
        cd /data/workspace/openxn/${app} || exit 1
        num=`ls *.zip |wc -l`
        if [ $num -eq 1 ];then
           unzip ${app}.zip && rm -f ${app}.zip
           find ./ -type f -name "*.properties" -exec rm -f {} \;
        fi
	   
        rsync -az  -e "ssh -p 22" /data/workspace/openxn/${app}/ 172.16.11.137:/home/wls81/openxn/${app}/ --exclude-from=/data/workspace/exclude.txt
	echo "同步配置文件"    
	d=$(date +"%Y-%m-%d_%H-%M")
	rsync -avz  -e "ssh -p 22" /data/workspace/config/bigdata/openxn/${app}/ 172.16.11.137:/home/wls81/openxn/${app}/
        echo $d > /data/workspace/openxn/${app}/time.txt
	   

  echo "#####################################################"
fi

# close,restart,deploy
case $app in
    dataprobe)
        ansible $cluster -m script -a "${dir}/engine.sh $app $class_name $opt"
        sleep 5
        ansible $cluster -m shell -a "ps -ef |grep -v grep |grep $class_name" > /dev/null
        if [ $opt != "close" ];then
            if [ $? -eq 0 ];then
                echo "${opt} $app成功 "
                echo "#####################################################"
            else
                echo "${opt} $app失败 "
                echo "#####################################################"
                exit 1
            fi
        else 
            if [ ! $? -eq 0 ];then
                echo "${opt} $app成功 "
                echo "#####################################################"
            else
                echo "${opt} $app失败 "
                echo "#####################################################"
                exit 1
            fi
        fi
  ;;  
  consumer)
    
    if [ $opt != "close" ];then
	    echo "先依次关闭集群中的consumer节点，停止对mq的消费"
		echo "#####################################################"
		
	    close_consumer "close"
		echo "启动consumer"
		echo "#####################################################"
		start_consumer
		
    else 
	    echo"依次关闭集群中的consumer节点，停止对mq的消费"
		echo "#####################################################"
	    close_consumer "close"
		
        if [ ! $? -eq 0 ];then
            echo "${opt} $app失败 "
            echo "#####################################################"
            exit 1
        fi
    fi
  ;;
  harmonizes|maestro)
    if [ $opt != "close" ];then
	   echo "先依次关闭集群中的consumer节点，停止对mq的消费"
	   echo "#####################################################"
	   close_consumer "close"
	   if [ ! $? -eq 0 ];then
              echo "${opt} $app失败，请先依次关闭集群中的consumer节点 "
              echo "#####################################################"
              exit 1
           fi
	   
	   echo "启动$app"
	   echo "#####################################################"
           go_app
           sleep 3
	   
           echo "启动consumer"
	   echo "#####################################################"
	   start_consumer

   else
   
	   echo "先依次关闭集群中的consumer节点，停止对mq的消费"
	   echo "#####################################################"
	   close_consumer "close"
	   if [ ! $? -eq 0 ];then
              echo "${opt} $app失败，请先依次关闭集群中的consumer节点 "
              echo "#####################################################"
              exit 1
           fi
	   echo "关闭$app"
	   echo "#####################################################"
	   go_app 

   fi
  ;;

  *)
    echo "error"
  ;;
esac
