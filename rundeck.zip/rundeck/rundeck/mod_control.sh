 #!/bin/bash
d=`date +"%Y-%m-%d %H:%M:%S"`
config="/home/wls81/shell/rundeck/modconfig.sh"
echo "$d -- 开启风控模型调度任务"
while true
   do
        # 加载调度配置
        #. /home/wls81/shell/rundeck/modconfig.sh
        . $config
        src_online_mod="$online_mod"
        hname=`hostname`
        d=`date +"%Y-%m-%d %H:%M:%S"`        
        echo "$d -- ####修改模型定时任务####"
        for x in $(seq 0 $((${#mods[@]}-1)))
          do 
            d=`date +"%Y-%m-%d %H:%M:%S"`
            mod_name=${mods[x]}
            if [ $mod_name == $online_mod ];then
               echo "$d -- 关闭线上模型${src_online_mod}的crontab调度任务"
               ansible $hname -m cron -a "name=$mod_name user=wls81 state=absent" > /dev/null
            else
               eval mod_script="\$$mod_name"
               echo "模型${mod_name}对应的主脚本名:$mod_script"
               if [ $run_stat == "close" ];then
                   ansible $hname -m cron -a "name=$mod_name user=wls81 state=absent" > /dev/null
                   echo "$d -- 关闭线下模型${mod_name}的crontab调度任务"
                else
                   ansible $hname -m cron -a "name=$mod_name user=wls81 state=present minute='0' job='$python ${dir}/${version}/$mod_script >/dev/null 2>&1 '" > /dev/null
                   echo "$d -- 开启线下模型${mod_name}的crontab调度任务"
                fi
            fi  
        done

        d=`date +"%Y-%m-%d %H:%M:%S"` 
        #是否需要关闭调度脚本
        if [ $run_stat == "close" ];then
            echo "$d -- 关闭所有调度脚本任务"
            break
        fi 

        echo "############################################"
        echo "############################################"
        #在秒级调度线上模型
        while true
          do
               #加载调度配置
               #. /home/wls81/shell/rundeck/modconfig.sh
               . $config
               #获取线上模型
               switch_online_mod=$online_mod
               d=`date +"%Y-%m-%d %H:%M:%S"`   
               #是否需要关闭调度脚本
               if [ $run_stat == "close" ];then
                  echo "$d -- 关闭线上模型调度脚本任务"
                  break
               fi 
               
               #执行线上模型脚本
               d=`date +"%Y-%m-%d %H:%M:%S"`
               eval mod_num="\$${switch_online_mod}_num"
               if [ ! -z $mod_num ];then
                   echo "$d -- 开始调度线上模型${online_mod}"
                   
                   $python ${dir}/${version}/$main $mod_num "$d"

                   num=` ps -ef | grep "main_.py"|grep -v "grep"|wc -l `
                   tm=0
                   while [ $num -gt 0 ]
                      do
                        sleep 1
                        tm=$(($tm+1))
                        num=` ps -ef | grep "main_.py"|grep -v "grep"|wc -l `
                   done
                   
                   echo "$d -- 结束调度线上模型${online_mod},运行时间:${tm}秒"
                   
               else
                   echo "$d -- ERROR:线上模型的参数为空"
                   break
               fi
                
               if [ $switch_online_mod != $src_online_mod ];then
                  echo "$d -- 线上模型切换为$switch_online_mod,自动切换线下模型的小时级定时任务"
                  break
               fi
               sleep $sleep_time
        done


    echo "$d -- 自动修改线下模型的小时级定时任务"

done

