#!/bin/bash

if [ $# != 1 ];then
   echo "Usage:$0 输入实例名"
   exit 1
fi

appn=$1
src="/data/workspace/shandai/trunk"
package="/data/workspace/package"
dir1="${package}/trunk/loan-parent/loan-api"
dir2="/data/workspace/war"
dir3="/data/workspace/config"
dir4="src/main/resources"
d=$(date +%Y-%m-%d_%H:%M)


mvnd=$(which mvn)
unset cp

cd $package || exit 1
rm -rf ${package}/*
cp -a $src $package
#rsync -az -e "ssh -p 20022" root@106.15.48.19:/data/workspace/ /data/workspace/ --exclude "*.svn" 
#dtime=`cat /data/workspace/shandai/branches/date.txt`
#echo "svn最后同步时间:$dtime"
#[[ $? != 0 ]] || build="false"
#[[ $build == "false" ]] && echo "svn同步失败" 
#[[ $build == "false" ]] && exit 1

#定义实例对应的端口

       #_port=(8009 8010 8011 8012 8013 8014 8015 8016 8017 8018 8019 8020)
       #_port=(2345 2346 2347 2348 2349 2350 2351 2352 loan-backend-web 2354 2355 2356)
instance_port=(8083 8084 8085 8086 8087 8088 8089 8090 8091 8092 8093 8094)

#根据输入的实例名以及上面定义的端口数组来获得实例的tom_pid 并记录对应的端口号port
case  ${appn} in
		       
                authCenter)
						  cd ${dir1}/loan-authCenter-api || exit 1
						  #用生产配置覆盖测试配置
						  cp -f ${dir3}/${appn}/*  ${dir1}/loan-authCenter-api/${dir4}/
						  if [ ! $? -eq 0 ];then
								echo "生产配置覆盖测试配置 失败"
								exit 1
							fi
						  rm -rf ${dir1}/loan-authCenter-api/target/* 
						  $mvnd package 
						  if [[ ! -f ${dir1}/loan-authCenter-api/target/loan-authCenter-api.war ]];then
							  echo "打包失败"
							  exit 1
						  fi
						  [[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						  rm -rf ${dir2}/${appn}/*
						  cp -f ${dir1}/loan-authCenter-api/target/loan-authCenter-api.war ${dir2}/${appn}/${appn}.war
						  t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}' ` 
						  echo $t1sha > ${dir2}/${appn}/sha256.txt
						  echo $d  > ${dir2}/${appn}/time
                ;;

                userCenter)
						cd ${dir1}/loan-user-api || exit 10
						#用生产配置覆盖测试配置
						cp -f ${dir3}/${appn}/*  ${dir1}/loan-user-api/${dir4}/
						if [ ! $? -eq 0 ];then
								echo "生产配置覆盖测试配置 失败"
								exit 1
							fi
						rm -rf ${dir1}/loan-user-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-user-api/target/loan-user-api.war ]];then
							  echo "打包失败"
							  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-user-api/target/loan-user-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
						echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;

                backendCenter)
						cd ${dir1}/loan-backend-web || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-backend-web/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-backend-web/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-backend-web/target/loan-backend-web.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-backend-web/target/loan-backend-web.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
						echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;
                backendtaskCenter)
						cd ${dir1}/loan-backend-task || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-backend-task/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-backend-task/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-backend-task/target/loan-backend-task.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-backend-task/target/loan-backend-task.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'`
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;

                messageCenter)
						cd ${dir1}/loan-message-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-message-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-message-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-message-api/target/loan-message-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-message-api/target/loan-message-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;

                activityCenter)
						cd ${dir1}/loan-activity-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-activity-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-activity-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-activity-api/target/loan-activity-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-activity-api/target/loan-activity-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;
			
		        debitapiCenter)
						cd ${dir1}/loan-debit-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-debit-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-debit-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-debit-api/target/loan-debit-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-debit-api/target/loan-debit-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;

                debitserviceCenter)
						cd ${dir1}/loan-debit-service-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-debit-service-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-debit-service-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-debit-service-api/target/loan-debit-service-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-debit-service-api/target/loan-debit-service-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'`
		                echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;
				
		        payCenter)
						cd ${dir1}/loan-pay-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-pay-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-pay-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-pay-api/target/loan-pay-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-pay-api/target/loan-pay-api.war ${dir2}/${appn}/${appn}.war
  						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'`
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;
		        bankCenter)
						cd ${dir1}/loan-bank-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-bank-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-bank-api/target/* 
						$mvnd package 
						if [[ ! -f ${dir1}/loan-bank-api/target/loan-bank-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-bank-api/target/loan-bank-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
                	    echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time
		
                ;;
		        payserviceCenter)
						cd ${dir1}/loan-pay-service-api || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/*  ${dir1}/loan-pay-service-api/${dir4}/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						rm -rf ${dir1}/loan-pay-service-api/target/* 
						$mvnd package
                        if [[ ! -f ${dir1}/loan-pay-service-api/target/loan-pay-service-api.war ]];then
						  echo "打包失败"
						  exit 1
						fi						
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan-pay-service-api/target/loan-pay-service-api.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'` 
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;
                crmCenter)
						cd ${dir1}/loan_crm_web || exit 1
						#用生产配置覆盖测试配置
					    cp -f ${dir3}/${appn}/resource/*  ${dir1}/loan_crm_web/${dir4}/ 
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi
						cp -f ${dir3}/${appn}/js/*  ${dir1}/loan_crm_web/src/main/webapp/commons/
						if [ ! $? -eq 0 ];then
							echo "生产配置覆盖测试配置 失败"
						    exit 1
						fi 
						rm -rf ${dir1}/loan_crm_web/target/* 
						$mvnd package
                        if [[ ! -f ${dir1}/loan_crm_web/target/loan_crm_web.war ]];then
						  echo "打包失败"
						  exit 1
						fi						
						[[ ! -d ${dir2}/$appn ]] && mkdir -p ${dir2}/$appn
						rm -rf ${dir2}/${appn}/*
						cp -f ${dir1}/loan_crm_web/target/loan_crm_web.war ${dir2}/${appn}/${appn}.war
						t1sha=`sha256sum ${dir2}/${appn}/${appn}.war | awk '{print $1}'`
			            echo $t1sha > ${dir2}/${appn}/sha256.txt
						echo $d  > ${dir2}/${appn}/time

                ;;


                *)
                    echo "tomcat实例名不正确"
                    exit 1
                ;;

esac

rm -rf /data/workspace/shandai
