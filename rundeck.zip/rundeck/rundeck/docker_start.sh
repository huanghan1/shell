#!/bin/bash

memry=2048

if [ ${type} == "war" ]
  then
   unset cp 
   rm -rf /home/wls81/tomcat/webapps/*
   \cp -f /home/wls81/common/${appname}.war /home/wls81/tomcat/webapps/
   \cp -f /home/wls81/common/server.xml /home/wls81/tomcat/conf/
   cd /home/wls81/tomcat || exit 1
   export memry
   export appname
   ./bin/startup.sh 
   
else 
  dir=/home/wls81/java
  logdir=/data/$app/logs
  [ ! -d $logdir ] && mkdir -p $logdir
  cronlog="/usr/bin/cronolog"
  log="/data/${app}/logs/catalina.out.%Y-%m-%d.log"
  start_port="-Dserver.port=$port"
  startmemry="-Xms${memry}m -Xmx${memry}m"
  
  rm -rf /home/wls81/java/*
  \cp -f /home/wls81/common/${appname}.jar /home/wls81/java/
  cd /home/wls81/java || exit 1
  java  -server -XX:+UseConcMarkSweepGC   -XX:CMSInitiatingOccupancyFraction=85 -XX:+CMSParallelRemarkEnabled -XX:+UseParNewGC $startmemry $pinpoint_str $config_dir $start_port -jar ${dir}/${appname}.jar  $jar_string  2>&1 | $cronlog $log >> /dev/null  &
fi

/bin/bash
