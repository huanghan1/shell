#!/bin/bash

dev_pass=dev
develop_pass=dev
test_pass=qytest
test1_pass=qytest
cloud_pass=dev
master_pass=pro
hotfix_pass=pro

eval pass="\$${branch}_pass"

if [ "$password" != "$pass" ];then 
   echo "#################password is error.....#############################"
   exit 1
fi     
