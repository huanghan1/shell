#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#svn://svn.xnshandai.net/shandai/trunk/loan-parent
#trunk
#dir="/root/.jenkins/workspace/trunk"
#dir1="${dir}/loan-api"
#tom_dir="/home/wls81/tomcat"
unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
app=$3
create_pro_war=$4
authority=$5
item=$6

[ $app == "None" -o -z $app ] && echo "The project name is error........" && exit 1
######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/parfile.sh

#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$$item"
dir1="${dir}/loan-api"

#获取环境对应的ip
eval ip="\$$to"
######################################################################
#获取项目对应的svn目录名
echo $app | grep -q "-"
[ $? -eq 0 ] && appn=`echo $app | sed -n 's/-//gp'`
[ -z $appn ] && appn=$app
eval pdir="\$$appn"
############下面是主要方法的定义#######################################
#配置替换
function package {
  cd ${dir1}/$pdir || exit 1
  flag=0
  if [ $create_pro_war == "ag" ];then
	 [ -d ${dir1}/${pdir}/target ] &&  rm -rf ${dir1}/${pdir}/target
	 $mvnd --settings $msetting clean install  -Dmaven.test.skip=true
	 [ $? -eq 0 ] && flag=1 || flag=2
  fi
  [ $flag -eq 2 ] && echo "构建${app}失败,请找开发确定是否还有未提交的代码" && exit 1

  filedir=`find target -name "*.war" `
  [ ! -z $filedir ] && warfile=`basename $filedir `
  
  if [ ! -f target/$warfile ];then
	 [ $flag -eq 1 ] && echo "构建${app}失败,请找开发确定是否还有未提交的代码"
	 [ $flag -eq 0 ] && echo "testall构建失败,请找开发确定是否还有未提交的代码"
	 exit 1
  else
	 src_dir="${dir1}/${pdir}/target/$warfile"
	 #替换配置文件，生成各环境war包
	 sh /data/shell2/shell/rundeck/config.sh  "$src_dir" $app $to $create_pro_war
  fi
	 
}

#部署
function deploy {
   echo "开始部署${to}环境....."
   #[ $to == "test01" -o $to == "test02" ] && rsync -avz -e "ssh -p 20022" /etc/hosts ${ip}:/etc/hosts > /dev/null
   if [ $to != "pre" ];then
      warfile=`find /data/workspace/war/${app}/ -name ${app}_${to}.war`
      [ ! -f $warfile ] && echo "没有可用的war包" && exit 1
      rsync -az -e "ssh -p 20022" ${tom_dir}/ ${ip}:${tom_dir}/ --exclude-from=/data/workspace/exclude.txt > /dev/null
      rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
      scp -P 20022 /data/workspace/war/${app}/${app}_${to}.war ${ip}:${tom_dir}/${app}/${app}.war
      ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/war_update.sh $app"
      #echo "$bra_name" > /data/workspace/war/${app}/version
   else
      warfile=`find /data/workspace/war/${app}/ -name ${app}.war`
      [ ! -f $warfile ] && echo "没有可用的war包" && exit 1
      echo "只生成预生产包，不部署..."
      echo "$bra_name" > /data/workspace/war/${app}/version
   fi
  
}

#########define function end ###################################################################################################
################################main############################################################################################
#判断密码
eval password="\$${to}X"
if [ $authority != $password ];then
   echo "your password is error ................................................."
   exit 1
fi


#执行testall打包
cd $dir || exit 1
find ./ -type f -name "*.war" |xargs rm -f {}
export BUILD_ID="mvn install"
$mvnd --settings $msetting clean install -Dmaven.test.skip=true

#执行package方法
package

#执行部署
export BUILD_ID=restarttomcat
deploy





