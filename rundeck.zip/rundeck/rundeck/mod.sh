#!/bin/bash
if [ $# != 1 ];then
   echo "参数错误"
   exit 1
fi

app=$1
echo "初始化运行模型调度脚本..."

cd /home/wls81/model/model_1.2 || exit 1
mdir="/home/wls81/shell/rundeck"
logdir="/data/${app}/logs/mod.out.%Y-%m-%d-%H.log"
#set -m "start mod"
su  wls81 -c "nohup sh ${mdir}/mod_control.sh 2>&1 | /usr/local/sbin/cronolog $logdir &"
