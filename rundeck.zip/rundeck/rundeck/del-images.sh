#!/bin/bash

#获取redis消息队列的长度
redisaddr=172.16.0.215
hostn=`cat /etc/hostname`
rediscmd=`which redis-cli`
list_num=`$rediscmd -h $redisaddr llen to-del-images `

if [ $list_num -gt 0 ];then
   for x in `seq 1 $list_num`
   do
     list_info=`$rediscmd -h $redisaddr lpop to-del-images` 
     if [ ! -z $list_info ];then
        IMAGE_ID=`docker images |grep $list_info |grep -v `date  +"%Y.%m.%d"`|awk '{print $3}'`
        if [ -n "${IMAGE_ID}" ];then
          for x in $IMAGE_ID
          do
            #sudo docker rmi -f $x
            echo $x
          done
        fi
     fi
   done
fi
