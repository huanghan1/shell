app=(newsApi searchApi videoApi payApi systemApi activityApi)

activityApi_dir=headline-activity-api/target
searchApi_dir=headline-search-api/target
videoApi_dir=headline-video-api/target
payApi_dir=headline-pay-api/target
systemApi_dir=headline-system-api/target
newsApi_dir=headline-news-api/target

ip="172.16.0.197"
src_tom_dir="/home/wls81/tomcat/headline"
dest_tom_dir="home/wls81/tomcat"
scripts_dir="/data/shell2/shell/rundeck"


dir=/root/.jenkins/workspace/headline-all/headline-content-api

for x in ${app[@]}
 do
   eval app_dir="\$${x}_dir"
   
   packe_dir=${dir}/${app_dir}/$packagename
   
   type=jar

   packagename=`ls ${dir}/${app_dir}/*.${type} |awk -F '[/]' '{print $NF}'`
   packe_dir=${dir}/${app_dir}/$packagename
   dir1=/data/workspace/${type}/headline
   [ ! -f ${dir}/${app_dir}/$packagename ] && exit 1
   [ ! -d ${dir1}/${x}/online ] && mkdir -pv /${dir1}/${x}/online

   cp -a ${dir}/${app_dir}/$packagename /${dir1}/${x}/online/${x}.${type}
   [ -f ${dir1}/${x}/online/${x}.${type} ] && sha256sum /${dir1}/${x}/online/${x}.${type} |awk '{print $1}' >/${dir1}/${x}/online/sha256.txt
   time=`date "+%Y-%m-%d:%H"`
   echo $time >/${dir1}/${x}/online/time.txt
   
   #同步tomcat目录
   rsync -az -e "ssh -p 20022" ${src_tom_dir}/ ${ip}:${dest_tom_dir}/
   #同步代码
   rsync -az -e "ssh -p 20022" ${dir1}/${x}/online/${x}.${type} ${ip}:${dest_tom_dir}/
   #同步脚本
   rsync -az -e "ssh -p 20022" ${scripts_dir}/ ${ip}:${scripts_dir}/
   
   
   
done
