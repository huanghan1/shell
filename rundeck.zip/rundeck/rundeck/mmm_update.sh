#!/bin/bash
. /etc/profile

app=$1
pinpoint=$2
conf=$3
dir=/home/wls81/tomcat/$app
dir1="/home/wls81/config/$app/"
config="/home/wls81/config/$app/application.properties"
cronlog="/usr/local/sbin/cronolog"
log="/data/${app}/logs"
logfile=$log/catalina.out.%Y-%m-%d-%H.log

#jar_start="java -server -Xms1024m -Xmx1024m -jar ${dir}/${app}.jar --spring.config.location=file:$config  2>&1 | $cronlog $logfile >> /dev/null &"

pinpoint_name="pinpoint-bootstrap-1.7.3.jar"
pinpoint_dir="/home/wls81/tomcat/pinpoint"
ppfile=${pinpoint_dir}/$pinpoint_name
hname=`hostname`



#configs="--spring.config.location=file:$config"
configs="-Dspring.config.location=$config"
if [ $app == "mgjobbaoxian" -o $app == "hhhjobbaoxian" ];then
    configs="-Denv=$conf"
fi
if [ $pinpoint == "yes" -a -f $ppfile ];then
   pinpoint_str="-Dpinpoint.agentId=$hname -Dpinpoint.applicationName=$app -javaagent:$ppfile"
   jar_start="java -server -Xms1536m -Xmx1536m $pinpoint_str $configs -jar ${dir}/${app}.jar 2>&1 | $cronlog $logfile >> /dev/null &"
else
   jar_start="java -server -Xms1024m -Xmx1024m $configs -jar ${dir}/${app}.jar 2>&1 | $cronlog $logfile >> /dev/null &"
fi


##################################################################################
chown -R wls81.wls81  $dir $dir1
[ ! -d /data/$app/logs ] && mkdir -p /data/$app/logs
#[ -d /data/$app ] && chown -R wls81.wls81 /data/$app
cd $dir || exit 1 


ignore_pid=$$
ignore_ppid=`ps -ef | awk -v pid="$$" '{if($2==pid) print $3}'`

for pid in `ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}'`
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
    if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
    then
        continue
    fi
    kill -9 $pid 2>/dev/null
done

pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')
if [  -z $pid ];then
  echo "$app closed successful"
else
  echo "$app closed false"
  exit 1
fi
###########################################################################
echo "############################################################################################"
echo "开始启动${app},这可能需要几分钟....."
sleep 1

unset mv 
if [ -f ${app}.jar ];then
   su wls81 -c  "nohup $jar_start "

   sleep 5 
   echo "启动检验............"
   pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')

   if [ -z $pid ] ;then
      echo "$app start false"
      exit 1
   else
      sleep 1
      echo "$app start sucessful"

   fi

else
   echo "$dir目录下没有jar包"
   exit 1
fi
   
   

