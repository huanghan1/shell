#!/bin/bash

if [ $# != 2 ];then
  echo "参数错误"
  exit 1
fi


To=$1
app=$2

#dir=$3
mvnd=$(which mvn)
setting="/usr/local/maven-3.5.0/conf/shandaicaiwu_trunk_settings.xml"

#svn基准目录
svn_dir=/root/.jenkins/workspace/loan-finance-parent
pro_svn_dir=${svn_dir}/${app}/loan-finance-system
wk_dir=/data/workspace/jar/caiwu
pro_wk_dir=${wk_dir}/$app


if [ $app != "dataprope" ];then
  #cd ${pro_svn_dir} || exit 1
  cd ${svn_dir} || exit 1
  echo "开始构建${app}。。。。"
  echo "############################################################################################"
  echo "############################################################################################"

  $mvnd clean  package install --settings $setting -P test -Dmaven.test.skip=true
  num=$?
  echo "############################################################################################"
  echo "############################################################################################"
  echo "构建${app}完成，开始生成${app}.jar"

  if [ $num -eq 0 ];then
     #取得jar包文件名
     cd ${pro_svn_dir} || exit 1

     [ -d target ] && filedir=`find target -name "*.jar" `
     [ ! -z $filedir ] && jarfile=`basename $filedir ` 
     if [[ ! -f ${pro_svn_dir}/target/$jarfile ]];then
        echo "############################################################################################"
        echo "############################################################################################"
        echo "打包失败"
        echo "构建${app}失败,请找开发确定是否还有未提交的代码"
        exit 1
     else
       [ ! -d $pro_wk_dir ] && mkdir -p $pro_wk_dir
       if [ -d $pro_wk_dir ];then
	  src_dir="${pro_svn_dir}/target/$jarfile"
	  #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
          unset cp
	  cp -f $src_dir  ${pro_wk_dir}/$app.jar

	  if [[ ! $? -eq 0 ]];then
		 echo "转移${app}的jar包失败"
		 exit 1
	  else
                  sleep 2
                  echo "############################################################################################"
		  echo "创建${app}.jar成功，生成md5.....记录时间...."
		  cd $pro_wk_dir || exit 1
		  sha256=$(sha256sum ${app}.jar | awk '{print $1}')
		  if [ ! -z $sha256 ];then
			 echo $sha256 > sha256.txt
		  else
			 echo "error" > sha256.txt
			 echo "md5值生成失败"
			 exit 1
		  fi
		  d=$(date +%Y-%m-%d_%H:%M)
		  echo $d  > time

	  fi
          echo "############################################################################################"
          echo "构建${app}完成."
          echo "############################################################################################"
        else
	  echo "${dir2}$appn 目录不存在"
	  exit 1
        fi
     fi
  else
     echo "构建失败"
     exit 1
  fi

fi
#exit 0

dev_ip="106.15.48.19"
test03_ip="172.16.0.192"
test06_ip="172.16.0.197"
config_dir="/data/workspace/config/caiwu/${app}/"
app_dir="/home/wls81/jar/caiwu/$app/"
script_dir="/data/shell2/shell/rundeck/caiwu_update.sh"

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
       test03)
           unset cp
           echo "开始部署${app}的测试环境....."
           rsync -az -e "ssh -p 20022" $config_dir $test03_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test03_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $test03_ip:$app_dir
           ssh -p 20022 $test03_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;
       test06)
           unset cp
           echo "测试环境....."
           rsync -az -e "ssh -p 20022" $config_dir $test06_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test06_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/$app.jar $test06_ip:$app_dir
           ssh -p 20022 $test06_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0
       ;;

       pro)
           echo "Only create pre war..."
       ;;
    esac
fi

