#!/bin/bash
. /etc/profile

app=$1
pinpoint=$2
con=$3
dir=/home/wls81/tomcat/$app
dir1="/home/wls81/config/$app/"
config="/home/wls81/config/$app/"
cronlog="/usr/local/sbin/cronolog"
log="/data/${app}/logs"
logfile=$log/catalina.out.%Y-%m-%d-%H.log
#chown -R wls81.wls81 $log
#jar_start="java -server -Xms1024m -Xmx1024m -jar ${dir}/${app}.jar --spring.config.location=file:$config  2>&1 | $cronlog $logfile >> /dev/null &"
#if [ $app == "messageCrm" ];then
#    con="-Dspring.config.location=${config}"
#fi
pinpoint_name="pinpoint-bootstrap-1.7.3.jar"
pinpoint_dir="/home/wls81/tomcat/pinpoint"
ppfile=${pinpoint_dir}/$pinpoint_name
hname=`hostname`
if [ $pinpoint == "yes" -a -f $ppfile ];then
   pinpoint_str="-Dpinpoint.agentId=$hname -Dpinpoint.applicationName=$app -javaagent:$ppfile"
   jar_start="java -server -Xms512m -Xmx512m $pinpoint_str $con -jar ${dir}/${app}.jar 2>&1 | $cronlog $logfile >> /dev/null &"
else
   jar_start="java -server -Xms512m -Xmx512m $con -jar ${dir}/${app}.jar 2>&1 | $cronlog $logfile >> /dev/null &"
fi


##################################################################################
#chown -R wls81.wls81  $dir $dir1
[ ! -d /data/$app/logs ] && mkdir -p /data/$app/logs
#[ -d /data/$app ] && chown -R wls81.wls81 /data/$app
chown -R wls81.wls81 /data/$app/logs
cd $dir || exit 1 
chown -R wls81.wls81 /home/wls81/tomcat/$app

ignore_pid=$$
ignore_ppid=`ps -ef | awk -v pid="$$" '{if($2==pid) print $3}'`

for pid in `ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}'`
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
    if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
    then
        continue
    fi
    kill -9 $pid 2>/dev/null
done

pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')
if [  -z $pid ];then
  echo "$app closed successful"
else
  echo "$app closed false"
  exit 1
fi
###########################################################################
echo "############################################################################################"
echo "开始启动${app},这可能需要几分钟....."
sleep 1

unset mv 
if [ -f ${app}.jar ];then
   su wls81 -c  "nohup $jar_start "

   sleep 5 
   echo "启动检验............"
   pid=$(ps -ef | grep -E "${dir}/${app}.jar" |grep -v "grep" | awk '{print $2}')

   if [ -z $pid ] ;then
      echo "$app start false"
      exit 1
   else
      sleep 1
      echo "$app start sucessful"

   fi

else
   echo "$dir目录下没有jar包"
   exit 1
fi
   
   

