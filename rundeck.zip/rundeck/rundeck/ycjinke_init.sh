#!/bin/bash
app=$1
#item=$2
#ip=$3
#idc=$4
item=ycjinke
ip=172.16.0.215
idc=yace

echo "start init" > /tmp/init.log
export LANG=en_US.UTF-8

#init hostname
local_ip=`/usr/sbin/ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | cut -f1 -d '/'`
num=`echo $local_ip |awk -F "." '{print $4}'`
if [ $num -le 10 ];then
   num=$(($num+10))
fi
local_hostname="${item}-${app}-$num"
hostnamectl set-hostname $local_hostname
#注册redis 以便能自动增加到zabbix
redis_dir="/usr/local/bin/redis-cli"
/usr/local/bin/redis-cli -h $ip set ${local_ip}_$local_hostname ${app}:${local_ip}
echo "注册到redis done" >> /tmp/init.log


#init hosts
#grep -q "#hosts modfiyed" /etc/hosts
#if [ ! $? -eq 0 ];then
> /etc/hosts
cat >> /etc/hosts << EOF
127.0.0.1   localhost localhost.localdomain localhost4 localhost
127.0.0.1 shandai-4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
#阿波罗
#172.16.11.4    apollo-v11-new apollo.51huihuahua.com
#压测域名映射
101.132.240.217 rm-uf6c186wq9ofsc6r4.mysql.rds.aliyuncs.com
172.16.12.227   r-uf6b6b930a3316c4.redis.rds.aliyuncs.com
172.16.12.227   hdmqzk.51qyin.com
172.16.12.227   hdeureka1.51qyin.com
172.16.12.227   hdeureka2.51qyin.com
172.16.12.227   hdeureka3.51qyin.com
EOF
echo "hosts init done" >> /tmp/init.log



#apollo环境参数 
[ ! -d /opt/settings ] && mkdir -p /opt/settings
cat << EOF > /opt/settings/server.properties
env=fat
idc=$idc
EOF

#创建/tmp
[ ! -d /tmp/$app ] && mkdir -p /tmp/$app
chown -R wls81.wls81 /tmp/$app

#增加crontab
#grep -q "#Ansible: register to redis" /var/spool/cron/root
#if [ ! $? -eq 0 ];then
> /var/spool/cron/root
echo "#Ansible: register to redis" >> /var/spool/cron/root
echo "*/2 * * * * /usr/local/bin/redis-cli -h $ip expire ${local_ip}_$local_hostname 300 " >> /var/spool/cron/root
#fi

