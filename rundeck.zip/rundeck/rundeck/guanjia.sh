
bra_name=$1
target_dir=$2
#JOB_BASE_NAME=$2
option=$3
app=$4
jar_name_str=$5
start_option="$6"
pinpoint="$7"
dir_1="$8"

#bra_name=`echo $GIT_BRANCH |awk -F "/" '{print $2}'`
work_dir="/data/workspace/jar/new_guanjia/${app}/$bra_name"
if [[ $4 == guanjiaapigatewayfdd ]];then
    dir=/root/.jenkins/workspace/guanjia/$target_dir/target
else 
    dir=/root/.jenkins/workspace/guanjia/$dir_1/$target_dir/target
fi 
conf_dir=/home/wls81/config/fenduoduo/$app
conf_dir1=/home/wls81/config/fenduoduo/pre/$app
tom_dir=/home/wls81/tomcat
tomcat_dir=${tom_dir}/fenduoduo/$app
develop_ip=172.16.18.52
test_ip=172.16.11.194
pre_ip=172.16.11.194
#pre_ip=172.16.0.197
pre_dir=/data/workspace/guanjia/${app}/

[ ! -d $work_dir ] && mkdir -p $work_dir
[ ! -d $tomcat_dir ] && mkdir -p $tomcat_dir
[ ! -d $conf_dir  ] && mkdir -p $conf_dir
[ ! -d $pre_dir ] && mkdir -p $pre_dir

eval ip="\$${bra_name}_ip"

cd $dir
jar_name=`ls | grep -E "$jar_name_str"`
[[ ! -f $jar_name ]] && echo "没有可用的jar包" &&  exit 1
unset cp
cp -f $jar_name ${work_dir}/${app}.jar

chown -R wls81. $work_dir

case ${bra_name} in
   master)      
    #记录打包时间
    cd $dir
    jar_name=`ls | grep -E "$jar_name_str"`
    [[ ! -f $jar_name ]] && echo "没有可用的jar包" &&  exit 1
    unset cp
    cp -f $jar_name ${pre_dir}/${app}.jar
    chown -R wls81. $pre_dir
    echo "记录打包时间.................."
    md5=$(sha256sum ${pre_dir}/${app}.jar  |awk '{print $1}')
    dt=`date +"%Y-%m-%d %H:%M"`
    echo $md5 > ${pre_dir}/sha256.txt
    echo $dt > ${pre_dir}/time
    echo "$bra_name" > ${work_dir}/version
    echo "生产包已经准备好..............."
    ##同步pinpoint 
    #rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${pre_ip}:${tom_dir}/pinpoint/ > /dev/null
    #同步tomcat
    #if [ $option == "restart" ];then
    #  rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    #else
    #  rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    #fi
        
    #同步配置文件
    #[ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir1}/ ${pre_ip}:${conf_dir}/
    #同步脚本
    #rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ ${pre_ip}:/data/shell2/shell/rundeck/
        
    #同步jar包
    #[ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ ${pre_ip}:${tom_dir}/${app}/

    #重新启动
    echo "############################################################################################"
    echo "开始启动${app},这可能需要几分钟....."
    echo "........"
    sleep 1
    echo "..."
    echo "启动检验............"
    #ssh -p 20022 ${pre_ip} "sh /data/shell2/shell/rundeck/new_guanjia_update.sh $app $start_option $pinpoint" &
    sleep 12
    #ssh -p 20022 ${pre_ip} "ps -ef |grep  ${app}.jar |grep -v grep "
    #[ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    exit 0
       
   ;;
    
   develop|test|pre|hotfix)
    ##同步pinpoint 
    rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${ip}:${tom_dir}/pinpoint/ > /dev/null 
    #同步tomcat
    if [ $option == "restart" ];then
      rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    else
      rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    fi
        
    #同步配置文件
    [ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir}/ ${ip}:${conf_dir}/
    #同步脚本
    rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
        
    #同步jar包
    [ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ $ip:${tom_dir}/${app}/

    #重新启动
    echo "############################################################################################"
    echo "开始启动${app},这可能需要几分钟....."
    echo "........"
    sleep 1
    echo "..."
    echo "启动检验............"
    set -m "test"
    ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/new_guanjia_update.sh $app  $start_option $pinpoint" &
    sleep 12
    ssh -p 20022 $ip "ps -ef |grep  ${app}.jar |grep -v grep "
    [ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    exit 0
  
  ;;    
    
  *)
    echo "分支不存在"
    exit 1
  ;;
esac

