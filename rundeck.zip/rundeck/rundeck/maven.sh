#!/bin/bash

cd  /data/workspace/shandai
/usr/bin/svn up
cd /data/workspace/shandai/trunk/loan-parent

/usr/local/maven-3.5.0/bin/mvn clean install 

unset cp
cp -f /data/workspace/shandai/trunk/loan-parent/loan-api/loan-user-api/target/loan-user-api.war  /home/wls81/tomcat/$1/$1.war
