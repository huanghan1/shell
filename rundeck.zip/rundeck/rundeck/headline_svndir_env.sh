#!/bin/bash

######################################################################
#定义项目的要svn目录名
newsApi=headline-news-api
searchApi=headline-search-api
videoApi=headline-video-api
payApi=headline-pay-api
systemApi=headline-system-api
activityApi=headline-activity-api
jobrule=headline-rule
