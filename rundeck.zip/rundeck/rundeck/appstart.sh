#!/bin/bash

#####################var#################################
> /home/wls81/tmp/var.txt
memry=$memry
[ -z $memry ] && memry=2048m
echo  "memry=$memry"  >> /home/wls81/tmp/var.txt

port=$port
[ -z $port ] && port=8080
echo "port=$port" >> /home/wls81/tmp/var.txt

appname=$appname
[ -z $appname ] && appname=none
echo "appname=$appname" >> /home/wls81/tmp/var.txt

ptype=$ptype
[ -z $ptype ] && ptype=war
echo "ptype=$ptype" >> /home/wls81/tmp/var.txt

shdowp=1$port
[ $port -eq 8080 ] && shdowp=8005

cluster=$cluster
echo "cluster=$cluster" >> /home/wls81/tmp/var.txt

pinpoint=$pinpoint
[ -z $pinpoint ] && pinpoint=no
echo "pinoint=$pinpoint" >> /home/wls81/tmp/var.txt

pinpoint_ip=$pinpoint_ip
echo "pinpoint_ip=$pinpoint_ip" >> /home/wls81/tmp/var.txt

config_dir=$config_dir
echo config_dir=$config_dir >> /home/wls81/tmp/var.txt

jar_string=$jar_string
echo "jar_string=$jar_string" >> /home/wls81/tmp/var.txt

com_dir=/home/wls81/common
ppfile="/home/wls81/pinpoint/pinpoint-bootstrap-1.8.0.jar"

logdir="$logdir"


################pinpoint##################################
function modify_setenv {
hname=`hostname`
cat >> bin/setenv.sh << EOF
#start pinpoint script
[ -z \$pinpoint ] && pinpoint=no
[ -z \$appname ] && appname=none
if [ \$pinpoint == "yes" -a \$appname != "none" ];then
   if [ -f \$ppfile ];then
      CATALINA_OPTS="\$CATALINA_OPTS -javaagent:$ppfile"
      CATALINA_OPTS="\$CATALINA_OPTS -Dpinpoint.agentId=$hname"
      CATALINA_OPTS="\$CATALINA_OPTS -Dpinpoint.applicationName=$appname"
     fi
   fi
else
   echo "cluster config error"
fi
EOF
}

if [ $pinpoint == yes ];then
   if [ -z $cluster -o -z $pinpoint_ip];then
      pinpoint_str=" "
      echo "pinpoint cluster config error or pinpoint_id config error"
   else
      grep "start pinpoint script" /home/wls81/tomcat/bin/setenv.sh
      if [ ! $? -eq 0 ];then
	 modify_setenv
      fi
      sed -i "s/127.0.0.1/$pinpoint_ip/" /home/wls81/pinpoint/pinpoint.config
      pinpoint_str="-Dpinpoint.agentId=$cluster -Dpinpoint.applicationName=$appname -javaagent:$ppfile"
   fi
else
   pinpoint_str=" "
fi

ifrestart=0
while true
     do
     ############################start applicaiton#######################
	if [ ${ptype} == "war" -a $appname != "none" ] 
	  then
	   dir=/home/wls81/tomcat
	   if [ -f $dir/${appname}.war ];then
	      sha1=`sha256sum $dir/${appname}.war |awk '{print $1}'`
	      sha2=`sha256sum $com_dir/${appname}.war |awk '{print $1}'`
	      if [ $sha1 != $sha2 ];then
	         [ -f $com_dir/${appname}.war ] && flag1=1 || flag1=0
	      else
	         flag1=0
                 [ $ifrestat == "0" ] && ifrestart=1
	      fi
	   else
	      [ -f $com_dir/${appname}.war ] && flag1=1 || flag1=0
	   fi
	   
	   unset cp 
	   if [ $flag1 -eq 1 ];then
              ifrestart=1
              \cp -f $com_dir/${appname}.war $dir/webapps/
           fi

	   #modify server.xml
	   sed -i "s/8080/$port/" $dir/conf/server.xml
	   sed -i "s/8005/$shdowp/" $dir/conf/server.xml

	   cd $dir || exit 1
           if [ $ifrestart == "1" ];then
	      pid=`ps -ef | grep ${dir}/temp| grep -v grep  |awk '{print $2}'`
	      echo "shutdown tomcat....."
	      ./bin/shutdown.sh
	      sleep 10
	      kill -9 $pid 2>&1 /dev/null
	   
	     export memry
	     export appname
	     export pinpoint
	     export appname
	     export cluster
             export logdir
	     echo "start tomcat ......."
	     ./bin/startup.sh 
          fi
	   
	elif [ $ptype == "jar" -a $appname != "none" ];then
	  dir=/home/wls81/java
	  cronlog="/usr/local/sbin/cronolog"
	  log="$logdir/catalina.out.%Y-%m-%d-%H.log"
	  start_port="-Dserver.port=$port"
	  startmemry="-Xms${memry} -Xmx${memry}"
	  
	   if [ -f $dir/${appname}.jar ];then
	     sha1=`sha256sum $dir/${appname}.jar |awk '{print $1}'`
	     sha2=`sha256sum $com_dir/${appname}.jar |awk '{print $1}'`
	     if [ $sha1 != $sha2 ];then
	        [ -f $com_dir/${appname}.jar ] && flag1=1 || flag1=0
	     else
	        flag1=0
                [ $ifrestat == "0" ] && ifrestart=1
	     fi
	   else
              [ -f $com_dir/${appname}.jar ] && flag1=1 || flag1=0
	   fi

	  unset cp 
	  if [ $flag1 -eq 1 ];then
             ifrestart=1
              \cp -f $com_dir/${appname}.jar $dir/
          fi

	  cd $dir || exit 1
          if [ $ifrestart == "1" ];then
	     pid=`ps -ef | grep ${dir}/${appname}.jar| grep -v grep  |awk '{print $2}'`
	     [ ! -z $pid ] && kill $pid
	     echo "shutdown java application......."
	     sleep 10
	     kill -9 $pid 2>&1 /dev/null
	     echo "start java applicaiton........"
	     java  -server -XX:+UseConcMarkSweepGC   -XX:CMSInitiatingOccupancyFraction=85 -XX:+CMSParallelRemarkEnabled -XX:+UseParNewGC $startmemry $pinpoint_str $config_dir $start_port -jar ${dir}/${appname}.jar  $jar_string  2>&1 | $cronlog $log >> /dev/null  &
          fi

	fi


	################################print log#######################################
	if [ $appname != "none" ];then
	  while true 
	      do
                 #####################monitor ifupdate application###############################
                 echo "monitor ifupdate"
                 ifrestart=2
	         ifupdate=0
		 ifoutwhile=0
	         if [ -f $logdir/${appname}.$ptype ] ;then
                   sha1=`sha256sum $logdir/${appname}.$ptype |awk '{print $1}'`
		   if [ -f $com_dir/${appname}.$ptype ];then
		      sha2=`sha256sum $com_dir/${appname}.$ptype |awk '{print $1}'`
		   	 if [ $sha1 != $sha2 ];then
		            if [ -f $logdir/$sha1 ];then
		   	       ifupdate=`cat $logdir/$sha1`
		    	       rm -f $logdir/$sha1
		    	       if [ $ifupdate == "1" ];then
                                  ifoutwhile=1
                                  ifrestart=1
                               fi
		    	     else
		     	      ifupdate=0
		    	     fi
		    		 
		    	 else
		          ifupdate=0
		         fi
		   else
		     ifupdate=`cat $logdir/$sha1`
		     rm -f $logdir/$sha1
		     if [ $ifupdate == "1" ];then
                        ifoutwhile=1
                        ifrestart=1
                     fi
		   fi
		else
		   ifupdate=0
		fi
	
		if [ $ifupdate == "1" ];then
		  unset cp 
		  \cp -f $logdir/${appname}.$ptype $com_dir/
	          rm -f $logdir/${appname}.$ptype
		fi
                
                ################# monitor ifrestart ######################
	        dstr=`date +"%Y-%m-%d"`
                sha1=`echo ${cluster}-$dstr |sha256sum |awk '{print $1}'`
                if [ -f $logdir/$sha1 ];then
                   ifrestart=`cat $logdir/$sha1`
                   rm -f  $logdir/$sha1
                   if [ $ifrestart == "1" ];then
                      ifoutwhile=1
                   else
                      ifoutwhile=0
                   fi 
                fi
                   
                sleep 3
		[ $ifoutwhile == "1" ] && break
		  
	 done

     else
       sleep 5      
       echo "var config error ........ application start false"
       echo "#####check vars########"
       cat /home/wls81/tmp/var.txt
     fi
done

tail -f /dev/null
