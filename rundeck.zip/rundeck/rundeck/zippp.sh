#!/bin/bash
if [ $# != 1 ];then
  echo "参数错误"
  exit 1
fi

app=$1

hdir="/home/wls81/tomcat/$app"

if [ "$app" == "dataprobe" -o "$app" == "hhhdataprobe" -o "$app" == "sddataprobe" -o "$app" == "gjdataprobe" -o "$app" == "hhhroute" -o "$app" == "hhhprodataprobe" -o "$app" == "dxdataprobe" -o "$app" == "hydataprobe" -o "$app" == "mgdataprobe" -o "$app" == "fgdataprobe" ];then
hdir="/home/wls81/openxn/$app"
fi 
[ -d $hdir ] && mkdir -pv $hdir
dir="/data/shell2/shell/rundeck"

dataprobeX="/home/wls81/openxn/$app"
sddataprobeX="/home/wls81/openxn/$app"
hhhdataprobeX="/home/wls81/openxn/$app"
gjdataprobeX="/home/wls81/openxn/$app"
dxdataprobeX="/home/wls81/openxn/$app"
hydataprobeX="/home/wls81/openxn/$app"
mgdataprobeX="/home/wls81/openxn/$app"
fgdataprobeX="/home/wls81/tomcat/$app"

hhhprodataprobeX="/home/wls81/openxn/$app"
hhhrouteX="/home/wls81/openxn/$app"

dataprobe_port="4860"
consumerX="cn.my.gw.mq.MainConsumer"
harmonizesX="cn.my.gw.server.Server"
maestroX="LogicEngine"
maestroX="cn.robot.axes.core.LogicEngine 55555 BL"

tdconsumerX="cn.my.gw.mq.MainConsumer"
tdharmonizesX="cn.my.gw.server.Server"
tdmaestroX="LogicEngine"

eval class_name="\$${app}X"

cronlog="/usr/local/sbin/cronolog"
log="/data/${app}/logs/catalina.out.%Y-%m-%d-%H.log"

chown -R wls81.wls81 $hdir
chown -R wls81.wls81 ${class_name}
cd ${class_name} || exit 1

ignore_pid=$$
ignore_ppid=`ps -ef | awk -v pid="$$" '{if($2==pid) print $3}'`
for pid in `ps -ef | grep -E "${class_name}" |grep -v "grep" | awk '{print $2}'`
do
    
    echo $pid | grep -E -q '^[0-9]+$' 
    if [ $? -ne 0 ]
    then
        continue
    fi
    if [ $ignore_pid -eq $pid -o $ignore_ppid -eq $pid ]
    then
        continue
    fi
    kill -9 $pid 2>/dev/null
done
echo "关闭成功"
echo "开始启动"
su wls81 -c "nohup sh ${class_name}/${app}.sh 2>&1 | $cronlog $log &"
echo "启动$app任务"


