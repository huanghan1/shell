#!/bin/bash
bra_name=$1
JOB_BASE_NAME=$2
option=$3
app=$4
jar_name_str=$5
start_option="$6"
pinpoint="$7"

apigateway="api-gateway"
openplatformrisk="open-platform-risk"
openplatformcollect="open-platform-collect"
openplatformloanmanager="open-platform-loan-manager"
registrycenter="registry-center"
openplatformuserprofile="open-platform-user-profile"

eval d="\$$app"
echo $app
echo $d

#bra_name=`echo $GIT_BRANCH |awk -F "/" '{print $2}'`
work_dir="/data/workspace/bigdata/${app}"
dir=/data/workspace/bigdata/$d/target
conf_dir=/home/wls81/config/bigdata/$app
conf_dir1=/home/wls81/config/bigdata/pre/$app
tom_dir=/home/wls81/tomcat
tomcat_dir=${tom_dir}/$app
develop_ip=106.15.48.19
test_ip=172.16.0.211
#pre_ip=172.16.0.190

[ ! -d $work_dir ] && mkdir -p $work_dir
[ ! -d $tomcat_dir ] && mkdir -p $tomcat_dir
[ ! -d $conf_dir  ] && mkdir -p $conf_dir

eval ip="\$${bra_name}_ip"

cd $dir
jar_name=`ls | grep -E "$jar_name_str"`
[[ ! -f $jar_name ]] && echo "没有可用的jar包" &&  exit 1
unset cp
cp -f $jar_name ${work_dir}/${app}.jar


case ${bra_name} in
   master)      
    #记录打包时间
    echo "记录打包时间.................."
    md5=$(sha256sum ${work_dir}/${app}.jar  |awk '{print $1}')
    dt=`date +"%Y-%m-%d %H:%M"`
    echo $md5 > ${work_dir}/sha256.txt
    echo $dt > ${work_dir}/time
    echo "$bra_name" > ${work_dir}/version
    echo "生产包已经准备好..............."
       
    ##同步pinpoint 
    #rsync -az -e "ssh -p 22" ${tom_dir}/pinpoint/ ${pre_ip}:${tom_dir}/pinpoint/ > /dev/null
    #同步tomcat
    #if [ $option == "restart" ];then
    #  rsync -az -e "ssh -p 22" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    #else
    #  rsync -az -e "ssh -p 22" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    #fi
        
    #同步配置文件
    #[ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir1}/ ${pre_ip}:${conf_dir}/
    #同步脚本
    #rsync -az -e "ssh -p 22" /data/shell2/shell/rundeck/ ${pre_ip}:/data/shell2/shell/rundeck/
        
    #同步jar包
    #[ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ ${pre_ip}:${tom_dir}/${app}/

    #重新启动
    #echo "############################################################################################"
    #echo "开始启动${app},这可能需要几分钟....."
    #echo "........"
    #sleep 1
    #echo "..."
    #echo "启动检验............"
    #ssh -p 22 ${pre_ip} "sh /data/shell2/shell/rundeck/bigdata_update.sh $app $start_option $pinpoint" &
    #sleep 12
    #ssh -p 22 ${pre_ip} "ps -ef |grep  ${app}.jar |grep -v grep "
    #[ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    exit 0
       
   ;;
    
   develop|test|pre)
    ##同步pinpoint 
    rsync -az -e "ssh -p 22" ${tom_dir}/pinpoint/ ${ip}:${tom_dir}/pinpoint/ > /dev/null 
    #同步tomcat
    if [ $option == "restart" ];then
      rsync -az -e "ssh -p 22" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    else
      rsync -az -e "ssh -p 22" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    fi
        
    #同步配置文件
    [ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir}/ ${ip}:${conf_dir}/
    #同步脚本
    rsync -az -e "ssh -p 22" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
        
    #同步jar包
    [ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ $ip:${tom_dir}/${app}/

    #重新启动
    echo "############################################################################################"
    echo "开始启动${app},这可能需要几分钟....."
    echo "........"
    sleep 1
    echo "..."
    echo "启动检验............"
    set -m "test"
    ssh -p 22 $ip "sh /data/shell2/shell/rundeck/bigdata_update.sh $app $start_option $pinpoint" &
    sleep 12
    ssh -p 22 $ip "ps -ef |grep  ${app}.jar |grep -v grep "
    [ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    exit 0
  
  ;;    
    
  *)
    echo "分支不存在"
    exit 1
  ;;
esac

