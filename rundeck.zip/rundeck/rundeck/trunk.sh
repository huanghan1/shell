#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# != 4 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi

appn=$1
to=$2
create_pro_war=$3
ip1=106.15.48.19
ip2=101.132.88.226
#svn://svn.xnshandai.net/shandai/trunk/loan-parent
#trunk
dir="/root/.jenkins/workspace/trunk"
dir1="${dir}/loan-api"
dir2="/home/wls81/tomcat"
#风控目录
dir3="/root/.jenkins/workspace/risk-svn/${bname}/risk-parent"
dir4="${dir3}/loan-api"
#receive
dir5="/root/.jenkins/workspace/receive-branche"
dir6="/root/.jenkins/workspace/receive-branche/loan-api"



mvnd=$(which mvn)

unset cp 
 
authority=$4
test01="test"
test02=$test01


function auth {

	 if [ $authority == $1 ];then
         echo "continue"
       else
         echo "your password is error"
         exit 2
     fi
}

case $to in
    dev)
       auth $to
    ;;
    test01|test02)
       auth $test01
    ;;
    pre)
       auth $to
    ;;
esac



case  ${appn} in   
 testall)
      cd $dir || exit 1
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install -Dmaven.test.skip=true
      [[ ! $? -eq 0 ]] &&  exit 1
  ;;
 risk-testall)
      cd $dir3 || exit 1
      $mvnd clean install -Dmaven.test.skip=true
      [[ ! $? -eq 0 ]] &&  exit 1
  ;;
 receive-testall)
      cd $dir5 || exit 1
      $mvnd clean install -Dmaven.test.skip=true
      [[ ! $? -eq 0 ]] &&  exit 1
  ;;
  authCenter)
      cd ${dir1}/loan-authCenter-api || exit 1
      
      [ -d ${dir1}/loan-authCenter-api/target ] &&  rm -rf ${dir1}/loan-authCenter-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [ $? -eq 0 ];then
        if [[ ! -f ${dir1}/loan-authCenter-api/target/loan-authCenter-api.war ]];then
          echo "打包失败"
          exit 1
        else
          src_dir="${dir1}/loan-authCenter-api/target/loan-authCenter-api.war"
          sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
        fi
      else
         echo "构建失败"
         exit 1
      fi 
 ;;
 userCenter)
      cd ${dir1}/loan-user-api || exit 10
      [ -d ${dir1}/loan-user-api/target ] &&  rm -rf ${dir1}/loan-user-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-user-api/target/loan-user-api.war ]];then
         echo "打包失败"
         exit 1
      else
        src_dir="${dir1}/loan-user-api/target/loan-user-api.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
  backendCenter)
      cd ${dir4}/loan-backend-web || exit 1
      [ -d ${dir4}/loan-backend-web/target ] &&  rm -rf ${dir4}/loan-backend-web/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir4}/loan-backend-web/target/loan-backend-web.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir4}/loan-backend-web/target/loan-backend-web.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
 backendDubbo)
      cd ${dir4}/loan-backend-dubbo || exit 1
      [ -d ${dir4}/loan-backend-dubbo/target ] &&  rm -rf ${dir4}/loan-backend-dubbo/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir4}/loan-backend-dubbo/target/loan-backend-dubbo.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir4}/loan-backend-dubbo/target/loan-backend-dubbo.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
 backendDubboCustomer)
      cd ${dir4}/loan-backend-dubbo-customer || exit 1
      [ -d ${dir4}/loan-backend-dubbo-customer/target ] &&  rm -rf ${dir4}/loan-backend-dubbo-customer/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir4}/loan-backend-dubbo-customer/target/loan-backend-dubbo-customer.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir4}/loan-backend-dubbo-customer/target/loan-backend-dubbo-customer.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
  backendtaskCenter)
      cd ${dir4}/loan-backend-task || exit 1
      [ -d ${dir4}/loan-backend-task/target ] &&  rm -rf ${dir4}/loan-backend-task/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir4}/loan-backend-task/target/loan-backend-task.war ]];then
       echo "打包失败"
       exit 1
      else
        src_dir="${dir4}/loan-backend-task/target/loan-backend-task.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
  messageCenter)
      cd ${dir1}/loan-message-api || exit 1
      [ -d ${dir1}/loan-message-api/target ] &&  rm -rf ${dir1}/loan-message-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-message-api/target/loan-message-api.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-message-api/target/loan-message-api.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
  activityCenter)
      cd ${dir1}/loan-activity-api || exit 1
      [ -d ${dir1}/loan-activity-api/target ] &&  rm -rf ${dir1}/loan-activity-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-activity-api/target/loan-activity-api.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-activity-api/target/loan-activity-api.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi

  ;;

  debitapiCenter)
      cd ${dir1}/loan-debit-api || exit 1
      [ -d ${dir1}/loan-debit-api/target ] &&  rm -rf ${dir1}/loan-debit-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-debit-api/target/debitapiCenter.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-debit-api/target/debitapiCenter.war" 
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war

      fi

  ;;

  debitserviceCenter)
      cd ${dir1}/loan-debit-service-api || exit 1
      [ -d ${dir1}/loan-debit-service-api/target ] &&  rm -rf ${dir1}/loan-debit-service-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-debit-service-api/target/debitserviceCenter.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-debit-service-api/target/debitserviceCenter.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi

  ;;
  bankCenter)
      cd ${dir1}/loan-bank-api || exit 1
      [ -d ${dir1}/loan-bank-api/target ] &&  rm -rf ${dir1}/loan-bank-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-bank-api/target/loan-bank-api.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-bank-api/target/loan-bank-api.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war

      fi

  ;;
  payserviceCenter)
      cd ${dir1}/loan-pay-service-api || exit 1
      [ -d ${dir1}/loan-pay-service-api/target ] &&  rm -rf ${dir1}/loan-pay-service-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-pay-service-api/target/loan-pay-service-api.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-pay-service-api/target/loan-pay-service-api.war"
	sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
 ;;
 crmCenter)
      #cd ${dir1}/loan_crm_web || exit 1
      #[ -d ${dir1}/loan_crm_web/target ] &&  rm -rf ${dir1}/loan_crm_web/target
      #$mvnd clean install -Dmaven.test.skip=true
      #if [[ ! -f ${dir1}/loan_crm_web/target/loan_crm_web.war ]];then
      #  echo "打包失败"
      #  exit 1
      #else
        src_dir="${dir1}/loan_crm_web/target/loan_crm_web.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war

     # fi

  ;;
  receiveWebCenter)
      cd ${dir6}/loan-receive-web || exit 1
      [ -d ${dir6}/loan-receive-web/target ] &&  rm -rf ${dir6}/loan-receive-web/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir6}/loan-receive-web/target/loan-receive-web.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir6}/loan-receive-web/target/loan-receive-web.war" $create_pro_war
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn

      fi

  ;;
  receiveTaskCenter)
      cd ${dir6}/loan-receive-task || exit 1
      [ -d ${dir6}/loan-receive-task/target ] &&  rm -rf ${dir6}/loan-receive-task/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir6}/loan-receive-task/target/loan-receive-task.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir6}/loan-receive-task/target/loan-receive-task.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war

      fi

  ;;

  honglu-batch)
      cd ${dir1}/honglu-batch || exit 1
      [ -d ${dir1}/honglu-batch/target ] &&  rm -rf ${dir1}/honglu-batch/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/honglu-batch/target/honglu-batch-1.0.0-RELEASE.war  ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/honglu-batch/target/honglu-batch-1.0.0-RELEASE.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war

      fi
 
  ;;
  honglu-batchMsg)
      cd ${dir1}/honglu-batch-msg || exit 1
      [ -d ${dir1}/honglu-batch-msg/target ] &&  rm -rf ${dir1}/honglu-batch-msg/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [ $? -eq 0 ];then
         if [[ ! -f ${dir1}/honglu-batch-msg/target/honglu-batch-msg-1.0.0-RELEASE.war ]];then
           echo "打包失败"
           exit 1
         else
           src_dir="${dir1}/honglu-batch-msg/target/honglu-batch-msg-1.0.0-RELEASE.war"
           sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
         fi
      else
	 echo "构建失败"
         exit 1
      fi
     
  ;;
  hongluMsg)
      cd ${dir1}/honglu-msg-impl || exit 1
      [ -d ${dir1}/honglu-msg-impl/target ] &&  rm -rf ${dir1}/honglu-msg-impl/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/honglu-msg-impl/target/honglu-msg-impl-0.0.1-SNAPSHOT.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/honglu-msg-impl/target/honglu-msg-impl-0.0.1-SNAPSHOT.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
  hongluBatchPay)
      cd ${dir1}/honglu-batch-pay || exit 1
      [ -d ${dir1}/honglu-batch-pay/target ] &&  rm -rf ${dir1}/honglu-batch-pay/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/honglu-batch-pay/target/honglu-batch-pay-1.0.0-RELEASE.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/honglu-batch-pay/target/honglu-batch-pay-1.0.0-RELEASE.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;
  delegateApi)
      cd ${dir1}/loan-delegate-api || exit 1
      [ -d ${dir1}/loan-delegate-api/target ] &&  rm -rf ${dir1}/loan-delegate-api/target
      $mvnd --settings /usr/local/maven-3.5.0/conf/trunk_settings.xml clean install  -Dmaven.test.skip=true
      if [[ ! -f ${dir1}/loan-delegate-api/target/loan-delegate-api.war ]];then
        echo "打包失败"
        exit 1
      else
        src_dir="${dir1}/loan-delegate-api/target/loan-delegate-api.war"
        sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
      fi
  ;;


  *)
    echo "tomcat实例名不正确"
    exit 1
  ;;

esac

#开始部署
if [ $appn != "testall" ];then
  case $to in
    dev)
       echo "研发环境....."
       rsync -az -e "ssh -p 20022" /home/wls81/tomcat/ $ip1:/home/wls81/tomcat/ --exclude-from=/data/workspace/exclude.txt > /dev/null
       scp -P 20022 /data/workspace/war/${appn}/${appn}_svn.war $ip1:${dir2}/${appn}/${appn}.war
       scp -P 20022 /data/shell/war_update.sh $ip1:/data/shell/
       ssh -p20022 106.15.48.19 "sh /data/shell/war_update.sh $appn"
       echo "Trunk" >/data/workspace/war/${appn}/dev.txt
    ;;
    test01)
       unset cp
       echo "测试环境....."
       cp -f /data/workspace/war/${appn}/${appn}_test.war ${dir2}/${appn}/${appn}.war
       sh /data/shell/war_update.sh $appn
       echo "Trunk" >/data/workspace/war/${appn}/test01.txt
    ;;
     test02)
       unset cp
       echo "测试环境02....."
       rsync -avz -e "ssh -p 22" /etc/hosts $ip2:/etc/hosts > /dev/null
       rsync -avz -e "ssh -p 22" /home/wls81/tomcat/ $ip2:/home/wls81/tomcat/ --exclude-from=/data/workspace/exclude.txt > /dev/null
       scp  /data/workspace/war/${appn}/${appn}_test.war $ip2:${dir2}/${appn}/${appn}.war
       scp  /data/shell/war_update.sh $ip:/data/shell/
       ssh  $ip2 "sh /data/shell/war_update.sh $appn"
       echo "Trunk" >/data/workspace/war/${appn}/test02.txt
    ;;

     pre)
       echo "Trunk" >/data/workspace/war/${appn}/version.txt
       echo "Only create pre war..."
    ;;

  esac
fi
