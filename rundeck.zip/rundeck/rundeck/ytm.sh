

bra_name=$1
JOB_BASE_NAME=$2
option=$3
app=$4
jar_name_str=$5
start_option="$6"


#bra_name=`echo $GIT_BRANCH |awk -F "/" '{print $2}'`
work_dir="/data/workspace/jar/ytm/${app}/$bra_name"
dir=/root/.jenkins/workspace/ytm/$JOB_BASE_NAME/target
tom_dir=/home/wls81/tomcat
tomcat_dir=${tom_dir}/ytm/$app
develop_ip=172.16.0.190
test_ip=172.16.0.193

[ ! -d $work_dir ] && mkdir -p $work_dir
[ ! -d $tomcat_dir ] && mkdir -p $tomcat_dir
eval ip="\$${bra_name}_ip"

cd $dir
jar_name=`ls | grep -E "$jar_name_str"`
[[ ! -f $jar_name ]] && echo "没有可用的war包" &&  exit 1
unset cp
cp -f $jar_name ${work_dir}/${app}.jar

case ${bra_name} in
   master)    	
        #记录打包时间
        echo "记录打包时间.................."
	md5=$(sha256sum ${work_dir}/${app}.jar  |awk '{print $1}')
        dt=`date +"%Y-%m-%d %H:%M"`
        echo $md5 > ${work_dir}/sha256.txt
        echo $dt > ${work_dir}/dtime
        echo "$bra_name" > ${work_dir}/version
	echo "生产包已经准备好..............."
   ;;
	
   develop|test)
	#同步tomcat
        if [ $option == "restart" ];then
           rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
        else
           rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
        fi
		
	#同步脚本
        rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
		
	#同步jar包
        [ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ $ip:${tom_dir}/${app}/

        #重新启动
        echo "############################################################################################"
	echo "开始启动${app},这可能需要几分钟....."
	echo "........"
	sleep 1
	echo "..."
	echo "启动检验............"
        ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/ytm_update.sh $app $start_option" &
        sleep 12
        ssh -p 20022 $ip "ps -ef |grep  ${app}.jar |grep -v grep "
        [ ! $? -eq 0 ] && echo "$app start false." && exit 1
        #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
        #kill -9 $pid
        exit 0
  
  ;;	
	
  *)
	echo "分支不存在"
	exit 1
  ;;
esac
            

