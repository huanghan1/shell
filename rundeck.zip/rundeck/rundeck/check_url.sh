#!/bin/bash

if [ $# != 1 ];then
   echo "Usage:$0 输入实例名"
   exit 1
fi

appn=$1

#定义实例对应的端口

       #_port=(8009 8010 8011 8012 8013 8014 8015 8016 8017 8018 8019 8020)
       #_port=(2345 2346 2347 2348 2349 2350 2351 2352 2353 2354 2355 2355)
instance_port=(8083 8084 8085 8086 8087 8088 8089 8090 8091 8092 8093 8094)

#根据输入的实例名以及上面定义的端口数组来获得实例的tom_pid 并记录对应的端口号port
case  ${appn} in
                authCenter)
                        port=${instance_port[0]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;

                userCenter)
                        port=${instance_port[1]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"

                ;;

                backendCenter)
                        port=${instance_port[2]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;
                backendtaskCenter)
                        port=${instance_port[3]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;

                messageCenter)
                        port=${instance_port[4]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;

                activityCenter)
                        port=${instance_port[5]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;
			
		debitapiCenter)
                        port=${instance_port[6]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;

                debitserviceCenter)
                        port=${instance_port[7]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;
				
		payCenter)
                        port=${instance_port[8]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;
		bankCenter)
                        port=${instance_port[9]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;
		payserviceCenter)
                        port=${instance_port[10]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;
                crmCenter)
                        port=${instance_port[11]}
                        http="http://127.0.0.1:${port}/${appn}/index.jsp"
                ;;


                *)
                    echo "tomcat实例名不正确"
                        exit 1
                ;;
esac
echo "当前实例对应的port为$port"
echo "对当前端口做http请求，URL为：$http"
sleep 2
script_path=$(dirname $0)
pid=`ps -ef | grep -E "${dir}" | grep -v "grep" | awk '{print $2}'`

[[ ! -z $pid ]] && code=`python ${script_path}/check.py "$http"` || exit 1

[[ $code -eq 200 ]] && exit 0 || exit 1


