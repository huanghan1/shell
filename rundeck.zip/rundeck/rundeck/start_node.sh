#!/bin/bash
local_app_name=$appname
cd /home/wls81/tomcat/$appname
mkdir -pv /data/$appname/logs/
/usr/local/bin/pm2 start pm2start.json
tail -f /data/$appname/logs/$appname.log
