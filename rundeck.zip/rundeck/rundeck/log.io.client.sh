#!/bin/bash
opt=$1
app=$2
litem=$3
lenv=$4
lidc=$5
pre_logdir=$6
dtime=`date +"%Y-%m-%d"`

start() {
       echo "Starting log.io process..."
       #/usr/bin/nohup /usr/bin/log.io-server >> /dev/null 2>&1 &
       /usr/bin/nohup /usr/bin/log.io-harvester >> /dev/null  2>&1 &
}

stop() {
      echo "Stopping io-log process..."
      pkill node
}                             

status() {
      echo "Status io-log process..."
      #netstat -tlp | grep node
}

flag=0

pid=`ps -ef |grep "/usr/bin/log.io-harvester" |grep -v "grep" |awk '{print $2}'`
cur_logdir="${pre_logdir}/catalina.out.${dtime}.log"
grep -q $cur_logdir /root/.log.io/harvester.conf

if [ ! $? -eq 0 ];then
 if [ ! -z $litem ];then
cat << EOF > /root/.log.io/harvester.conf
exports.config = {
  nodeName: "${litem}-${lenv}-${lidc}",
  logStreams: {
    ${app}: [
      "$cur_logdir"
    ]
  },
  server: {
    host: '172.16.12.243',
    port: 28777
  }
}

EOF
  flag=1
 fi
fi 

if [ $opt == "start" ];then
  if [ ! -z $pid ];then
    [ $flag -eq 1 ] && opt="restart"
    [ $flag -eq 0 ] && opt="status" 
  fi
fi
   

case "$opt" in
     start)
     start
     ;;
     stop)
     stop
     ;;
     status)
     status
     ;;
     restart)
     echo "Restart log.io process..."
     $0 stop
     $0 start
     ;;
     *)
     echo "Usage: start|stop|restart|status"
     ;;
esac
