#!/bin/bash

#########################################################################
#定义实例对应的端口
user=8080  #jvm:2345
message=8081  #jvm:2345
trade=8082  #jvm:2345
community=8083  #jvm:2345
mall=8084  #jvm:2345
spback=8085  #shutdown:8001 , jvm:2345
activity=8092  #jvm:2345
activitymq=8093  #jvm:2345
