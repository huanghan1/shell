#!/bin/bash

d=`date +%Y-%m-%d`
mysqldump -u root -pnhyroot --opt shandai > /data/backup/mysql/shandai_${d}.sql
find /data/backup/mysql -mtime +7 -name "*.sql"  |xargs rm -rf {}
