docker pull "registry-vpc.cn-shanghai.aliyuncs.com/xn-test/fdd:loanapply"
docker tag "registry-vpc.cn-shanghai.aliyuncs.com/xn-test/fdd:loanapply" "registry-vpc.cn-shanghai.aliyuncs.com/xn-test/fdd:loanapply_2019-04-19-10-40"
#image_id=`docker images | grep  | awk '{print $3}'`
#for id in $image_id
#do
#  if [ -n "${id}" ];then
#     docker rmi -f $id
#  fi
#done
