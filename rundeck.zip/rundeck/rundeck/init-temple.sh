#!/bin/bash
app=loancustomer
ip=172.16.0.215
init_filename="ycjinke_init.sh"

cd /home/wls81/shell/rundeck || exit 1
[ -f $init_filename ] && rm -f $init_filename
wget http://$ip/shell/rundeck/$init_filename
sh $init_filename $app 
