#!/bin/bash
#app_主干命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 trunk crmCenter yes test app_trunk

#app_分支命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 1.4.0 activityCenter no test app_branch

#风控命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 risk-parent_2.7 backendCenter no test risk

#催收命令行测试用例
#sh -x  /data/shell2/shell/rundeck/app_trunk.sh test02 receive receiveWebCenter no test receive
######################################################################
#定义项目对应的maven配置文件路径
app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
app_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
risk_mset="/usr/local/maven-3.5.0/conf/risk_settings.xml"
receive_mset="/usr/local/maven-3.5.0/conf/receive_settings.xml"
receive_trunk_mset="/usr/local/maven-3.5.0/conf/receive_trunk_settings.xml"
caiwu_trunk_mset="/usr/local/maven-3.5.0/conf/shandaicaiwu_trunk_settings.xml"
operate_trunk_mset=$app_trunk_mset
operate_branch_mset=$app_branch_mset

######################################################################
#tomcat路径
src_tom_dir="/home/wls81/shandai"
tom_dir="/home/wls81/tomcat"

#定义环境对应的svn物理路径
#app 主干
#app_trunk="/root/.jenkins/workspace/shandai/"
app_trunk="/root/.jenkins/workspace/shandai/loan-parent"
#app 分支
app_branch="/root/.jenkins/workspace/huihuahua/branches/${bra_name}/loan-parent"

#huihuahuai活动
operate_trunk="/root/.jenkins/workspace/shandai/operate-parent"

payApi_trunk="/root/.jenkins/workspace/shandai/pay-parent"

#风控
risk="/root/.jenkins/workspace/risk-svn/${bra_name}/risk-parent"
#催收
receive="/root/.jenkins/workspace/receive-branche/$bra_name"
receive_trunk="/root/.jenkins/workspace/receive-trunk/$bra_name"
#财务
caiwu_trunk="/root/.jenkins/workspace/$bra_name"
######################################################################
#定义环境对应的ip
hdev="106.15.48.19"
htest01="172.16.0.216"
htest02="172.16.0.192"
hpro="172.16.0.1"

#定义环境密码
hdevX="dev"
htest01X="gotest"
htest02X=$test01X
htest03X=$test01X
htest04X=$test01X
htest05X=$test01X
htest06X=$test01X
hproX="pro"

######################################################################
#定义项目的要svn目录名
#app
bankCenter="bank-api-web"
payserviceCenter="loan-pay-service-api"
activityCenter="loan-activity-api"
delegateApi="loan-delegate-api"
userCenter="loan-user-api"
crmCenter="loan_crm_web"
hongluMsg="honglu-msg-impl"
authCenter="loan-authCenter-api"
honglubatchMsg="honglu-batch-msg"
debitapiCenter="loan-debit-api"
messageCenter="loan-message-api"
hongluBatchPay="honglu-batch-pay"
honglubatch="honglu-batch"
debitserviceCenter="loan-debit-service-api"
yntrustpay="loan-yntrustpay-api"
hongluBatchXt="honglu-batch-xt"
hongluBatchMonitor="honglu-batch-monitor"
marketApi="loan-market-api"
ptoppayApi="loan-ptoppay-api"
operateActApi="loan-operate-act-api"
honglubatchTem="honglu-batch-tem"
hongluupgrade="loan-upgrade-api"
hongluoperate="operate-activity-api"
hongluoperateApi="operate-operate-api"

#risk
backendCenter="loan-backend-web"
backendDubbo="loan-backend-dubbo"
backendDubboCustomer="loan-backend-dubbo-customer"
backendShared="loan-backend-shared"
backendMqCenterConsumer="loan-backend-rabbitmq"
backendtaskCenter="loan-backend-task"
backendMqCenter="loan-backend-rabbit-producer"
backendtaskminor="loan-backend-task-minor"
backendMqbusiness="loan-backend-mq-business"
backendTaskPromote="loan-backend-task-promote"
payApi="pay-api"

#receive
receiveWebCenter="loan-receive-web"
receiveTaskCenter="loan-receive-task"
receiveReport="loan-receive-report"
#caiwu
financeWeb="loan-finance-system"
#########################################################################
#定义实例对应的端口

        #_port=(8009 8010 8011 8012 8013 8014 8015 8016 8017 8018 8019 8020 8021 8022 8023 8024 8025 8026 8027 8028 8029 8030 8031 8032 8033 8034 8035 8036 8037 8038 8039 8040 8041 8042 8043 8044 8045)
        #_port=(2346 2347 2348 2349 2350 2351 2352 2353 2354 2354 2355 2356 2357 2358 2359 2360 2361 2362 2363 2364 2365 2366 2367 2368 2369 2370 2371 2372 2373 2374 2375 2376 2377 2378 2379 2380 2381)    
#instance_port=(8083 8084 8085 8086 8087 8088 8089 8090 8091 8092 8093 8094 8095 8096 8097 8098 8099 8100 8101 8102 8103 8104 8105 8106 8107 8108 8109 8110 8111 8112 8113 8114 8115 8116 8117 8118 8119) 
authCenterX=8083
userCenterX=8084
backendCenterX=8085
backendtaskCenterX=8086
messageCenterX=8087
activityCenterX=8088
debitapiCenterX=8089
debitserviceCenterX=8090
bankCenterX=8092
payserviceCenterX=8093
crmCenterX=8094
honglubatchX=8095
receiveTaskCenterX=8096
receiveWebCenterX=8097
backendDubboX=8098
backendDubboCustomerX=8099
honglubatchMsgX=8100
hongluMsgX=8101
hongluBatchPayX=8102
operationWebX=8103
backendMqCenterConsumerX=8104
backendSharedX=8105
delegateApiX=8106
yntrustpayX=8107
hongluBatchXtX=8108
receiveReportX=8109
backendMqCenterX=8110
backendtaskminorX=8111
financeWebX=8112
hongluBatchMonitorX=8113
backendMqbusinessX=8114
marketApiX=8115
ptoppayApiX=8116
operateActApiX=8117
backendTaskPromoteX=8118
honglubatchTemX=8119
rejobadminX=8120  #shutdown:8046 , jvm:2382
hhhjobadminX=8121 #shutdown:8047 , jvm:2383
hongluupgradeX=8122 #shutdown:8048,jvm:2384
hongluoperateX=8123 #shutdown:8049,jvm:2385
hongluoperateApiX=8124 #shutdown:8050,jvm:2386
payApiX=8128 #shutdown:8051,jvm:2387




