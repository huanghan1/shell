#!/bin/bash

if [ $# != 3 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#ip=106.15.48.19
port=20022
src_war_dir=$1
appn=$2
create_pro_war=$3

src="/home/wls81/tomcat"
dest="/data/workspace/war"
d=$(date +%Y-%m-%d_%H:%M)

[ ! -d ${dest}/$appn ] && mkdir -p ${dest}/$appn
cd ${dest}/$appn || exit 1
rm -rf ${dest}/${appn}/*

[ ! -d tmp ] && mkdir tmp

unset cp
[ -f ${src_war_dir} ] && cp -f  ${src_war_dir} ./${appn}_svn.war
[ $? -eq 0 ] && echo "研发环境war包构建完成"
[ -f ${src_war_dir} ] && cp -f  ${src_war_dir} tmp/${appn}.war



function modify_config {
pre_conf="/data/workspace/config/pre"
pro_conf="/data/workspace/config/pro"
cd tmp ||exit 10
if [ -f ${appn}.war ];then
    #解包
    jar -xf ${appn}.war 
    #删除原包
    [ $? -eq 0 ] && rm -f ${appn}.war || exit 12

    #替换成测试环境配置
    unset cp
    cp -f ${pre_conf}/${appn}/* WEB-INF/classes/
    [[ ! $? -eq 0 ]] && echo "配置文件目录没有找到，已经退出配置文件替换过程" && exit 1
    if [ $appn == "crmCenter" ];then
         unset mv
         mv -f WEB-INF/classes/base.js commons/base.js
         [ ! $? -eq 0 ]&& exit 19
         echo "测试环境crmCenter的base.js 替换ok"
    fi
    #封装测试包
    jar -cf ${appn}.war ./*
    [ ! $? -eq 0 ] && exit 14
 
    #移动war包到上层目录
    if [ -f ${appn}.war ];then
        #mv ${appn}.war ${src}/$appn 
        mv ${appn}.war ../${appn}_test.war
        [ $? -eq 0 ] && echo "测试环境war包构建完成" || exit 1
    else
        echo "封装测试包失败"
        exit 1
    fi
########################################################################################
    if [ $create_pro_war == "yes" ];then
        #生产配置来替换预发布的配置
        #scp -P$port ${ip}:/data/workspace/config/${appn}/* WEB-INF/classes/
        if [ ! -d ${pro_conf}/$appn ];then
	        echo "${appn}的生产配置文件不存在" 
                echo "${appn}的生产包准备失败，，已经退出配置文件替换过程"
		exit 1
        else
		cp -f ${pro_conf}/${appn}/* WEB-INF/classes/   
        fi
          
        if [ $appn == "crmCenter" ];then
             unset mv
             mv -f WEB-INF/classes/base.js commons/base.js
             [ ! $? -eq 0 ]&& exit 19
             echo "预生产crmCenter的base.js 替换ok"
        fi

        #封生产包
        jar -cf ${appn}.war ./*
        [ ! $? -eq 0 ] && exit 14

        #移动war包到workspace/war/xxx目录下
        if [ -f ${appn}.war ];then 
              mv ${appn}.war ../ || exit 1
              [ $? -eq 0 ] &&  echo "预生产环境war包已经构建完成" || exit 1
        else
             echo "封装预生产包失败"
             exit 1
        fi
  
	cd .. || exit 13
   	#生成md5值并保存
   	sha256=$(sha256sum ${appn}.war | awk '{print $1}')
   	if [ ! -z $sha256 ];then
       	   echo $sha256 > sha256.txt
  	 else
       	   echo "error" > sha256.txt
           echo "md5值生成失败"
           exit 1
  	fi
  	echo $d  > time
  	echo "生产配置文件替换成功...."
  fi

  echo "各环境配置文件替换成功....,开始部署....."
  echo "#################################################"
   

else
  echo "拉不到war包"
  exit 15
fi
  
    
    
}
   
modify_config

