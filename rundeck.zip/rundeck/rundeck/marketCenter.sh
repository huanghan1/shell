#!/bin/bash
. /etc/profile
to=$1
name=$2
#jarwork_dir="/data/workspace/jar/xnyule/$name/$to/"
warwork_dir="/data/workspace/miaogou/$name/$to/"
src_dir="/home/wls81/tomcat/$name/"
src1_dir="/home/wls81/tomcat/$name/webapps/"
shell_dir="/data/shell2/shell/rundeck/"

dev_ip="172.16.11.196"
test_ip="172.16.11.187"
#[ ! -d $jarwork_dir ] && mkdir -p $jarwork_dir 
[ ! -d $warwork_dir ] && mkdir -p $warwork_dir


#配置文件替换
testconfig="/data/workspace/config/mpre1"
onlineconfig="/data/workspace/config/mpro"

if [ $to == test ];then
       cd  $warwork_dir 
	   jar -xf ${name}.war
	   rm -f ${name}.war
           rsync -az $testconfig/$name/ WEB-INF/classes/
           jar -cf ${name}.war ./*
elif [ $To == online ];then
	   cd  $warwork_dir 
	   jar -xf ${name}.war
	   rm -f ${name}.war
           rsync -az $onlineconfig/$name/ WEB-INF/classes/
           jar -cf ${name}.war ./*
	   sleep 3
	   mv ${name}.war /data/workspace/miaogou/$name/
	   cd /data/workspace/miaogou/$name/
	   sha256sum ${name}.war | awk -F ' ' '{print $1}' > sha256.txt
           tim=`date +"%Y-%m-%d-%H"`
           echo $tim > time.txt
 else
	   echo "开发环境，不需要替换配置文件"
       
fi

#chown wls81. /data/workspace/jar/xnyule -R
chown wls81. /data/workspace/miaogou/ -R



#同步包，并执行启动脚本
if [[ $to == "dev" ]];then
   rsync -az -e "ssh -p 20022" $shell_dir $dev_ip:$shell_dir --delete > /dev/null
   if [[ $name == "marketCenter" ]];then
       rsync -az -e "ssh -p 20022" $warwork_dir/${name}.war $dev_ip:$src1_dir --delete > /dev/null
   else 
       rsync -az -e "ssh -p 20022" $jarwork_dir $dev_ip:$src_dir --delete > /dev/null
   fi
   
   sleep 3
   
   if [[ $name == "marketCenter" ]];then
       ssh -p 20022 $dev_ip "sh /data/shell2/shell/rundeck/xnyule_war_update.sh $name" 
   else
       ssh -p 20022 $dev_ip "sh /data/shell2/shell/rundeck/xnyule_update.sh $name $to" &
   fi  

elif [[ $to == "test" ]];then
   rsync -az -e "ssh -p 20022" $shell_dir $test_ip:$shell_dir --delete > /dev/null
   if [[ $name == "statisticsCenter" ]];then
       rsync -az -e "ssh -p 20022" $warwork_dir/${name}.war $test_ip:$src1_dir --delete > /dev/null
   else
       rsync -az -e "ssh -p 20022" $jarwork_dir $test_ip:$src_dir --delete > /dev/null
   fi

   sleep 3

   if [[ $name == "marketCenter" ]];then
       ssh -p 20022 $test_ip "sh /data/shell2/shell/rundeck/xnyule_war_update.sh $name" 
   else
       ssh -p 20022 $test_ip "sh /data/shell2/shell/rundeck/xnyule_update.sh $name $to" &
   fi


else
   echo "仅构建生产包，不进行发布"
   #exit 1

fi

