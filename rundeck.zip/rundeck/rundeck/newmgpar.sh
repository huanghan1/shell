#!/bin/bash
######################################################################
#定义项目对应的maven配置文件路径
#app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
#newmgapp_trunk_mset="/usr/local/maven-3.5.0/conf/settings.xml"
newmgapp_trunk_mset="/usr/local/maven-3.5.0/conf/newsettings.xml"
newmgapp_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
#userCenter_trunk_mset="/usr/local/maven-3.5.0/conf/settingshhh.xml"
#userCenter_trunk_mset=$app_trunk_mset
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/miaogou"
tom_dir="/home/wls81/tomcat"

#定义环境对应的svn物理路径
#app 主干
newmgapp_trunk="/root/.jenkins/workspace/app-miaogou/"
#app 分支
dir2="/root/.jenkins/workspace/miaogou_git"

#定义环境对应的ip
#定义环境对应的ip
mdev="172.16.11.196"
mtest01="172.16.11.187"
mpro=""
hdmpro=""
#定义环境密码
mdevX="dev"
mtest01X="xntest"
mproX="pro"
hdmproX="pro"
######################################################################
#定义项目的要svn目录名
#app
hongluoperateApi="miaogou-hongluoperateApi/operate-operate-api"
messageCenter="miaogou-messageCenter/loan-message-api"
hongluMsg="miaogou-hongluMsg/honglu-msg-impl"
jobbaoxian="miaogou-jobbaoxian"
hongluupgrade="miaogou-hongluupgrade/loan-upgrade-api"
authCenter="miaogou-authCenter/loan-authCenter-api"
userCenter="miaogou-userCenter/loan-user-api"
crmCenter="miaogou-crmCenter/operate-crm/operate-crm-web"
mgmarketCenter="miaogou-market/market-api-web"

authCenterX=8083
userCenterX=8084
backendCenterX=8085
backendtaskCenterX=8086
messageCenterX=8087
activityCenterX=8088
debitapiCenterX=8089
debitserviceCenterX=8090
bankCenterX=8092
payserviceCenterX=8093
crmCenterX=8094
honglubatchX=8095
receiveTaskCenterX=8096
receiveWebCenterX=8097
backendDubboX=8098
backendDubboCustomerX=8099
honglubatchMsgX=8100
hongluMsgX=8101
hongluBatchPayX=8102
operationWebX=8103
backendMqCenterConsumerX=8104
backendSharedX=8105
delegateApiX=8106
yntrustpayX=8107
hongluBatchXtX=8108
receiveReportX=8109
backendMqCenterX=8110
backendtaskminorX=8111
financeWebX=8112
hongluBatchMonitorX=8113
backendMqbusinessX=8114
marketApiX=8115
ptoppayApiX=8116
operateActApiX=8117
backendTaskPromoteX=8118
honglubatchTemX=8119
rejobadminX=8120  #shutdown:8046 , jvm:2382
hhhjobadminX=8121 #shutdown:8047 , jvm:2383
hongluupgradeX=8122 #shutdown:8048,jvm:2384
hongluoperateX=8123 #shutdown:8049,jvm:2385
hongluoperateApiX=8124 #shutdown:8050,jvm:2386
crmCenter2X=8129

