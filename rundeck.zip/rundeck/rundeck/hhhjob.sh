#!/bin/bash


To=$1
app=$2
passwd=$3
pinpoint=$4

hdev_pd="hhhhh"
htest01_pd="xntest"
hpro_pd="pro"

eval pd="\$${To}_pd"

if [ $passwd != "$pd" ];then
   echo "your passwd is error...."
   exit
fi

hhhjobmessage=job-message
hhhjobmonitor=job-monitor
hhhjoboverdue=job-overdue
hhhjobpayment=job-payment
hhhjobdatapush=job-datapush
hhhjobbaoxian=job-baoxian

mgjobmessage=job-message
mgjobmonitor=job-monitor
mgjoboverdue=job-overdue
mgjobpayment=job-payment
mgjobdatapush=job-datapush
mgjobbaoxian=job-baoxian


eval app_dir="\$$app"

#dir=$3
mvnd=$(which mvn)
setting="/usr/local/maven-3.5.0/conf/shandaicaiwu_trunk_settings.xml"

#svn基准目录
svn_dir=/root/.jenkins/workspace/huihuahua-xxjob/XXLJob
pro_svn_dir=${svn_dir}/${app_dir}
wk_dir=/data/workspace/huihuahua
pro_wk_dir=${wk_dir}/$app
#if [ ! -d "${pro_svn_dir}" ];then
#    mkdir -pv ${pro_svn_dir}
#fi

if [ $app != "dataprope" ];then
  cd ${pro_svn_dir} || exit 1
  #cd ${svn_dir} || exit 1
  echo "开始构建${app}。。。。"
  echo "############################################################################################"
  echo "############################################################################################"
  if [ $To != "pro" -a $To != "pre" ];then
     #$mvnd clean  package install --settings $setting -P prod -Dmaven.test.skip=true
     $mvnd clean  package package  -Dmaven.test.skip=true
  else
     #$mvnd clean  package install --settings $setting -P test -Dmaven.test.skip=true
     $mvnd clean  package package  -Dmaven.test.skip=true
  fi
  num=$?
  echo "############################################################################################"
  echo "############################################################################################"
  echo "构建${app}完成，开始生成${app}.jar"

  if [ $num -eq 0 ];then
     #取得jar包文件名
     cd ${pro_svn_dir} || exit 1

     [ -d target ] && filedir=`find target -name "*.jar" `
     [ ! -z $filedir ] && jarfile=`basename $filedir ` 
     if [[ ! -f ${pro_svn_dir}/target/$jarfile ]];then
        echo "############################################################################################"
        echo "############################################################################################"
        echo "打包失败"
        echo "构建${app}失败,请找开发确定是否还有未提交的代码"
        exit 1
     else
       [ ! -d $pro_wk_dir ] && mkdir -p $pro_wk_dir
       if [ -d $pro_wk_dir ];then
	  src_dir="${pro_svn_dir}/target/$jarfile"
	  #sh /data/shell2/shell/rundeck/package5.sh  $src_dir $appn $create_pro_war
          unset cp
          if [ $To != "hpro" -a $To != "hpre" ];then
             cp -f $src_dir  ${pro_wk_dir}/${app}_${To}.jar
          else
            cp -f $src_dir  ${pro_wk_dir}/${app}.jar
          fi

	  if [[ ! $? -eq 0 ]];then
		 echo "转移${app}的jar包失败"
		 exit 1
	  elif [ $To == "hpro" -o $To == "hpre" ];then
                  sleep 2
                  echo "############################################################################################"
		  echo "创建${app}.jar成功，生成md5.....记录时间...."
		  cd $pro_wk_dir || exit 1
		  sha256=$(sha256sum ${app}.jar | awk '{print $1}')
		  if [ ! -z $sha256 ];then
			 echo $sha256 > sha256.txt
		  else
			 echo "error" > sha256.txt
			 echo "md5值生成失败"
			 exit 1
		  fi
		  d=$(date +%Y-%m-%d_%H:%M)
		  echo $d  > time

	  fi
          echo "############################################################################################"
          echo "构建${app}完成."
          echo "############################################################################################"
        else
	  echo "${dir2}$appn 目录不存在"
	  exit 1
        fi
     fi
  else
     echo "构建失败"
     exit 1
  fi

fi
#exit 0

hdev_ip="106.15.48.19"
htest02_ip="172.16.11.177"
htest01_ip="172.16.0.197"
#htest01_ip="172.16.11.187"
src_config_dir="/data/workspace/config/huihuahua/${app}/$To"
dest_config_dir="/home/wls81/config/${app}/"
src_tom_dir="/home/wls81/huihuahua/$app"
app_dir="/home/wls81/tomcat/$app/"

script_dir="/data/shell2/shell/rundeck/mmm_update.sh"

#部署jar包
if [ $app != "dataprobe" ];then
    case $To in
       hdev)
           unset cp
           echo "开始部署${app}的开发环境"
           #rsync -az -e "ssh -p 20022" $config_dir $hdev_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $hdev_ip:$script_dir
           rsync -az -e "ssh -p 20022" ${pro_wk_dir}/${app}_${To}.jar ${hdev_ip}:${app_dir}/${app}.jar
           ssh -p 20022 $hdev_ip "sh $script_dir $app $pinpoint dev"
           [ $? -eq 0 ] && exit 0

       ;;
       htest02)
           unset cp
           echo "开始部署${app}的${To}环境....."
           rsync -az -e "ssh -p 20022" $src_config_dir/* $htest02_ip:$dest_config_dir/
           rsync -az -e "ssh -p 20022" $script_dir $htest02_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}_${To}.jar $htest02_ip:$app_dir
           ssh -p 20022 $htest02_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;


      htest03)
           unset cp
           echo "开始部署${app}的测试环境....."
           rsync -az -e "ssh -p 20022" $config_dir $test03_ip:$app_dir
           rsync -az -e "ssh -p 20022" $script_dir $test03_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}_${To}.jar $test03_ip:$app_dir
           ssh -p 20022 $test03_ip "sh $script_dir $app"
           [ $? -eq 0 ] && exit 0

       ;;
     htest01)
           unset cp
           echo "测试环境....."
           [ ! -d $src_tom_dir ] && mkdir -p $src_tom_dir
           rsync -az -e "ssh -p 20022 " $src_tom_dir/ $htest01_ip:$app_dir/
           rsync -az -e "ssh -p 20022" $src_config_dir/ $htest01_ip:$dest_config_dir/
           rsync -az -e "ssh -p 20022" $script_dir $htest01_ip:$script_dir
           scp -P 20022 ${pro_wk_dir}/${app}_${To}.jar $htest01_ip:${app_dir}/${app}.jar
           ssh -p 20022 $htest01_ip "sh $script_dir $app $pinpoint fat"
           [ $? -eq 0 ] && exit 0
       ;;

      hpre|hpro)
           echo "Only create pro jar..."
       ;;
    esac
fi

