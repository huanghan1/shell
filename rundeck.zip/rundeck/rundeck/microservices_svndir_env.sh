user=headline-user/headline-user-service
account=headline-account/headline-account-service
apiGateway=headline-api-gateway
web=headline-web
job=headline-job
message=headline-message/headline-message-dubbo
ruleConfig=headline-rule-config/headline-rule-config-service
jobrule=headline-rule
