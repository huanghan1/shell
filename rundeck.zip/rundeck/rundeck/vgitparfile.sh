#!/bin/bash
#app_主干命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 trunk crmCenter yes test app_trunk

#app_分支命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 1.4.0 activityCenter no test app_branch

#风控命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 risk-parent_2.7 backendCenter no test risk

#催收命令行测试用例
#sh -x  /data/shell2/shell/rundeck/app_trunk.sh test02 receive receiveWebCenter no test receive
######################################################################
#定义项目对应的maven配置文件路径
#app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
app_trunk_mset="/usr/local/maven-3.5.0/conf/voice_setting.xml"
app_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/tomcat/voice"
tom_dir="/home/wls81/tomcat"
jar_config_dir="/home/wls81/config/voice"
war_config_idr="/data/workspace/config"
workspace_dir="/data/workspace/voice"
#配置文件路
vdev_configdir="/data/workspace/config/vdev"
vtest01_configdir="/data/workspace/config/vtest01"
vtest02_configdir="/data/workspace/config/vtest02"
vpro_configdir="/data/workspace/config/vpro"

#定义环境对应的svn物理路径
#app 主干
app_trunk="/root/.jenkins/workspace/voice"
dir2="/root/.jenkins/workspace/voice"


######################################################################
#定义环境对应的ip
vdev="172.16.11.199"
vtest01="172.16.11.201"
vtest02="172.16.11.214"
vtest03="172.16.12.241"
vpro="172.16.0.191"

#定义环境密码
vdevX="dev"
vtest01X="test123"
vtest02X="test123"
vtest03X="test123"
vproX="pro"

######################################################################

#定义项目的要target目录名
activitywar_target="quickcall-activity/quickcall-activity-web"
activityjar_target="quickcall-activity/quickcall-activity-service"
accountwar_target="quickcall-account/quickcall-account-web"
accountjar_target="quickcall-account/quickcall-account-service"
userwar_target="quickcall-user/quickcall-user-web"
userjar_target="quickcall-user/quickcall-user-service"
commonjar_target="quickcall-common/quickcall-cmomon-third"
adminwar_target="quickcall-admin"
taskjar_target="quickcall-task"
consumerjar_target="quickcall-consumer/quickcall-consumer-service"
producerjar_target="quickcall-producer/quickcall-producer-service"
databuryjar_target="quickcall-databury/quickcall-databury-services"
shumeijar_target="quickcall-third/quickcall-third-shumei"
activityconsumeraccount_target="quickcall-activity/quickcall-activity-consumer-account"
activityconsumercache_target="quickcall-activity/quickcall-activity-consumer-cache"
activityconsumergift_target="quickcall-activity/quickcall-activity-consumer-gift"
activityconsumermsg_target="quickcall-activity/quickcall-activity-consumer-msg"



#定义项目的要打包目录名
activitywar_build="quickcall-activity"
activityjar_build="quickcall-activity"
accountwar_build="quickcall-account"
accountjar_build="quickcall-account"
userwar_build="quickcall-user"
userjar_build="quickcall-user"
commonjar_build="quickcall-common"
adminwar_build="quickcall-admin"
taskjar_build="quickcall-task"
consumerjar_build="quickcall-consumer"
producerjar_build="quickcall-producer"
databuryjar_build="quickcall-databury"
shumeijar_build="quickcall-third"
activityconsumeraccount_buile="quickcall-activity/quickcall-activity-consumer-account"
activityconsumercache_buile="quickcall-activity/quickcall-activity-consumer-cache"
activityconsumergift_buile="quickcall-activity/quickcall-activity-consumer-gift"
activityconsumermsg_buile="quickcall-activity/quickcall-activity-consumer-msg"


#定义实例对应的端口
activitywarX=8083
activityjarX=8084
accountwarX=8085
accountjarX=8086
userwarX=8087
userjarX=8088
commonjarX=8089
adminwarX=8090
taskjarX=8091
consumerjarX=8092
producerjarX=8093
databuryjarX=8094
shumeijarX=8095
activityconsumeraccountX=8096
activityconsumercacheX=8097
activityconsumergiftX=8098
activityconsumermsgX=8099

#定义应用类型
activitywar_type=war
activityjar_type=jar
accountwar_type=war
accountjar_type=jar
userwar_type=war
userjar_type=jar
commonjar_type=jar
adminwar_type=war
taskjar_type=jar
consumerjar_type=jar
producerjar_type=jar
databuryjar_type=jar
shumeijar_type=jar
activityconsumeraccount_type=jar
activityconsumercache_type=jar
activityconsumergift_type=jar
activityconsumermsg_type=jar

#包名
activitywar_filename=activityCenter.war
activityjar_filename=activityCenter.jar
accountwar_filename=accountCenter.war
accountjar_filename=accountCenter.jar
userwar_filename=userCenter.war
userjar_filename=userCenter.jar
commonjar_filename=quickcall.jar
adminwar_filename=admin.war
taskjar_filename=voice-task.jar
consumerjar_filename=consumerjar.jar
producerjar_filename=producerjar.jar
databuryjar_filename=databuryjar.jar
shumeijar_filename=shumeijar.jar
activityconsumeraccount_filename=activityconsumeraccount.jar
activityconsumercache_filename=activityconsumercache.jar
activityconsumergift_filename=activityconsumergift.jar
activityconsumermsg_filename=activityconsumermsg.jar

