#!/bin/bash
######################################################################
#定义项目对应的maven配置文件路径
headline_mset="/usr/local/maven-3.5.0/conf/headline_settings.xml"
microservices_mset="/usr/local/maven-3.5.0/conf/headline_settings.xml"
headlinejobmaster_mset="/usr/local/maven-3.5.0/conf/headline_settings.xml"

receive_parent_mset=$headline_mset
receive_job_mset=$headline_mset

sports_mset="/usr/local/maven-3.5.0/conf/sports_settings.xml"
sportsJob_mset="/usr/local/maven-3.5.0/conf/sportsJob_settings.xml"

elect_parent_mset=$headline_mset
######################################################################
#tomcat路径
tom_dir="/home/wls81/tomcat"
#work_dir
work_dir="/data/workspace"

#定义环境对应的svn物理路径
#headline 主干
headline="/root/.jenkins/workspace/headline"
headlineApi="${headline}/headline-content-api"

microservices="/root/.jenkins/workspace/headline-parent"
microservicesApi="${microservices}/headline-api"

headlinejobmaster="/root/.jenkins/workspace/job-master"
headlinejobmasterApi="$headlinejobmaster"

#sports trunk
sports="/root/.jenkins/workspace/sports/athletics-parent"
sportsApi="${sports}"


#sports job
sportsJob="/root/.jenkins/workspace/sports/athletics-parent/job-master"
sportsJobApi="${sportsJob}"

#receive 催收
receive_parent="/root/.jenkins/workspace/receive/receive-parent"
receive_parentApi="$receive_parent"
receive_job="/root/.jenkins/workspace/receive/receive_job"
receive_jobApi="$receive_job"
 
elect_parent="/root/.jenkins/workspace/elect/elect-parent"
elect_parentApi="$elect_parent"
######################################################################
#配置中心
dev_host="disconf.51xnsd.com"
dev_port="80"
dev_env="rd"
test01_host="disconf.51xnsd.com"
test01_port=$dev_port
test01_env="qa"

test06_host="disconf.51xnsd.com"
test06_port=$dev_port
test06_env="qa"


online_host=""
online_port=""
online_env="online"

######################################################################
#定义环境对应的ip
headlineX=(172.16.0.226 172.16.0.216)
headline_dev="172.16.0.226"
headline_test01="172.16.0.216"

microservicesX=(172.16.0.226 172.16.0.216)
microservices_dev="172.16.0.226"
microservices_test01="172.16.0.216"

headlinejobmasterX=(172.16.0.226 172.16.0.216)
headlinejobmaster_dev="172.16.0.226"
headlinejobmaster_test01="172.16.0.216"

sportsX=(172.16.0.220 172.16.0.217)
sports_dev="172.16.0.220"
sports_test01="172.16.0.217"

sportsJobX=(172.16.0.220 172.16.0.217)
sportsJob_dev="172.16.0.220"
sportsJob_test01="172.16.0.217"

receive_parentX=(106.15.48.19 172.16.0.188)
receive_parent_dev=106.15.48.19
receive_parent_test01=172.16.0.188

receive_jobX=(106.15.48.19 172.16.0.192)
receive_job_dev=106.15.48.19
receive_job_test01=172.16.0.192



elect_parentX=(106.15.48.19 172.16.0.226)
elect_parent_dev=106.15.48.19
elect_parent_test01=172.16.0.226
####################################################################

#定义环境密码
devX="dev"
test01X="testing"
onlineX="1"

######################################################################

