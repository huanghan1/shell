#!/bin/bash
if [ ! $# -eq 3 ];then
   echo "Usage: app_name  env  project_name"
   exit 1
fi

appname=$1
env=$2
proj=$3

dir=/data/workspace/$proj/$appname

type=`curl -sSL "http://apollo.51huihuahua.com:8089/configfiles/json/huihuahua-app-type/default/application?ip=192.168.1.248" |jq .${appname}_type | awk '{print $1}' |sed -n 's/\"//gp'`
[ -z $type ] && echo "type is Null " && exit 1

if [ $type == "war" ];then
   docker_dir="/home/wls81/tomcat/webapps"
else
   docker_dir="/home/wls81/java"
fi

echo $env |grep -q pro
if [ $? -eq 0 ];then
  filename=${appname}.$type  
else
  filename=${appname}_${env}.$type
fi

cd $dir || exit 1

cat << EOF > Dockerfile
from registry-vpc.cn-shanghai.aliyuncs.com/xn-test/xn-docker:java_tomcat8_v1
MAINTAINER niehaiyong@xiaoniu.com
workdir /home/wls81
ENV LANG=zh_CN.UTF-8 
env appname=$appname
env apptype=$type
COPY $filename ${docker_dir}/${appname}.$type
EOF

#开始构建应用容器
tagstr=$3
#大写转小写
typeset -l  app
app=$appname

HARBOR_IP="registry-vpc.cn-shanghai.aliyuncs.com"
REPOSITORIES="xn-test/${proj}"
HARBOR_USER="niehaiyong@xiaoniutech"
HARBOR_USER_PASSWD="xn123456"
 
# Delete image early version.
docker login -u ${HARBOR_USER} -p ${HARBOR_USER_PASSWD} ${HARBOR_IP} 
IMAGE_ID=`docker images | grep ${REPOSITORIES} | awk '{print $3}'`
if [ -n "${IMAGE_ID}" ];then
    sudo docker rmi -f ${IMAGE_ID}
fi
 
# Build image.
cd $dir
#TAG=`date +"%Y-%m-%d-%H-%M"`
tagstr="$env"
docker build -t ${HARBOR_IP}/${REPOSITORIES}:${tagstr} . 
 
# Push to the harbor registry.
docker push ${HARBOR_IP}/${REPOSITORIES}:${tagstr} 

#sh  /data/shell2/shell/rundeck/docker-build.sh $appname  $proj
