#!/bin/bash
password=$1
if [ "$password" != "123@abc"  ];then
        echo "密码错误，请重新输入"
        exit 1
fi
