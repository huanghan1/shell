
jobadmin=job-admin
jobproft=job-executor/job-executor-proft
jobsys=job-executor/job-executor-system
jobtrade=job-executor/job-executor-trade
jobmall=job-executor/job-executor-mall
jobnews=job-executor/job-executor-news
