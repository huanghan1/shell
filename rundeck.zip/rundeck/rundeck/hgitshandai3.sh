#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 5 ];then
   echo "Usage:$0 参数错误"
   exit 1
fi
#svn://svn.xnshandai.net/shandai/trunk/loan-parent

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
app=$4
create_pro_war=$5
item=$6
pinpoint=$7
[ -z $pinpoint ] && pinpoint=no

[ $app == "None" -o -z $app ] && echo "The project name is error........" && exit 1
######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/hgitparfile.sh

#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径

eval dir="\$$item"
dir1="${dir}/loan-api"

if [[ $app == "hongluoperate" ]];then
   #dir="/root/.jenkins/workspace/huihuahua/trunk/operate-parent"
   dir1="$dir/operate-activity"
elif [[ $app == hongluoperateApi ]];then
   dir1="${operate_trunk}/operate-operate"
elif [[ $app == "crmCenter2" ]];then
   dir1="${operate_trunk}/operate-crm"
elif [[ $app == "marketCenter" ]];then
   dir1="${market_parent}"
elif [[ $app == "debitapiCenter" ]];then
   dir1="${debbitapi_trunk}/loan-api"
elif [[ $app == "userCenter" ]];then
   dir1="${userCenter_trunk}"

#elif [[ $projects == "debitapiCenter" ]];then
#   dir1="$dir2/debit-api-parent"
#elif [[ $projects == "bankCenter" ]];then
#   dir1="$dir2/bank-api-parent"

fi


#获取环境对应的ip
eval ip="\$$to"
######################################################################
#获取项目对应的svn目录名
echo $app | grep -q "-"
[ $? -eq 0 ] && appn=`echo $app | sed -n 's/-//gp'`
[ -z $appn ] && appn=$app
eval pdir="\$$appn"
############下面是主要方法的定义#######################################
#配置替换
function package {
  fg=0
  cd ${dir1}/$pdir || fg=1
  [ $fg -eq 1 ] && echo "目录${bra_name}下没有${app}这个工程目录" && exit 1
  flag=0
  if [ $build_all == "no" ];then
	 [ -d ${dir1}/${pdir}/target ] &&  rm -rf ${dir1}/${pdir}/target
         if [ $app  == "hongluoperate" -o $app == "hongluoperateApi" ];then
            cd $dir1
            $mvnd --settings $msetting clean install  -Dmaven.test.skip=true
            [ ! $? -eq 0 ] && echo "$app构建失败" && exit 1
            cd  ${dir1}/$pdir
         else 
            $mvnd --settings $msetting clean install  -Dmaven.test.skip=true
            [ ! $? -eq 0 ] && echo "$app构建失败" && exit 1
         fi

         echo "############################################################################################"
         echo "############################################################################################"
	 [ $? -eq 0 ] && flag=1 || flag=2
  fi
  [ $flag -eq 2 ] && echo "构建${app}失败,请找开发确定是否还有未提交的代码" && exit 1
  
  #[ -d target ] && filedir=`find target -name "*.original" `
  if [ -z $filedir ];then
     [ -d target ] && filedir=`find target -name "*.war" `
  fi
  [ ! -z $filedir ] && warfile=`basename $filedir `
  
  if [ ! -f target/$warfile ];then
         echo "############################################################################################"
         echo "############################################################################################"
	 [ $flag -eq 1 ] && echo "构建${app}失败,请找开发确定是否还有未提交的代码"
	 [ $flag -eq 0 ] && echo "testall构建失败,请找开发确定是否还有未提交的代码"
	 exit 1
  else
	 src_dir="${dir1}/${pdir}/target/$warfile"
	 #替换配置文件，生成各环境war包
	 sh /data/shell2/shell/rundeck/hgitconfig2.sh  "$src_dir" $app $to $create_pro_war
         #[ ! $? -eq 0 ] && echo "替换配置文件失败...." && exit 1
  fi
	 
}

#部署
function deploy {
   echo "开始部署${to}环境${app}项目....."
   chown -R wls81.wls81 /data/workspace/huihuahua/${app}
   #[ $to == "test01" -o $to == "test02" ] && rsync -avz -e "ssh -p 20022" /etc/hosts ${ip}:/etc/hosts > /dev/null
   if [ $to != "hpro" -a $to != "hpre" ];then
      warfile=`find /data/workspace/huihuahua/${app}/ -name ${app}_${to}.war`
      [ ! -f $warfile ] && echo "没有可用的war包" && exit 1
      #同步pinpoint 
      rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${ip}:${tom_dir}/pinpoint/

      rsync -az -e "ssh -p 20022" ${src_tom_dir}/${app}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude1.txt > /dev/null
      rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
      [ $build_all != "only_restart" ] && scp -P 20022 /data/workspace/huihuahua/${app}/${app}_${to}.war ${ip}:${tom_dir}/${app}/webapps/${app}.war
      ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/war_update.sh $app $pinpoint"
      #echo "$bra_name" > /data/workspace/war/${app}/version
   else
      warfile=`find /data/workspace/huihuahua/${app}/ -name ${app}.war`
      [[ ! -f $warfile ]] && echo "没有可用的war包" && exit 1
      echo "只生成${to}环境包，不部署..."
      echo "$bra_name" > /data/workspace/huihuahua/${app}/version
   fi
  
}

#########define function end ###################################################################################################

#执行package方法
if [ $build_all != "only_restart" ];then
    package
    echo "hconfig2 result:$?"
    [ ! $? -eq 0 ] && echo "配置文件替换失败" && exit 1 
fi

[ $build_all == "only_restart" ] && echo "重启所选应用。。。。。"

#[ $? -eq 1 ] && echo "配置文件替换失败" && exit 1 
#执行部署
export BUILD_ID=restarttomcat_${app}
deploy





