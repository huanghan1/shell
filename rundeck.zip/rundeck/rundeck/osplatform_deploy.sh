#!/bin/bash
#export BUILD_ID=restarttomcat
if [ $# -lt 4 ];then
   echo "Usage:$0 参数错误"
   echo 1
   exit 1
fi

unset cp 
mvnd=$(which mvn)

to=$1
bra_name=$2
build_all=$3
app=$4
item=$5

[ $app == "None" -o -z $app ] && echo "The project name is error........" && echo 2 && exit 1
######################################################################
#加载变量文件
parfile=`dirname $0`
. ${parfile}/osplatform_main_env.sh
. ${parfile}/${item}_svndir_env.sh

#获取maven的配置文件路径
eval msetting="\$${item}_mset"

#获取环境对应的svn物理路径
eval dir="\$$item"
eval dir1="\$${item}Api"

#获取环境对应的ip


eval ip="\$${item}_${to}"
#echo $app | grep -q "job"
#if [ "$?" == "0" ];then
#   item1="receive_job_${to}"
#   eval ip="\$$item1"
#fi
echo $ip
#拆分app

ptype=$(echo $app | awk -F "_" '{print $2}')
app=$(echo $app | awk -F "_" '{print $1}')
#获取配置中心对应的变量值
eval conf_host="\$${to}_host"
eval conf_port="\$${to}_port"
eval conf_env="\$${to}_env"

conf_app=${item}_$app
######################################################################
#获取项目对应的svn目录名
echo $app | grep -q "-"
[ $? -eq 0 ] && appn=`echo $app | sed -n 's/-//gp'`
[ -z $appn ] && appn=$app
eval pdir="\$$appn"

############下面是主要方法的定义#######################################
#配置替换
re=0
function package {

  echo ${dir1}/$pdir
cd ${dir1}/$pdir 
  echo ${dir1}/$pdir
  [ -z $pdir ] && echo "目录${bra_name}下没有${pdir}这个工程目录" && re=3 &&  exit 1
  [ ! -d ${dir1}/$pdir ] && echo "目录${bra_name}下没有${pdir}这个工程目录" && re=3 &&  exit 1
  flag=0
  if [ $build_all == "no" ];then
	 #[ -d ${dir1}/${pdir}/target ] &&  rm -rf ${dir1}/${pdir}/target
         if [ $item == "microservices" ];then
             $mvnd --settings $msetting clean install  -Dmaven.test.skip=true
         elif [ $item == "headline" ];then
              if [ $to == "online" ];then
                 $mvnd --settings $msetting  clean install -Dmaven.test.skip=true -Ddubbo.registry.address=zookeeper://zk.xnheadline.com:2181  -Pprod 
                 #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
              elif [ $to == "test01" ];then
                 $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true -Ptest
                 #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
              else
		 $mvnd --settings $msetting   clean install -Dmaven.test.skip=true -Pdev
                 #$mvnd --settings $msetting clean install -Dmaven.test.skip=true
              fi
         else
              
	      if [ $to == "online" ];then
                 mvn_string=""
                 [  $appn != "osplatformjobadmin" ] && mvn_string="-P online"
                 $mvnd  --settings $msetting clean install -Dmaven.test.skip=true  $mvn_string
              elif [ $to == "test01" ];then
                 mvn_string=""
                 [ $appn != "osplatformjobadmin" ] && mvn_string="-P qa"
                 $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true $mvn_string
              else
                 mvn_string=""
                 [ $appn != "osplatformjobadmin" ] && mvn_string="-P rd"
                 $mvnd  --settings $msetting  clean install -Dmaven.test.skip=true $mvn_string
              fi

         fi   
     
         #[ $? -eq 0 ] && flag=1 || flag=2
         echo "############################################################################################"
         echo "############################################################################################"
  fi
  [ $flag -eq 2 ] && echo "构建${app}失败,请找开发确定是否还有未提交的代码" && re=4 && exit 1
  
  #获取war或jar包  
  if [ "$ptype" == "war" ] ;then
     filedir=`find ${dir1}/${pdir} -name "*.war" `
  elif [ "$ptype" == "jar" ] ;then
     filedir=`find ${dir1}/${pdir} -name "*.jar" `
     if [ $item == "sports" ];then
        filedir=`find ${dir1}/${pdir} -name "*.war" `
     fi
  else
     echo "工程类型没有指定" && re=9 && exit 1
  fi

  filename=`basename $filedir`

  if [ "${filename}X" == "X" ];then
         echo "############################################################################################"
         echo "############################################################################################"
	 [ $flag -eq 1 ] && echo "构建${appn}失败,请找开发确定是否还有未提交的代码"
	 [ $flag -eq 0 ] && echo "testall构建失败,请找开发确定是否还有未提交的代码"
         echo 5
	 exit 1
  else
         if [ $build_all == "only_restart" ];then
            echo 6
            exit 0
         fi
	 #src_dir="${dir1}/${pdir}/target/$filename"
         if [ ! -d ${work_dir}/${ptype}/${item}/${appn}/$to ];then
                t1=0
                mkdir -p ${work_dir}/${ptype}/${item}/${appn}/$to
                cd ${work_dir}/${ptype}/${item}/${appn}/$to || t1=1
                [ $t1 -eq 1 ] && echo 10 && exit 1
         else
                t1=0
                cd ${work_dir}/${ptype}/${item}/${appn}/$to || t1=1
                [ $t1 -eq 1 ] && echo 11 && exit 1
                rm -rf ./*
         fi
         unset cp
         cp -f $filedir ./

         if [ "$ptype" == "war" ] ;then
            jar -xf $filename && rm -f $filename
            #modify disconf.properties
            if [ -f WEB-INF/classes/disconf.properties ];then
               sed -i "s/conf_server_host=.*/conf_server_host=$conf_host/" WEB-INF/classes/disconf.properties
               sed -i "s/app=.*/app=$conf_app/" WEB-INF/classes/disconf.properties
               sed -i "s/env=.*/env=$conf_env/" WEB-INF/classes/disconf.properties
            else
               #echo "没有${work_dir}/${ptype}/${item}/${appn}/${to}/WEB-INF/classes/disconf.properties 文件"
               unset cp
               #替换配置文件
               if [ -d /data/workspace/config/pre1/${app} -o -d /data/workspace/config/pro/${app} ];then
                  if [ $item == "osplatform_parent" ];then
                     if [ $to == "test01" ] ;then
                         cp -a /data/workspace/config/pre1/${app}/* WEB-INF/classes/
                     fi
                  elif [ $to == "dev" -o $to == "test01" ];then

                     cp -a /data/workspace/config/pre1/${app}/* WEB-INF/classes/
                  fi

                  if [ $to == "online" ];then
                     cp -a /data/workspace/config/pro/${app}/* WEB-INF/classes/
                  fi
               else
                  echo "/data/workspace/config目路下没有$app的配置文件"
                  exit 20
               fi
            fi
            #封装
            #if [ $to == "online" ];then
                  #封装生产包
                  jar  -cf ${appn}.war ./*
                  ls |grep -v ${appn}.war |sed  -r 's/(.*)/rm -rf  \1/' |bash
                  md5=$(sha256sum ${appn}.war  |awk '{print $1}')

            #fi
             
        else
           mv $filename ${appn}.jar
           md5=$(sha256sum ${appn}.jar  |awk '{print $1}')
        fi 

        echo "workspace 目录下已经准备好${appn}的最新编绎代码."

        if [ $to == "online" ];then
           #记录打包时间
           echo "记录打包时间.................."
           dt=`date +"%Y-%m-%d %H:%M"`       
           echo $md5 > sha256.txt    
           echo $dt > time
           echo "$bra_name" > version
        fi

                  
  fi
echo 0
	 
}

#部署
function deploy {
   echo "开始部署${to}环境${appn}项目....."
   #[ $to == "test01" -o $to == "test02" ] && rsync -avz -e "ssh -p 20022" /etc/hosts ${ip}:/etc/hosts > /dev/null
   if [ $to != "online" ];then
      #同步tomcat
      if [ $build_all == "only_restart" ];then
         rsync -az -e "ssh -p 20022" ${tom_dir}/${item}/${appn}/ ${ip}:${tom_dir}/${appn}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
      else
         rsync -az -e "ssh -p 20022" ${tom_dir}/${item}/${appn}/ ${ip}:${tom_dir}/${appn}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
      fi
      #同步脚本
      rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
      if [ $item == "osplatform_parent" ];then
         echo "rsync -az -e 'ssh -p 20022' /data/workspace/config/$item/$to/$app/ $ip:/home/wls81/config/$app/"
         [ -d /data/workspace/config/$item/$to/$app ] &&  rsync -az -e "ssh -p 20022" /data/workspace/config/$item/$to/$app/ $ip:/home/wls81/config/$app/
      fi
      if [ $item == sports -o $item == sportsJob ];then
         [ -d /data/workspace/config/sports/$to/$app ]&&  rsync -az -e "ssh -p 20022" /data/workspace/config/sports/$to/$app/ $ip:/home/wls81/config/$app/
      fi
         
      if [ "$ptype" == "war" ];then
         #同步app代码
         [ $build_all != "only_restart"  ] && rsync -az --delete -e "ssh -p 20022" ${work_dir}/${ptype}/$item/${appn}/${to}/ $ip:${tom_dir}/${appn}/webapps/
         #重新启动
         ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/war_update.sh $appn $item" 
      else
         #同步app代码
         [ $build_all != "only_restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/${ptype}/${item}/${appn}/${to}/ $ip:${tom_dir}/${appn}/
         #重新启动
         if [ $item == "sports" -o $item == "sportsJob" ];then
            ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/sports_update.sh $appn " & 
         elif [ $item == "osplatform_parent" -o $item == "receive_job" ];then
            ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/osplatform_update.sh $appn " &
         else
            ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/jar_update.sh $appn $item $to" & 
         fi
      fi 

   else
      if [ $ptype == "war" ];then
         warfile=`find ${work_dir}/${ptype}/${item}/${appn}/${to}/ -name ${appn}.war`
      else 
         warfile=`find ${work_dir}/${ptype}/${item}/${appn}/${to}/ -name ${appn}.jar`
      fi
      [[ ! -f $warfile ]] && echo "没有可用的war包" && re=1 &&  exit 1
      echo "生产包已经准备好..............."
      exit 0
   fi

  
}

#########define function end ###################################################################################################

#执行package方法
if [ $build_all != "only_restart" ];then
    package
    echo "re:$re"
    [[ ! $re -eq 0 ]] && echo "package error" && exit 1
else

   [ $build_all == "only_restart" ] && echo "重启所选应用。。。。。"
fi

#[ $? -eq 1 ] && echo "配置文件替换失败" && exit 1 
#执行部署
export BUILD_ID=restarttomcat_${app}
deploy





