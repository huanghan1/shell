
to=$1
JOB_BASE_NAME=$2
option=$3
app=$4
jar_name_str=$5
start_option="$6"
pinpoint="$7"


#bra_name=`echo $GIT_BRANCH |awk -F "/" '{print $2}'`
work_dir="/data/workspace/jar/huihuahua/${app}/$to"
dir=/root/.jenkins/workspace/huihuahua/risk-control/$JOB_BASE_NAME/target
conf_dir=/home/wls81/config/huihuahua/$app
conf_dir1=/home/wls81/config/huihuahua/pre/$app
tom_dir=/home/wls81/tomcat
tomcat_dir=${tom_dir}/huihuahua/$app

riskapply_ip=172.16.11.211
riskfddjob_ip=172.16.11.211
riskcreditaccess_ip=172.16.0.190
riskcreditbusiness_ip=172.16.0.190
riskcreditreport_ip=172.16.11.212
riskcustomer_ip=172.16.0.190
riskjob_ip=172.16.0.190
riskmqconsumer_ip=172.16.11.211
riskmqproducer_ip=172.16.11.212
riskrule_ip=172.16.11.212
riskrulerest_ip=172.16.11.211
risksecurity_ip=172.16.0.190
riskweb_ip=172.16.0.190
mgriskjob_ip=172.16.11.212


dev_ip=106.15.48.19
deploy_ip=106.15.48.19
fat_ip=172.16.0.193
#pre_ip=172.16.0.190
eval "uat_ip=\$${app}_ip"

[ ! -d $work_dir ] && mkdir -p $work_dir
[ ! -d $tomcat_dir ] && mkdir -p $tomcat_dir
[ ! -d $conf_dir  ] && mkdir -p $conf_dir

eval ip="\$${to}_ip"

cd $dir
jar_name=`ls | grep -E "$jar_name_str"`
[[ ! -f $jar_name ]] && echo "没有可用的jar包" &&  exit 1
unset cp
cp -f $jar_name ${work_dir}/${app}.jar

chown -R wls81. $work_dir

case ${to} in
   pro)      
    #记录打包时间
    echo "记录打包时间.................."
    md5=$(sha256sum ${work_dir}/${app}.jar  |awk '{print $1}')
    dt=`date +"%Y-%m-%d %H:%M"`
    echo $md5 > ${work_dir}/sha256.txt
    echo $dt > ${work_dir}/time
    echo "$to" > ${work_dir}/version
    echo "生产包已经准备好..............."
       
    #比较生产包与测试包的md5
    #if [ -f /data/workspace/jar/huihuahua/${app}/fat/sha256.txt ];then
    #   fat_sha256=`cat data/workspace/jar/huihuahua/${app}/fat/sha256.txt`
    #   if [ $md5 != $fat_sha256 ];then
    #      echo "此生产包与最后一次构建的测试包md5值不一致,此生产包未经测试验证。"   
    #      echo "0" > ${work_dir}/if_pass_verify.txt
    #      exit 1
    #   else
    #      echo "此生产包与最后一次构建的测试包md5值一致,此生产包已经测试验证。"
    #      echo "1" > ${work_dir}/if_pass_verify.txt
    #      exit 0
    #   fi
    #else
    #   echo "此生产包与最后一次构建的测试包md5值不一致,此生产包未经测试验证。"   
    #   echo "0" > ${work_dir}/if_pass_verify.txt
    #   exit 1
    #fi
                   
    ##同步pinpoint 
    #rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${pre_ip}:${tom_dir}/pinpoint/ > /dev/null
    #同步tomcat
    #if [ $option == "restart" ];then
    #  rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    #else
    #  rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${pre_ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    #fi
        
    #同步配置文件
    #[ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir1}/ ${pre_ip}:${conf_dir}/
    #同步脚本
    #rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ ${pre_ip}:/data/shell2/shell/rundeck/
        
    #同步jar包
    #[ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ ${pre_ip}:${tom_dir}/${app}/

    #重新启动
    #echo "############################################################################################"
    #echo "开始启动${app},这可能需要几分钟....."
    #echo "........"
    #sleep 1
    #echo "..."
    #echo "启动检验............"
    #ssh -p 20022 ${pre_ip} "sh /data/shell2/shell/rundeck/hhh-risk_update.sh $app $start_option $pinpoint" &
    #sleep 12
    #ssh -p 20022 ${pre_ip} "ps -ef |grep  ${app}.jar |grep -v grep "
    #[ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    exit 0
       
   ;;
    
   dev|fat|uat)
    echo "$ip"
    ##同步pinpoint 
    rsync -az -e "ssh -p 20022" ${tom_dir}/pinpoint/ ${ip}:${tom_dir}/pinpoint/ > /dev/null 
    #同步tomcat
    if [ $option == "restart" ];then
      rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt  > /dev/null
    else
      rsync -az -e "ssh -p 20022" ${tomcat_dir}/ ${ip}:${tom_dir}/${app}/ --exclude-from=/data/workspace/exclude.txt --delete > /dev/null
    fi
        
    #同步配置文件
    [ $bra_name != "develop" ] && rsync -az -e "ssh -p 20022" ${conf_dir}/ ${ip}:${conf_dir}/
    #同步脚本
    rsync -az -e "ssh -p 20022" /data/shell2/shell/rundeck/ $ip:/data/shell2/shell/rundeck/
        
    #同步jar包
    [ $option != "restart" ] && rsync -az  -e "ssh -p 20022" ${work_dir}/ $ip:${tom_dir}/${app}/

    #重新启动
    echo "############################################################################################"
    echo "开始启动${app},这可能需要几分钟....."
    echo "........"
    sleep 1
    echo "..."
    echo "启动检验............"
    set -m "test"
    ssh -p 20022 $ip "sh /data/shell2/shell/rundeck/hhh-risk_update.sh $app \"$start_option\" $pinpoint" &
    sleep 12
    ssh -p 20022 $ip "ps -ef |grep  ${app}.jar |grep -v grep "
    [ ! $? -eq 0 ] && echo "$app start false." && exit 1
    #pid=$(ps -ef | grep -E "ytm.sh" |grep -v "grep" | awk '{print $2}')
    #kill -9 $pid
    md5=$(sha256sum ${work_dir}/${app}.jar  |awk '{print $1}')
    echo $md5 > ${work_dir}/sha256.txt
    exit 0
  
  ;;    
    
  *)
    echo "环境不存在"
    exit 1
  ;;
esac

