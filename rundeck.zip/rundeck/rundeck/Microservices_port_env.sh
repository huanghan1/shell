user=20890  #jvm:2353
account=20891  #jvm:2354
apiGateway=8090  #jvm:2351
web=8091  #jvm:2352
job=10000  #jvm:10000
message=20893  #jvm:2356
ruleConfig=20892  #jvm:2355
