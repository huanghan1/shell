#!/bin/bash
appname=$1
[ ! -d /home/wls81/tomcat/$appname ]  && mkdir -pv /home/wls81/tomcat/$appname
[ ! -d /data/$appname/logs/ ] && mkdir -pv /data/$appname/logs/

/usr/bin/pm2 stop /home/wls81/tomcat/$appname/start.json

sleep 5 

/usr/bin/pm2 start /home/wls81/tomcat/$appname/start.json
