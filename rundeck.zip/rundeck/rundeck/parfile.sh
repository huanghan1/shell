#!/bin/bash
######################################################################
#定义项目对应的maven配置文件路径
headline_mset="/usr/local/maven-3.5.0/conf/headline_settings.xml"
sports_mset="/usr/local/maven-3.5.0/conf/sports_settings.xml"

######################################################################
#tomcat路径
tom_dir="/home/wls81/tomcat"
#work_dir
work_dir="/data/workspace"

#定义环境对应的svn物理路径
#headline 主干
headline="/root/.jenkins/workspace/headline"
headlineApi="${headline}/headline-api"

#sports trunk
#sports="/root/.jenkins/workspace/branches/${bra_name}/loan-parent"
#sportsApi="/root/.jenkins/workspace/branches/${bra_name}/loan-parent"
######################################################################
#配置中心
dev_host="disconf.51xnsd.com"
dev_port="80"
dev_env="rd"
test01_host="172.16.0.215"
test01_port=$dev_port
test01_env="qa"

online_host=""
online_port=""
online_env="online"

######################################################################
#定义环境对应的ip
dev="172.16.0.226"
test01="172.16.0.216"
test02=""
test03="172.16.0.217"
test04="172.16.0.193"
test05="172.16.0.196"
test06="172.16.0.197"

#定义环境密码
devX="dev"
test01X="testing"
test02X=$test01X
test03X=$test01X
test04X=$test01X
test05X=$test01X
test06X=$test01X
onlineX="1"

######################################################################
#定义项目的要svn目录名
#app
bankCenter="loan-bank-api"
payserviceCenter="loan-pay-service-api"
activityCenter="loan-activity-api"
delegateApi="loan-delegate-api"
userCenter="loan-user-api"
crmCenter="loan_crm_web"
hongluMsg="honglu-msg-impl"
authCenter="loan-authCenter-api"
honglubatchMsg="honglu-batch-msg"
debitapiCenter="loan-debit-api"
messageCenter="loan-message-api"
hongluBatchPay="honglu-batch-pay"
honglubatch="honglu-batch"
debitserviceCenter="loan-debit-service-api"
yntrustpay="loan-yntrustpay-api"
hongluBatchXt="honglu-batch-xt"
hongluBatchMonitor="honglu-batch-monitor"
marketApi="loan-market-api"
loanQuotaApi="loan-quota-api"

#risk
backendCenter="loan-backend-web"
backendCenter2="loan-backend-web"
backendDubbo="loan-backend-dubbo"
backendDubboCustomer="loan-backend-dubbo-customer"
backendShared="loan-backend-shared"
backendMqCenterConsumer="loan-backend-rabbitmq"
backendtaskCenter="loan-backend-task"
backendMqCenter="loan-backend-rabbit-producer"
backendtaskminor="loan-backend-task-minor"
backendMqbusiness="loan-backend-mq-business"
backendTaskPromote="loan-backend-task-promote"

#receive
receiveWebCenter="loan-receive-web"
receiveTaskCenter="loan-receive-task"
receiveReport="loan-receive-report"
#caiwu
financeWeb="loan-finance-system"
#########################################################################
#定义实例对应的端口

        #_port=(8009 8010 8011 8012 8013 8014 8015 8016 8017 8018 8019 8020 8021 8022 8023 8024 8025 8026 8027 8028 8029 8030 8031 8032 8033 8034 8035 8036 8037 8038 8039 8040 8041 8042 8043 8044 8045 8046)
        #_port=(2346 2347 2348 2349 2350 2351 2352 2353 2354 2354 2355 2356 2357 2358 2359 2360 2361 2362 2363 2364 2365 2366 2367 2368 2369 2370 2371 2372 2373 2374 2375 2376 2377 2378 2379 2380 2381 2382) 
#instance_port=(8083 8084 8085 8086 8087 8088 8089 8090 8091 8092 8093 8094 8095 8096 8097 8098 8099 8100 8101 8102 8103 8104 8105 8106 8107 8108 8109 8110 8111 8112 8113 8114 8115 8116 8117 8118 8119 8220) 
authCenterX=8083
userCenterX=8084
backendCenterX=8085
backendtaskCenterX=8086
messageCenterX=8087
activityCenterX=8088
debitapiCenterX=8089
debitserviceCenterX=8090
bankCenterX=8092
payserviceCenterX=8093
crmCenterX=8094
honglubatchX=8095
receiveTaskCenterX=8096
receiveWebCenterX=8097
backendDubboX=8098
backendDubboCustomerX=8099
honglubatchMsgX=8100
hongluMsgX=8101
hongluBatchPayX=8102
operationWebX=8103
backendMqCenterConsumerX=8104
backendSharedX=8105
delegateApiX=8106
yntrustpayX=8107
hongluBatchXtX=8108
receiveReportX=8109
backendMqCenterX=8110
backendtaskminorX=8111
financeWebX=8112
hongluBatchMonitorX=8113
backendMqbusinessX=8114
marketApiX=8115
ptoppayApiX=8116
operateActApiX=8117
backendTaskPromoteX=8118
backendCenter2X=8119
loanQuotaApiX=8220

