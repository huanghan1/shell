#!/bin/bash
#app_主干命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 trunk crmCenter yes test app_trunk

#app_分支命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 1.4.0 activityCenter no test app_branch

#风控命令行测试用例
#sh -x /data/shell2/shell/rundeck/app_trunk.sh test02 risk-parent_2.7 backendCenter no test risk

#催收命令行测试用例
#sh -x  /data/shell2/shell/rundeck/app_trunk.sh test02 receive receiveWebCenter no test receive
######################################################################
#定义项目对应的maven配置文件路径
#app_trunk_mset="/usr/local/maven-3.5.0/conf/trunk_settings.xml"
app_trunk_mset="/usr/local/maven-3.5.0/conf/voice_setting.xml"
app_branch_mset="/usr/local/maven-3.5.0/conf/appBranch_settings.xml"
######################################################################
#tomcat路径
src_tom_dir="/home/wls81/tomcat/voice"
tom_dir="/home/wls81/tomcat"
jar_config_dir="/home/wls81/config/voice"
war_config_idr="/data/workspace/config"
workspace_dir="/data/workspace/voice"
#配置文件路
vdev_configdir="/data/workspace/config/vdev"
vtest01_configdir="/data/workspace/config/vtest01"
vpro_configdir="/data/workspace/config/vpro"

#定义环境对应的svn物理路径
#app 主干
app_trunk="/root/.jenkins/workspace/gsvoice"
dir2="/root/.jenkins/workspace/gsvoice"


######################################################################
#定义环境对应的ip
vdev="172.16.11.195"
vtest01="172.16.11.206"
vpro="172.16.0.191"

#定义环境密码
vdevX="dev"
vtest01X="qytest"
vproX="pro"

######################################################################

#定义项目的要target目录名
gsactivitywar_target="quickcall-activity/quickcall-activity-web"
gsactivityjar_target="quickcall-activity/quickcall-activity-service"
gsaccountwar_target="quickcall-account/quickcall-account-web"
gsaccountjar_target="quickcall-account/quickcall-account-service"
gsuserwar_target="quickcall-user/quickcall-user-web"
gsuserjar_target="quickcall-user/quickcall-user-service"
gscommonjar_target="quickcall-common/quickcall-cmomon-third"
gsadminwar_target="quickcall-admin"
gstaskjar_target="quickcall-task"
gsconsumerjar_target="quickcall-consumer/quickcall-consumer-service"
gsproducerjar_target="quickcall-producer/quickcall-producer-service"
gsdataburyjar_target="quickcall-databury/quickcall-databury-services"


#定义项目的要打包目录名
gsactivitywar_build="quickcall-activity"
gsactivityjar_build="quickcall-activity"
gsaccountwar_build="quickcall-account"
gsaccountjar_build="quickcall-account"
gsuserwar_build="quickcall-user"
gsuserjar_build="quickcall-user"
gscommonjar_build="quickcall-common"
gsadminwar_build="quickcall-admin"
gstaskjar_build="quickcall-task"
gsconsumerjar_build="quickcall-consumer"
gsproducerjar_build="quickcall-producer"
gsdataburyjar_build="quickcall-databury"


#定义实例对应的端口
gsactivitywarX=18083
gsactivityjarX=18084
gsaccountwarX=18085
gsaccountjarX=18086
gsuserwarX=18087
gsuserjarX=18088
gscommonjarX=18089
gsadminwarX=18090
gstaskjarX=18091
gsconsumerjarX=18092
gsproducerjarX=18093
gsdataburyjarX=18094

#定义应用类型
gsactivitywar_type=war
gsactivityjar_type=jar
gsaccountwar_type=war
gsaccountjar_type=jar
gsuserwar_type=war
gsuserjar_type=jar
gscommonjar_type=jar
gsadminwar_type=war
gstaskjar_type=jar
gsconsumerjar_type=jar
gsproducerjar_type=jar
gsdataburyjar_type=jar


#包名
gsactivitywar_filename=activityCenter.war
gsactivityjar_filename=activityCenter.jar
gsaccountwar_filename=accountCenter.war
gsaccountjar_filename=accountCenter.jar
gsuserwar_filename=userCenter.war
gsuserjar_filename=userCenter.jar
gscommonjar_filename=quickcall.jar
gsadminwar_filename=admin.war
gstaskjar_filename=voice-task.jar
gsconsumerjar_filename=consumerjar.jar
gsproducerjar_filename=producerjar.jar
gsdataburyjar_filename=databuryjar.jar
