#!/bin/bash
domains=$1
subdomains=$2
. /etc/profile
for i in `/usr/bin/cat /home/wls81/ansible/file/shell/rundeck/config.ini`
do
   key=`echo $i |awk -F '[-]' '{print $2}'`
   keyId=`echo $i |awk -F '[-]' '{print $1}'`
   keys=`/home/wls81/ansible/file/shell/rundeck/querydomin -keyId=$keyId -key=$key -domains="$domains"`   
   if [ ! -z "$keys" ];then
       break
   fi
done
if [ -z $keys ];then
    echo "$domains不存在这些账户中"
    exit 0
fi

keyId=`echo $keys |awk -F '[-]' '{print $1}'`
key=`echo $keys |awk -F '[-]' '{print $2}'`

#echo $keyId
#cho $key
echo $domains
echo $subdomains
record_type="A"
ip_value="106.14.55.251"

#echo "/usr/bin/python2.7 /home/wls81/ansible/file/shell/rundeck/add_domain.py $keyId $key $domains $subdomains $record_type $ip_value"
/usr/bin/python2.7 /home/wls81/ansible/file/shell/rundeck/add_domain.py $keyId $key $domains $subdomains $record_type $ip_value
